import { createClient } from '@/utils/supabase/server'
import { NewsImage } from '@/components/news-image'
import Link from 'next/link'
import { Database } from '@/types/database.types'

type Post = Database['public']['Tables']['posts']['Row']

interface RelatedArticlesProps {
  currentPostId: string
  category: string
  currentTags?: string[] | null
  limit?: number
}

export async function RelatedArticles({
  currentPostId,
  category,
  currentTags = [],
  limit = 3,
}: RelatedArticlesProps) {
  const supabase = await createClient()

  // First, get posts in same category
  const { data: categoryPosts, error: categoryError } = await (supabase
    .from('posts') as any)
    .select('*')
    .eq('status', 'published')
    .eq('category', category)
    .neq('id', currentPostId)
    .limit(limit * 3) // Get more to score and filter

  if (categoryError) {
    console.error('Error fetching related posts:', categoryError)
  }

  // Also get posts with matching tags if we have tags
  let taggedPosts: any[] = []
  if (currentTags && currentTags.length > 0) {
    const { data, error: tagError } = await (supabase
      .from('posts') as any)
      .select('*')
      .eq('status', 'published')
      .neq('id', currentPostId)
      .contains('tags', currentTags)
      .limit(limit * 2)

    if (!tagError && data) {
      taggedPosts = (data || []) as any[]
    }
  }

  // Combine and score posts
  const allPosts = [...((categoryPosts || []) as any[]), ...taggedPosts]

  // Deduplicate by ID
  const uniquePosts = Array.from(
    new Map(allPosts.map((post: any) => [post.id, post])).values()
  )

  // Score posts: higher score = more relevant
  const scoredPosts = uniquePosts.map((post: any) => {
    let score = 0

    // Category match: +10 points
    if (post.category === category) {
      score += 10
    }

    // Tag matches: +5 points per matching tag
    if (currentTags && post.tags && Array.isArray(post.tags)) {
      const matchingTags = post.tags.filter((tag: any) =>
        currentTags.includes(tag)
      ).length
      score += matchingTags * 5
    }

    // Views: +0.01 per view (normalized)
    score += (post.views || 0) * 0.01

    // Recency: newer posts get slight boost
    if (post.published_at) {
      const pubDate = new Date(post.published_at).getTime()
      // Use efficient approx for current time to avoid re-render purity check failures or move to useMemo if needed
      // But for scoring, a stable 'now' is fine.
      const now = new Date().getTime()
      const daysSince = (now - pubDate) / (1000 * 60 * 60 * 24)
      if (daysSince < 7) score += 2
      else if (daysSince < 30) score += 1
    }

    return { ...post, relevanceScore: score }
  })

  // Sort by relevance score and take top N
  const posts = scoredPosts
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, limit)

  if (posts.length === 0) {
    return null
  }

  return (
    <div className="border-t border-border pt-8 mt-8">
      <h2 className="text-2xl font-heading font-bold mb-6">Related Articles</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {posts.map((post: any) => (
          <Link
            key={post.id}
            href={`/news/${post.slug}`}
            className="group block space-y-3"
          >
            <div className="aspect-video rounded-md border border-border/50 overflow-hidden relative">
              <NewsImage
                src={post.featured_image_url}
                alt={post.title}
                fill
                className="group-hover:scale-105 transition-transform duration-300"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                <span className="text-accent uppercase">{post.category}</span>
                {post.published_at && (
                  <>
                    <span>•</span>
                    <span>{new Date(post.published_at).toLocaleDateString()}</span>
                  </>
                )}
              </div>
              <h3 className="font-heading font-bold group-hover:text-accent transition-colors line-clamp-2">
                {post.title}
              </h3>
              {post.excerpt && (
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {post.excerpt}
                </p>
              )}
            </div>
          </Link>
        ))}
      </div>
    </div>
  )
}



