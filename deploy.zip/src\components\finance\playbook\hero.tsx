export function PlaybookHero() {
    return (
        <section className="bg-gradient-to-br from-blue-500 via-trail-blue to-purple-600 text-white py-24">
            <div className="max-w-5xl mx-auto px-6 text-center">
                <div className="inline-flex items-center gap-2 px-6 py-3 bg-white/20 backdrop-blur-sm rounded-full mb-8">
                    <span className="text-sm font-bold uppercase tracking-wider font-sans">💎 Premium Wealth Guide</span>
                </div>

                <h1 className="font-display text-6xl sm:text-7xl font-black mb-6 leading-tight">
                    The Millionaire&apos;s<br />Playbook
                </h1>

                <p className="text-2xl sm:text-3xl mb-12 text-blue-100 max-w-3xl mx-auto leading-relaxed font-serif">
                    7 proven strategies used by 10,000+ people to build their first million from scratch
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 max-w-3xl mx-auto">
                    <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                        <div className="text-4xl sm:text-5xl font-black mb-2 font-display">18.2</div>
                        <div className="text-sm text-blue-200 font-sans">Avg. Years to $1M</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                        <div className="text-4xl sm:text-5xl font-black mb-2 font-display">89%</div>
                        <div className="text-sm text-blue-200 font-sans">Success Rate</div>
                    </div>
                    <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                        <div className="text-4xl sm:text-5xl font-black mb-2 font-display">$0</div>
                        <div className="text-sm text-blue-200 font-sans">Starting Capital</div>
                    </div>
                </div>
            </div>
        </section>
    )
}
