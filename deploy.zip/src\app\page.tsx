import { createClient } from '@/utils/supabase/server'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { BackToTop } from '@/components/back-to-top'
import { BreakingBanner } from '@/components/breaking-banner'
import { getSiteUrl } from '@/lib/env'
import type { Metadata } from 'next'

// New Homepage Components
import { FilterBar } from '@/components/home/filter-bar'
import { LeftSidebar } from '@/components/home/left-sidebar'
import { RightSidebar } from '@/components/home/right-sidebar'
import { MainFeed } from '@/components/home/main-feed'

// Data Fetching
import { getTrendingPosts } from '@/components/trending-posts'
import { getMostPopular } from '@/components/most-popular'

const POSTS_PER_PAGE = 20

// Re-using existing helper with improved typing
async function getSiteConfig() {
  const supabase = await createClient()
  const { data, error } = await (supabase
    .from('site_config') as any)
    .select('*')
    .single()

  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching site config:', error)
    return null
  }

  return data as {
    id: string
    hero_post_id: string | null
    breaking_banner_active: boolean | null
    breaking_banner_text: string | null
    pinned_post_ids: string[] | null
    [key: string]: any
  } | null
}

async function getHeroAndPinnedPosts(config: any) {
  const supabase = await createClient()
  const postIds: string[] = []

  if (config?.hero_post_id) postIds.push(config.hero_post_id)
  if (config?.pinned_post_ids && Array.isArray(config.pinned_post_ids)) {
    postIds.push(...config.pinned_post_ids)
  }

  if (postIds.length === 0) return { heroPost: null, pinnedPosts: [] }

  const { data, error } = await (supabase
    .from('posts') as any)
    .select('*')
    .eq('status', 'published')
    .in('id', postIds)

  if (error) {
    console.error('Error fetching hero/pinned posts:', error)
    return { heroPost: null, pinnedPosts: [] }
  }

  const typedData = (data || []) as any[]
  const heroPost = config?.hero_post_id
    ? typedData.find((p: any) => p.id === config.hero_post_id) || null
    : null

  const pinnedPosts = config?.pinned_post_ids
    ? typedData.filter((p: any) => config.pinned_post_ids?.includes(p.id)) || []
    : []

  return { heroPost, pinnedPosts }
  return { heroPost, pinnedPosts: [] }
}

async function getEditorsPicks() {
  const supabase = await createClient()
  const { data, error } = await (supabase
    .from('posts') as any)
    .select('*')
    .eq('status', 'published')
    .eq('is_editors_pick', true)
    .order('published_at', { ascending: false })
    .limit(5)

  if (error) {
    console.error('Error fetching editors picks:', error)
    return []
  }

  return (data || []) as any[]
}

async function getPublishedPosts(page: number = 1, excludeIds: string[] = []) {
  const supabase = await createClient()
  const from = (page - 1) * POSTS_PER_PAGE
  const to = from + POSTS_PER_PAGE - 1

  let query = (supabase
    .from('posts') as any)
    .select('*', { count: 'exact' })
    .eq('status', 'published')
    .order('published_at', { ascending: false })

  if (excludeIds.length > 0) {
    query = query.not('id', 'in', `(${excludeIds.join(',')})`)
  }

  const { data, error, count } = await query.range(from, to)

  if (error) {
    console.error('Error fetching posts:', error)
    return { posts: [], total: 0 }
  }

  return {
    posts: (data || []) as any[],
    total: count || 0,
  }
}

export const revalidate = 60

export async function generateMetadata(): Promise<Metadata> {
  const siteUrl = getSiteUrl()
  return {
    title: 'The Trail - Follow the path to the truth',
    description: 'High performance, clean typology, information-dense news. Follow the path to the truth.',
    alternates: {
      canonical: siteUrl,
    },
    openGraph: {
      title: 'The Trail',
      description: 'High performance, information-dense news.',
      url: siteUrl,
      siteName: 'The Trail',
      type: 'website',
    },
    twitter: {
      card: 'summary_large_image',
      title: 'The Trail',
      description: 'Follow the path to the truth.',
      creator: '@TheTrailNews',
    },
  }
}

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>
}) {
  const configPromise = getSiteConfig()
  const trendingPromise = getTrendingPosts([], 5)
  const popularPromise = getMostPopular(3)
  const resolvedSearchParams = await searchParams
  const currentPage = parseInt(resolvedSearchParams?.page || '1', 10) || 1

  // 1. Resolve Config first to determine Hero/Pinned (needed for exclusion)
  const config = await configPromise

  // 2. Fetch Hero based on config (Pinned is now deprecated in favor of is_editors_pick)
  const { heroPost } = await getHeroAndPinnedPosts(config)

  // 3. Fetch Editors Picks (Dynamic)
  const editorsPicksPromise = getEditorsPicks()

  // 4. Prepare Excludes for Main Feed (will need to wait for editors picks if we exclude them, 
  // but to optmize, we can fetch them in parallel and filter client side or distinct logic. 
  // Typically Editor's picks might overlap with feed. Let's exclude them to avoid duplicates if they are in the top list.)
  // Ideally we await all.

  const [
    editorsPicks,
    trendingPosts,
    popularPosts
  ] = await Promise.all([
    editorsPicksPromise,
    trendingPromise,
    popularPromise
  ])

  // 5. Prepare Excludes
  const excludeIds: string[] = []
  if (heroPost) excludeIds.push(heroPost.id)
  if (editorsPicks.length > 0) excludeIds.push(...editorsPicks.map((p: any) => p.id))

  // 6. Fetch Main Feed
  const { posts: feedPosts, total } = await getPublishedPosts(currentPage, excludeIds)

  return (
    <div className="min-h-screen bg-white text-slate-text font-sans">
      {/* Top Alert */}
      <BreakingBanner
        text={config?.breaking_banner_text || ''}
        active={config?.breaking_banner_active || false}
      />

      {/* Header */}
      <Navigation breakingBannerActive={config?.breaking_banner_active || false} />

      {/* Filter Bar (New) */}
      <FilterBar />

      {/* Main Content Layout */}
      <main className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-12 gap-8">

          {/* Left Sidebar (Trending, Editor's Picks) */}
          <LeftSidebar
            trendingPosts={trendingPosts}
            editorsPicks={editorsPicks}
          />

          {/* Center Content (Hero, Grid, List) */}
          <MainFeed
            heroPost={heroPost}
            feedPosts={feedPosts}
          />

          {/* Right Sidebar (Popular, Live, Categories) */}
          <RightSidebar
            popularPosts={popularPosts}
          />

        </div>
      </main>

      <Footer />
      <BackToTop />
    </div>
  )
}
