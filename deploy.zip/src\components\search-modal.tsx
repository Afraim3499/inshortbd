'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Search, Clock, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'
import Link from 'next/link'

const CATEGORIES = ['Politics', 'Tech', 'Culture', 'Business', 'World']

interface SearchModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function SearchModal({ open, onOpenChange }: SearchModalProps) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const router = useRouter()

  // Load recent searches from localStorage with lazy initialization to avoid Effect
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('trail_recent_searches')
      if (stored) {
        try {
          return JSON.parse(stored).slice(0, 5)
        } catch {
          // Invalid JSON, ignore
        }
      }
    }
    return []
  })

  // Focus input when modal opens
  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100)
    } else {
      // Clear query after close animation
      const timer = setTimeout(() => setQuery(''), 300)
      return () => clearTimeout(timer)
    }
  }, [open])

  // Keyboard shortcut handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault()
        onOpenChange(!open)
      }
      if (e.key === 'Escape' && open) {
        onOpenChange(false)
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [open, onOpenChange])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      // Save to recent searches
      const newRecent = [query.trim(), ...recentSearches.filter(s => s !== query.trim())].slice(0, 5)
      setRecentSearches(newRecent)
      if (typeof window !== 'undefined') {
        localStorage.setItem('trail_recent_searches', JSON.stringify(newRecent))
      }

      router.push(`/search?q=${encodeURIComponent(query.trim())}`)
      onOpenChange(false)
    }
  }

  const handleRecentClick = (search: string) => {
    setQuery(search)
    router.push(`/search?q=${encodeURIComponent(search)}`)
    onOpenChange(false)
  }

  const handleCategoryClick = (category: string) => {
    router.push(`/category/${encodeURIComponent(category)}`)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl p-0 gap-0 bg-white">
        <DialogTitle className="sr-only">Search Website</DialogTitle>
        <div className="p-6 border-b border-card-border">
          <form onSubmit={handleSubmit}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-meta-gray" />
              <Input
                ref={inputRef}
                type="search"
                placeholder="Search articles, topics, categories..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="pl-12 pr-24 h-14 text-lg font-serif border-2 border-card-border focus:border-trail-blue rounded-none"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-2">
                <kbd className="hidden sm:inline-flex h-6 select-none items-center gap-1 rounded border border-card-border bg-soft-wash px-2 font-mono text-xs text-meta-gray">
                  {navigator.platform.toUpperCase().includes('MAC') ? '⌘' : 'Ctrl'}K
                </kbd>
                <span className="text-xs text-meta-gray font-mono">ESC</span>
              </div>
            </div>
          </form>
        </div>

        <div className="max-h-[60vh] overflow-y-auto">
          {/* Recent Searches */}
          {recentSearches.length > 0 && (
            <div className="p-6 border-b border-card-border">
              <div className="flex items-center gap-2 mb-4">
                <Clock className="w-4 h-4 text-meta-gray" />
                <h3 className="text-sm font-sans font-semibold uppercase tracking-wide text-ink-black">
                  Recent Searches
                </h3>
              </div>
              <div className="space-y-2">
                {recentSearches.map((search, index) => (
                  <button
                    key={index}
                    onClick={() => handleRecentClick(search)}
                    className="w-full text-left px-3 py-2 text-sm text-slate-text hover:bg-soft-wash hover:text-trail-blue transition-colors font-serif rounded-sm"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quick Categories */}
          <div className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="w-4 h-4 text-meta-gray" />
              <h3 className="text-sm font-sans font-semibold uppercase tracking-wide text-ink-black">
                Browse Categories
              </h3>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {CATEGORIES.map((category) => (
                <button
                  key={category}
                  onClick={() => handleCategoryClick(category)}
                  className="px-4 py-2 text-sm text-slate-text hover:bg-trail-blue hover:text-white transition-colors font-serif border border-card-border hover:border-trail-blue text-center"
                >
                  {category}
                </button>
              ))}
            </div>
          </div>

          {/* Search Tips */}
          <div className="p-6 bg-soft-wash border-t border-card-border">
            <DialogDescription className="text-xs text-meta-gray font-mono">
              Press <kbd className="px-1.5 py-0.5 rounded border border-card-border bg-white">Enter</kbd> to search
              {' • '}
              Press <kbd className="px-1.5 py-0.5 rounded border border-card-border bg-white">ESC</kbd> to close
            </DialogDescription>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
