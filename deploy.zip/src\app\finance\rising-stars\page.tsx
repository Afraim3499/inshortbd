import { getBillionaires } from '@/app/actions/billionaires/get'
import { FinanceHeader } from '@/components/finance/finance-header'
import { PRHero } from '@/components/finance/pr/pr-hero'
import { SponsorshipBanner } from '@/components/finance/pr/sponsorship-banner'
import { PRCard } from '@/components/finance/pr/pr-card'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Rising Stars Under 40: Young Billionaires - The Trail Finance',
    description: 'The next generation of billionaires, unicorn founders, and wealth builders reshaping global finance.',
}

export const revalidate = 300 // 5 minutes

export default async function RisingStarsPage() {
    // Fetch up to 100 rising stars
    const { billionaires } = await getBillionaires({
        ageGroup: 'under-40',
        sortBy: 'net_worth',
        limit: 100,
    })

    // Calculate Stats
    const count = billionaires.length

    // Total wealth in billions
    const totalWealthVal = billionaires.reduce((acc, curr) => acc + curr.net_worth_usd, 0)
    const totalWealthStr = `$${(totalWealthVal / 100000000000).toFixed(1)}B`

    // Avg Age
    const totalAge = billionaires.reduce((acc, curr) => acc + (curr.age || 0), 0)
    const avgAge = count > 0 ? Math.round(totalAge / count) : 0

    // Self Made %
    const selfMadeCount = billionaires.filter(b => b.is_self_made).length
    const selfMadePct = count > 0 ? Math.round((selfMadeCount / count) * 100) : 0

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                <PRHero
                    title="Rising Stars Under 40"
                    subtitle="The next generation of billionaires, unicorn founders, and wealth builders reshaping global finance"
                    stats={{
                        count,
                        wealth: totalWealthStr,
                        avgAge,
                        selfMadePct
                    }}
                    badgeText="EXCLUSIVE LIST 2025"
                    colorClass="text-trail-blue"
                />

                <SponsorshipBanner
                    text="Want to be featured in our next Rising Stars list?"
                    ctaText="Sponsorship Info →"
                />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

                    {/* Filters or intro text could go here */}
                    <div className="mb-8 p-4 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-600">
                            Showing top {count} young billionaires
                        </div>
                        <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                            Updated: Real-time
                        </div>
                    </div>

                    <div className="space-y-4">
                        {billionaires.map((b, index) => (
                            <PRCard
                                key={b.id}
                                billionaire={b}
                                rank={index + 1}
                                colorClass="text-trail-blue"
                            />
                        ))}
                        {billionaires.length === 0 && (
                            <div className="text-center py-12 text-gray-500 italic">
                                No rising stars found in the database.
                            </div>
                        )}
                    </div>

                    {/* Footer CTA */}
                    <div className="text-center py-12">
                        <button className="px-8 py-4 bg-trail-blue text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all font-sans">
                            Load More Candidates
                        </button>
                    </div>

                    {/* Bottom Sponsorship - Dark */}
                    <div className="bg-gray-900 text-white rounded-2xl p-6 sm:p-8 border-2 border-trail-blue mt-8">
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <h3 className="text-xl sm:text-2xl font-black font-display">Want to be featured in our Rising Stars list?</h3>
                            <div className="flex gap-3">
                                <a href="#" className="px-6 py-3 bg-trail-blue text-white font-bold rounded-lg hover:bg-blue-700 whitespace-nowrap font-sans">
                                    Submit Profile
                                </a>
                                <a href="#" className="px-6 py-3 bg-gray-800 text-white font-bold rounded-lg hover:bg-gray-700 border border-gray-700 whitespace-nowrap font-sans">
                                    Sponsorship Info
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    )
}
