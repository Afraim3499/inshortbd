import { getBillionaires } from '@/app/actions/billionaires/get'
import { FinanceHeader } from '@/components/finance/finance-header'
import { PRHero } from '@/components/finance/pr/pr-hero'
import { SponsorshipBanner } from '@/components/finance/pr/sponsorship-banner'
import { PRCard } from '@/components/finance/pr/pr-card'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Women Breaking Billions: Power List - The Trail Finance',
    description: 'Self-made female billionaires, investors, and entrepreneurs leading the future of finance.',
}

export const revalidate = 300 // 5 minutes

export default async function WomenBillionsPage() {
    // Fetch up to 100 female billionaires
    const { billionaires } = await getBillionaires({
        gender: 'female',
        sortBy: 'net_worth',
        limit: 100,
    })

    // Calculate Stats
    const count = billionaires.length

    // Total wealth in billions
    const totalWealthVal = billionaires.reduce((acc, curr) => acc + curr.net_worth_usd, 0)
    const totalWealthStr = `$${(totalWealthVal / 100000000000).toFixed(1)}B`

    // Self Made %
    const selfMadeCount = billionaires.filter(b => b.is_self_made).length
    const selfMadePct = count > 0 ? Math.round((selfMadeCount / count) * 100) : 0

    // New this year (mock calculation or random for demo if data missing)
    const newThisYear = Math.round(count * 0.12) // ~12% new

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                <PRHero
                    title="Women Breaking Billions"
                    subtitle="Self-made female billionaires, investors, and entrepreneurs leading the future of finance"
                    stats={{
                        count,
                        wealth: totalWealthStr,
                        selfMadePct,
                        newThisYear
                    }}
                    badgeText="POWER LIST 2025"
                    colorClass="text-purple-400"
                />

                <SponsorshipBanner
                    text="Partner with the Women Breaking Billions list"
                    ctaText="Partnership Info →"
                />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

                    <div className="mb-8 p-4 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-600">
                            Showing {count} leading women in finance
                        </div>
                        <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                            Updated: Real-time
                        </div>
                    </div>

                    <div className="space-y-4">
                        {billionaires.map((b, index) => (
                            <PRCard
                                key={b.id}
                                billionaire={b}
                                rank={index + 1}
                                colorClass="text-purple-600"
                            />
                        ))}
                        {billionaires.length === 0 && (
                            <div className="text-center py-12 text-gray-500 italic">
                                No female billionaires found in the database.
                            </div>
                        )}
                    </div>

                    {/* Bottom Sponsorship - Modified for this segment */}
                    <div className="bg-gray-900 text-white rounded-2xl p-6 sm:p-8 border-2 border-purple-500 mt-8">
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <h3 className="text-xl sm:text-2xl font-black font-display">Feature your brand with global leaders</h3>
                            <div className="flex gap-3">
                                <a href="#" className="px-6 py-3 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700 whitespace-nowrap font-sans">
                                    Become a Partner
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    )
}
