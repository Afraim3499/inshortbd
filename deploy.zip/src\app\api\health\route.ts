import { NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'

/**
 * Health check endpoint for Docker and monitoring
 * Returns 200 if service is healthy, 503 if unhealthy
 */
export async function GET() {
  try {
    // Check database connectivity
    const supabase = await createClient()
    const { error } = await (supabase
      .from('site_config') as any)
      .select('id')
      .limit(1)
      .single()

    // If database query fails, service is unhealthy
    if (error && error.code !== 'PGRST116') {
      // PGRST116 is "no rows returned" which is acceptable
      return NextResponse.json(
        {
          status: 'unhealthy',
          database: 'error',
          error: error.message,
        },
        { status: 503 }
      )
    }

    // All checks passed
    return NextResponse.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      database: 'connected',
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: 'unhealthy',
        error: error instanceof Error ? error.message : 'Unknown error',
      },
      { status: 503 }
    )
  }
}





