'use client'

import { LineChart, Line, ResponsiveContainer, YAxis } from 'recharts'

interface MarketIndexCardProps {
    name: string
    value: string
    change: string
    changePercent: string
    isPositive: boolean
    color: 'green' | 'blue' | 'purple' | 'red'
    data: number[]
    description: string
    tag: string
}

export function MarketIndexCard({
    name,
    value,
    change,
    changePercent,
    isPositive,
    color,
    data,
    description,
    tag
}: MarketIndexCardProps) {

    // Map color names to hex values for Recharts
    const colorMap = {
        green: '#22C55E',
        blue: '#2563EB',
        purple: '#9333EA',
        red: '#EF4444'
    }

    const chartColor = colorMap[color] || '#666666'

    // Format data for Recharts
    const chartData = data.map((val, idx) => ({ i: idx, val }))

    const borderColorClass = {
        green: 'border-green-200',
        blue: 'border-blue-200',
        purple: 'border-purple-200',
        red: 'border-gray-200' // Russell 2000 styling in template was gray border even if red text? Actually red accent usually.
    }[color] || 'border-gray-200'

    return (
        <div className={`bg-white rounded-3xl p-8 shadow-xl border-2 ${borderColorClass} hover:shadow-2xl transition-all duration-300 hover:scale-105`}>
            <div className="flex items-start justify-between mb-6">
                <div>
                    <div className="text-sm text-gray-500 uppercase tracking-wider mb-2 font-sans">{name}</div>
                    <div className="text-5xl font-black font-display tracking-tight text-gray-900">{value}</div>
                </div>
                <div className={`px-3 py-1 ${isPositive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'} rounded-full text-sm font-bold font-sans`}>
                    {changePercent}
                </div>
            </div>

            <div className="h-16 mb-4">
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData}>
                        <Line
                            type="monotone"
                            dataKey="val"
                            stroke={chartColor}
                            strokeWidth={2}
                            dot={false}
                            isAnimationActive={true}
                        />
                        <YAxis domain={['dataMin', 'dataMax']} hide={true} />
                    </LineChart>
                </ResponsiveContainer>
            </div>

            <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600 font-sans">{change}</span>
                <span className={`font-bold font-sans ${isPositive ? 'text-' + color + '-600' : 'text-gray-500'}`}>
                    {tag}
                </span>
            </div>
        </div>
    )
}
