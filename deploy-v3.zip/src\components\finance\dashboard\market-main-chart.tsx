'use client'

import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid, AreaChart, Area } from 'recharts'
import { useState } from 'react'

export function MarketMainChart() {
    const [range, setRange] = useState('1D')

    // Mock Data Generator roughly matching the S&P 500 line
    const data = [
        { time: '9:30', val: 4850 },
        { time: '10:00', val: 4870 },
        { time: '10:30', val: 4860 },
        { time: '11:00', val: 4880 },
        { time: '11:30', val: 4900 },
        { time: '12:00', val: 4890 },
        { time: '12:30', val: 4910 },
        { time: '13:00', val: 4920 },
        { time: '13:30', val: 4930 },
        { time: '14:00', val: 4950 },
        { time: '9:30', val: 4987 },
    ]

    return (
        <div className="bg-white rounded-3xl p-8 shadow-xl">
            <div className="flex flex-col sm:flex-row items-center justify-between mb-8 gap-4">
                <div>
                    <h2 className="text-3xl font-black mb-1 font-display">S&P 500</h2>
                    <p className="text-gray-600 font-sans">Intraday Performance</p>
                </div>
                <div className="flex gap-2">
                    {['1D', '5D', '1M', '1Y'].map(r => (
                        <button
                            key={r}
                            onClick={() => setRange(r)}
                            className={`px-4 py-2 rounded-xl text-sm font-bold font-sans transition-colors ${range === r
                                    ? 'bg-trail-blue text-white'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                        >
                            {r}
                        </button>
                    ))}
                </div>
            </div>
            <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={data}>
                        <defs>
                            <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#2563EB" stopOpacity={0.1} />
                                <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
                            </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                        <XAxis
                            dataKey="time"
                            axisLine={false}
                            tickLine={false}
                            tick={{ fill: '#6B7280', fontSize: 12 }}
                            dy={10}
                        />
                        <YAxis
                            domain={['dataMin - 10', 'dataMax + 10']}
                            axisLine={false}
                            tickLine={false}
                            tick={{ fill: '#6B7280', fontSize: 12 }}
                            dx={-10}
                        />
                        <Tooltip
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                            itemStyle={{ color: '#2563EB', fontWeight: 'bold' }}
                        />
                        <Area
                            type="monotone"
                            dataKey="val"
                            stroke="#2563EB"
                            fillOpacity={1}
                            fill="url(#colorVal)"
                            strokeWidth={3}
                        />
                    </AreaChart>
                </ResponsiveContainer>
            </div>
        </div>
    )
}
