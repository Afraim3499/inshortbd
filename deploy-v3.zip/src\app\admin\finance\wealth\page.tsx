'use client'

import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { Loader2, Edit, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'

export default function WealthPlaybookListPage() {
    const supabase = createClient()

    const { data: strategies = [], isLoading } = useQuery({
        queryKey: ['playbook-strategies'],
        queryFn: async () => {
            const { data, error } = await supabase
                .from('playbook_strategies')
                .select('*')
                .order('order_index', { ascending: true })
            if (error) throw error
            return data
        }
    })

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between gap-4 items-center">
                <h2 className="text-2xl font-bold font-heading">Wealth Playbook</h2>
                {/* Usually fixed to 7 steps, so maybe no Add button unless we want dynamic steps? 
                    The fallback data shows 7 steps. Let's allow editing existing ones mainly. 
                    Or if empty, maybe a button to 'Seed Defaults'.
                */}
            </div>

            <div className="p-4 bg-blue-50 text-blue-800 rounded-md flex items-start gap-3">
                <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                <div>
                    <h4 className="font-bold">Playbook Structure</h4>
                    <p className="text-sm mt-1">
                        The Playbook is designed as a sequential 7-step guide. Edit the steps below to change the content that users unlock.
                    </p>
                </div>
            </div>

            <div className="border rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead className="w-16">Step</TableHead>
                            <TableHead>Strategy Title</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            <TableRow>
                                <TableCell colSpan={4} className="h-24 text-center">
                                    <Loader2 className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                                </TableCell>
                            </TableRow>
                        ) : strategies.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={4} className="h-24 text-center text-gray-500">
                                    No strategies found. The system uses fallbacks currently.
                                    <br />
                                    <Link href="/admin/finance/wealth/new">
                                        <Button variant="link">Create First Strategy</Button>
                                    </Link>
                                </TableCell>
                            </TableRow>
                        ) : (
                            strategies.map((s: any) => (
                                <TableRow key={s.id}>
                                    <TableCell className="font-bold">#{s.order_index}</TableCell>
                                    <TableCell className="font-medium">{s.title}</TableCell>
                                    <TableCell>
                                        <Badge variant={s.is_locked ? "outline" : "default"} className={s.is_locked ? "text-gray-500" : "bg-green-600"}>
                                            {s.is_locked ? 'Locked' : 'Free / Open'}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Link href={`/admin/finance/wealth/${s.id}`}>
                                            <Button variant="ghost" size="sm">
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}
