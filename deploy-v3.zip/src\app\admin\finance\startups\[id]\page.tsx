'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { TiptapEditor } from '@/components/editor/tiptap'
import { Loader2, ArrowLeft } from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import Link from 'next/link'
import { ImageUpload } from '@/components/editor/image-upload'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { Sparkles } from "lucide-react"
import { parseStartupImportText, parseCurrencyString } from "@/lib/finance/import-parser"

export default function StartupEditorPage() {
    const params = useParams()
    const id = params.id as string
    const isNew = id === 'new'
    const router = useRouter()
    const supabase = createClient()
    const queryClient = useQueryClient()

    // Company Info
    const [companyName, setCompanyName] = useState('')
    const [slug, setSlug] = useState('')
    const [founderName, setFounderName] = useState('')
    const [foundedYear, setFoundedYear] = useState<number | ''>('')
    const [region, setRegion] = useState('')
    const [industry, setIndustry] = useState('')
    const [storyType, setStoryType] = useState('success')

    // Stats
    const [valuation, setValuation] = useState<number | ''>('')
    const [raised, setRaised] = useState<number | ''>('')

    // Content Sections
    const [struggle, setStruggle] = useState<any>(null)
    const [breakthrough, setBreakthrough] = useState<any>(null)
    const [wisdom, setWisdom] = useState<any>(null)

    const [heroImage, setHeroImage] = useState<string | null>(null)
    const [isPublished, setIsPublished] = useState(false)
    const [error, setError] = useState('')

    // Smart Import
    const [isSmartImportOpen, setIsSmartImportOpen] = useState(false)
    const [smartImportText, setSmartImportText] = useState('')

    const handleSmartImport = () => {
        try {
            const startups = parseStartupImportText(smartImportText)
            if (startups.length > 0) {
                const s = startups[0]
                if (s.company_name) setCompanyName(s.company_name)
                if (s.slug) setSlug(s.slug)
                if (s.founder_name) setFounderName(s.founder_name)
                if (s.founded_year) setFoundedYear(s.founded_year)
                if (s.region) setRegion(s.region)
                if (s.industry) setIndustry(s.industry)

                // Map unicorn/success -> success, failure -> failure
                if (s.story_type) {
                    const normalized = s.story_type.toLowerCase().includes('failure') ? 'failure' : 'success'
                    setStoryType(normalized)
                }

                if (s.current_valuation_usd_raw) {
                    const val = parseCurrencyString(s.current_valuation_usd_raw)
                    setValuation(isNaN(val) ? 0 : val)
                }
                if (s.funding_raised_usd_raw) {
                    const raised = parseCurrencyString(s.funding_raised_usd_raw)
                    setRaised(isNaN(raised) ? 0 : raised)
                }

                // Append parsed content to editors if they are empty, or overwrite? 
                // Overwriting is cleaner for "import"
                if (s.struggle_section) setStruggle(`<p>${s.struggle_section.replace(/\n/g, '</br>')}</p>`)
                if (s.breakthrough_section) setBreakthrough(`<p>${s.breakthrough_section.replace(/\n/g, '</br>')}</p>`)
                if (s.wisdom_section) setWisdom(`<p>${s.wisdom_section.replace(/\n/g, '</br>')}</p>`)

                if (s.hero_image_url) setHeroImage(s.hero_image_url)

                setIsSmartImportOpen(false)
                setSmartImportText('')
            }
        } catch (e) {
            console.error(e)
            alert("Failed to parse startup text")
        }
    }

    // Fetch existing
    const { data: existingData, isLoading } = useQuery({
        queryKey: ['startup', id],
        queryFn: async () => {
            if (isNew) return null
            const { data, error } = await supabase.from('startup_stories').select('*').eq('id', id).single()
            if (error) throw error
            return data
        },
        enabled: !isNew
    })

    useEffect(() => {
        if (existingData) {
            setCompanyName(existingData.company_name)
            setSlug(existingData.slug)
            setFounderName(existingData.founder_name)
            setFoundedYear(existingData.founded_year || '')
            setRegion(existingData.region)
            setIndustry(existingData.industry)
            setStoryType(existingData.story_type)
            setValuation(existingData.current_valuation_usd || '')
            setRaised(existingData.funding_raised_usd || '')
            setHeroImage(existingData.hero_image_url)
            setIsPublished(existingData.is_published || false)

            setStruggle(existingData.struggle_section)
            setBreakthrough(existingData.breakthrough_section)
            setWisdom(existingData.wisdom_section)
        }
    }, [existingData])

    // Auto-slug
    useEffect(() => {
        if (isNew && companyName && !slug) {
            setSlug(companyName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''))
        }
    }, [companyName, isNew, slug])

    const saveMutation = useMutation({
        mutationFn: async () => {
            if (!companyName || !slug || !founderName) throw new Error("Company Name, Slug and Founder Name are required")

            const payload: any = {
                company_name: companyName,
                slug,
                founder_name: founderName,
                founded_year: foundedYear || null,
                region,
                industry,
                story_type: storyType,
                current_valuation_usd: valuation || null,
                funding_raised_usd: raised || null,
                hero_image_url: heroImage,
                is_published: isPublished,
                struggle_section: struggle,
                breakthrough_section: breakthrough,
                wisdom_section: wisdom,
                updated_at: new Date().toISOString()
            }

            if (isNew) {
                const { error } = await supabase.from('startup_stories').insert(payload)
                if (error) throw error
            } else {
                const { error } = await supabase.from('startup_stories').update(payload).eq('id', id)
                if (error) throw error
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['startups-list'] })
            router.push('/admin/finance/startups')
        },
        onError: (err: any) => setError(err.message)
    })

    if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>

    return (
        <div className="max-w-5xl mx-auto space-y-8 pb-12">
            <div className="flex items-center gap-4">
                <Link href="/admin/finance/startups">
                    <Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button>
                </Link>
                <h1 className="text-2xl font-bold font-heading">{isNew ? 'New Story' : 'Edit Story'}</h1>
            </div>

            <Dialog open={isSmartImportOpen} onOpenChange={setIsSmartImportOpen}>
                <DialogTrigger asChild>
                    <Button variant="outline" className="gap-2 border-emerald-500 text-emerald-600 hover:bg-emerald-50">
                        <Sparkles className="w-4 h-4" />
                        Smart Import
                    </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-[800px]">
                    <DialogHeader>
                        <DialogTitle>Smart Import Startup Story</DialogTitle>
                        <DialogDescription>
                            Paste the full story text below to automatically extract company details and narratives.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4 py-4">
                        <p className="text-sm text-gray-500">
                            Paste the full story text or data block here. Format:
                            <code>Company: Name ... The Struggle: ...</code>
                        </p>
                        <Textarea
                            value={smartImportText}
                            onChange={(e) => setSmartImportText(e.target.value)}
                            placeholder="[[STARTUP]] Company: Stripe Founder: Patrick Collison ..."
                            className="min-h-[400px] font-mono text-xs"
                        />
                    </div>
                    <DialogFooter>
                        <Button onClick={handleSmartImport}>Import Data</Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>

            {error && <div className="p-4 bg-red-50 text-red-600 rounded-md">{error}</div>}

            <div className="grid md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-8">
                    {/* Basic Info */}
                    <div className="p-6 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold text-lg">Company Data</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div><Label>Company Name</Label><Input value={companyName} onChange={e => setCompanyName(e.target.value)} /></div>
                            <div><Label>Slug</Label><Input value={slug} onChange={e => setSlug(e.target.value)} /></div>
                            <div><Label>Founder</Label><Input value={founderName} onChange={e => setFounderName(e.target.value)} /></div>
                            <div><Label>Founded Year</Label><Input type="number" value={foundedYear} onChange={e => setFoundedYear(Number(e.target.value))} /></div>
                        </div>
                    </div>

                    {/* Story Sections */}
                    <div className="space-y-6">
                        <div>
                            <h3 className="font-heading font-bold text-xl mb-2 text-orange-700">The Struggle / Origin</h3>
                            <p className="text-sm text-gray-500 mb-2">How did they start? What challenges did they face?</p>
                            <TiptapEditor content={struggle} onChange={setStruggle} className="min-h-[200px]" />
                        </div>

                        <div>
                            <h3 className="font-heading font-bold text-xl mb-2 text-emerald-700">The Breakthrough</h3>
                            <p className="text-sm text-gray-500 mb-2">What was the turning point? The key strategy?</p>
                            <TiptapEditor content={breakthrough} onChange={setBreakthrough} className="min-h-[200px]" />
                        </div>

                        <div>
                            <h3 className="font-heading font-bold text-xl mb-2 text-blue-700">The Wisdom</h3>
                            <p className="text-sm text-gray-500 mb-2">Key lessons for other entrepreneurs.</p>
                            <TiptapEditor content={wisdom} onChange={setWisdom} className="min-h-[200px]" />
                        </div>
                    </div>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                    <div className="p-5 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Classification</h3>
                        <div>
                            <Label>Story Type</Label>
                            <select className="w-full border p-2 rounded" value={storyType} onChange={e => setStoryType(e.target.value)}>
                                <option value="success">Success Story</option>
                                <option value="success">Unicorn Deep Dive (mapped to Success)</option>
                                <option value="failure">Failure / Lesson</option>
                            </select>
                        </div>
                        <div><Label>Region</Label><Input value={region} onChange={e => setRegion(e.target.value)} placeholder="Southeast Asia" /></div>
                        <div><Label>Industry</Label><Input value={industry} onChange={e => setIndustry(e.target.value)} placeholder="Fintech" /></div>
                    </div>

                    <div className="p-5 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Financials</h3>
                        <div><Label>Valuation (USD)</Label><Input type="number" value={valuation} onChange={e => setValuation(Number(e.target.value))} /></div>
                        <div><Label>Total Raised (USD)</Label><Input type="number" value={raised} onChange={e => setRaised(Number(e.target.value))} /></div>
                    </div>

                    <div className="p-5 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Hero Image</h3>
                        {heroImage ? (
                            <div className="relative">
                                <img src={heroImage} className="w-full h-32 object-cover rounded" alt="Hero" />
                                <Button variant="destructive" size="sm" className="absolute top-2 right-2" onClick={() => setHeroImage(null)}>Remove</Button>
                            </div>
                        ) : (
                            <ImageUpload onUploadComplete={setHeroImage} />
                        )}
                    </div>

                    <div className="flex items-center gap-2 p-4 bg-gray-50 rounded-lg">
                        <input type="checkbox" id="pub" checked={isPublished} onChange={e => setIsPublished(e.target.checked)} className="h-4 w-4" />
                        <Label htmlFor="pub">Published</Label>
                    </div>

                    <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="w-full bg-orange-600 hover:bg-orange-700">
                        {saveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Story
                    </Button>
                </div>
            </div>
        </div>
    )
}
