import { createClient } from '@/utils/supabase/server'
import { NewsImage } from '@/components/news-image'
import { ViewTracker } from '@/components/view-tracker'
import { ArticleTracker } from '@/components/analytics/article-tracker'
import { SocialShare } from '@/components/social-share'
import { AuthorBio } from '@/components/author-bio'
import { RelatedArticles } from '@/components/related-articles'
import {
  ArticleStructuredData,
  BreadcrumbStructuredData,
} from '@/components/structured-data'
import { ReadingTime } from '@/components/reading-time'
import { NewsletterSignup } from '@/components/newsletter-signup'
import { CommentList } from '@/components/comments/comment-list'
import { CollectionNav } from '@/components/collections/collection-nav'
import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { BackToTop } from '@/components/back-to-top'
import { ReadingProgress } from '@/components/reading-progress'
import { TableOfContents } from '@/components/table-of-contents'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'
import { AdUnit } from '@/components/ads/ad-unit'
import { RelatedStories } from '@/components/news/related-stories'
import { getTrendingPosts } from '@/components/trending-posts'
import { generateHTML } from '@tiptap/html'
import StarterKit from '@tiptap/starter-kit'
import Image from '@tiptap/extension-image'
import Link from '@tiptap/extension-link'
import { TextStyle } from '@tiptap/extension-text-style' // Fixed named import
import { Color } from '@tiptap/extension-color'
import { sanitizeHtml } from '@/lib/sanitize'
import { getSiteUrl } from '@/lib/env'

async function getPost(slug: string) {
  const supabase = await createClient()
  const { data, error } = await (supabase
    .from('posts') as any)
    .select('*')
    .eq('slug', slug)
    .eq('status', 'published')
    .single()

  if (error || !data) {
    return null
  }

  return data as any
}

async function getAuthorName(authorId: string | null) {
  if (!authorId) return undefined
  const supabase = await createClient()
  const { data } = await (supabase
    .from('profiles') as any)
    .select('full_name, email')
    .eq('id', authorId)
    .single()

  const typedData = data as { full_name: string | null; email: string | null } | null
  return typedData?.full_name || typedData?.email || undefined
}

async function getAllPostSlugs() {
  try {
    const supabase = await createClient()
    const { data, error } = await (supabase
      .from('posts') as any)
      .select('slug')
      .eq('status', 'published')

    if (error) {
      console.error('Error fetching post slugs:', error)
      return []
    }

    const typedData = (data || []) as Array<{ slug: string }>
    return typedData.map((post: any) => ({ slug: post.slug }))
  } catch (error) {
    console.warn('Could not fetch post slugs for static generation:', error)
    return []
  }
}

export async function generateStaticParams() {
  const slugs = await getAllPostSlugs()
  return slugs
}

// Enable ISR: revalidate every 60 seconds
export const revalidate = 60

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>
}): Promise<Metadata> {
  const resolvedParams = await params
  const post = await getPost(resolvedParams.slug)

  if (!post) {
    return {
      title: 'Article Not Found',
    }
  }

  const siteUrl = getSiteUrl()
  const canonicalUrl = `${siteUrl}/news/${post.slug}`
  const authorName = await getAuthorName(post.author_id)

  // Build full image URL if needed
  let imageUrl = post.featured_image_url
  if (imageUrl && !imageUrl.startsWith('http')) {
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
    if (supabaseUrl) {
      const cleanUrl = imageUrl.startsWith('/') ? imageUrl.slice(1) : imageUrl
      const path = cleanUrl.startsWith('news-images/') ? cleanUrl : `news-images/${cleanUrl}`
      imageUrl = `${supabaseUrl}/storage/v1/object/public/${path}`
    }
  }

  return {
    title: `${post.title} | The Trail`,
    description: post.excerpt || post.title,
    alternates: {
      canonical: canonicalUrl,
    },
    openGraph: {
      title: post.title,
      description: post.excerpt || post.title,
      url: canonicalUrl,
      siteName: 'The Trail',
      images: imageUrl ? [{ url: imageUrl }] : [],
      type: 'article',
      publishedTime: post.published_at || undefined,
      authors: authorName ? [authorName] : undefined,
      section: post.category,
      tags: post.tags || undefined,
    },
    twitter: {
      card: 'summary_large_image',
      title: post.title,
      description: post.excerpt || post.title,
      images: imageUrl ? [imageUrl] : [],
      creator: '@TheTrailNews',
    },
  }
}


function renderContent(content: any) {
  if (!content) return null

  try {
    const html = generateHTML(content, [
      StarterKit,
      Image.configure({
        HTMLAttributes: {
          class: 'max-w-full h-auto my-8',
        },
      }),
      // Fix: Add TextStyle and Color to schema to prevent RangeError
      TextStyle,
      Color,
      Link.configure({
        openOnClick: false,
      }),
    ])

    // Add IDs to headings for Table of Contents
    let htmlWithIds = html.replace(
      /<h([2-3])>(.*?)<\/h\1>/gi,
      (match: string, level: string, text: string) => {
        const textContent = text.replace(/<[^>]*>/g, '').trim()
        const id = textContent
          .toLowerCase()
          .replace(/[^\w\s-]/g, '')
          .replace(/\s+/g, '-')
          .replace(/-+/g, '-')
          .trim()
        return `<h${level} id="${id}">${text}</h${level}>`
      }
    )

    // Convert blockquotes to pull quotes
    htmlWithIds = htmlWithIds.replace(
      /<blockquote>(.*?)<\/blockquote>/gi,
      '<blockquote class="pull-quote">$1</blockquote>'
    )

    const sanitizedHtml = sanitizeHtml(htmlWithIds)

    return (
      <div
        className="article-content"
        dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
      />
    )
  } catch (error) {
    console.error('Error rendering content:', error)
    return (
      <div className="p-4 bg-red-50 text-red-600 rounded-lg">
        <p>Error rendering article content. Please contact support.</p>
      </div>
    )
  }
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const resolvedParams = await params
  const post = await getPost(resolvedParams.slug)

  if (!post) {
    notFound()
  }

  // Fetch Author and Trending data
  // Prioritize manual author name > profile name > fallback
  const profileName = await getAuthorName(post.author_id)
  const authorName = post.author_name || profileName || 'The Trail Team'
  const trending = await getTrendingPosts()

  const siteUrl = getSiteUrl()

  return (
    <>
      <ArticleStructuredData post={post as any} authorName={authorName} siteUrl={siteUrl} />
      <BreadcrumbStructuredData
        items={[
          { name: 'Home', url: '/' },
          { name: post.category, url: `/category/${encodeURIComponent(post.category)}` },
          { name: post.title, url: `/news/${post.slug}` },
        ]}
        siteUrl={siteUrl}
      />
      <Navigation />
      <ReadingProgress />
      <ViewTracker postId={post.id} />
      <ArticleTracker postId={post.id} />

      <main id="main-content" tabIndex={-1} className="min-h-screen bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <article>
            <header className="mb-16">
              {/* Row 1: Centered Title & Meta */}
              <div className="text-center max-w-4xl mx-auto mb-12">
                <div className="flex items-center justify-center gap-3 text-sm font-medium text-muted-foreground mb-6 tracking-wide uppercase">
                  <span className="text-primary font-bold">{post.category}</span>
                  <span>•</span>
                  {post.published_at && (
                    <span>{new Date(post.published_at).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</span>
                  )}
                  <span>•</span>
                  <ReadingTime content={post.content} />
                </div>

                <h1 className="text-4xl md:text-5xl lg:text-6xl font-sans font-extrabold leading-tight text-foreground tracking-tight mb-6">
                  {post.title}
                </h1>
              </div>

              {/* Row 2: Split Layout (Context Left, Image Right) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
                {/* Left Column: Context */}
                <div className="lg:col-span-5 flex flex-col justify-center h-full space-y-8 order-2 lg:order-1">
                  {post.excerpt && (
                    <p className="text-xl md:text-2xl text-muted-foreground font-serif leading-relaxed border-l-4 border-primary pl-6">
                      {post.excerpt}
                    </p>
                  )}

                  <div className="flex items-center gap-4 py-6 border-y border-border/50">
                    <div className="h-12 w-12 rounded-full bg-accent/20 flex items-center justify-center text-lg font-bold text-accent">
                      {authorName?.[0] || 'A'}
                    </div>
                    <div>
                      <div className="font-bold text-foreground">{authorName || 'The Trail Team'}</div>
                      <div className="text-sm text-muted-foreground">Author</div>
                    </div>
                    <div className="ml-auto">
                      <SocialShare
                        url={`/news/${post.slug}`}
                        title={post.title}
                        description={post.excerpt || ''}
                      />
                    </div>
                  </div>

                  {post.tags && post.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {post.tags.map((tag: string) => (
                        <span key={tag} className="text-xs px-2 py-1 bg-secondary text-secondary-foreground rounded-md font-medium">#{tag}</span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Right Column: Featured Image */}
                <div className="lg:col-span-7 order-1 lg:order-2">
                  {post.featured_image_url ? (
                    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl shadow-lg border border-border/50 bg-muted">
                      <NewsImage
                        src={post.featured_image_url}
                        alt={post.title}
                        fill
                        className="object-cover transition-transform duration-700 hover:scale-105"
                        priority
                        sizes="(max-width: 768px) 100vw, (max-width: 1200px) 60vw, 800px"
                      />
                    </div>
                  ) : (
                    <div className="aspect-[2/1] bg-gradient-to-br from-muted to-accent/10 rounded-xl flex items-center justify-center border border-border/50">
                      <span className="text-muted-foreground font-medium">No Image Available</span>
                    </div>
                  )}
                </div>
              </div>
            </header>

            {/* Grid Layout: Article Content & Sidebar */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">

              {/* Main Content Column */}
              <div className="lg:col-span-8">
                <div className="prose prose-lg max-w-none font-serif text-slate-text leading-relaxed">
                  {renderContent(post.content)}
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-16">
                  <AuthorBio authorId={post.author_id} customName={authorName} />
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-12">
                  <CollectionNav postId={post.id} />
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-12">
                  <RelatedArticles
                    currentPostId={post.id}
                    category={post.category}
                    currentTags={post.tags || []}
                    limit={3}
                  />
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-12">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-base font-sans font-semibold mb-2 text-ink-black uppercase tracking-wide">Share this article</h3>
                      <p className="text-sm text-meta-gray font-serif">
                        Help spread the truth
                      </p>
                    </div>
                    <SocialShare
                      url={`/news/${post.slug}`}
                      title={post.title}
                      description={post.excerpt || undefined}
                    />
                  </div>
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-12">
                  <NewsletterSignup variant="inline" source="article" />
                </div>

                <div className="border-t-2 border-card-border pt-12 mt-12">
                  <CommentList postId={post.id} />
                </div>
              </div>

              {/* Sidebar Column - Sticky on Desktop, Stacked on Mobile */}
              <aside className="col-span-1 lg:col-span-4 space-y-8 mt-12 lg:mt-0 pt-12 lg:pt-0 border-t-2 border-card-border lg:border-t-0">
                <div className="sticky top-24 space-y-8">
                  <div className="bg-white border-2 border-card-border p-6 shadow-lg rounded-lg">
                    <TableOfContents content={post.content} />
                  </div>
                  <AdUnit placement="article_sidebar" />
                  <RelatedStories posts={trending} />
                </div>
              </aside>

            </div>
          </article>
        </div>
      </main>
      <Footer />
      <BackToTop />
    </>
  )
}
