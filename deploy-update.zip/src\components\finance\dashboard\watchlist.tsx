export function Watchlist() {
    return (
        <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-3xl p-6 border-2 border-trail-blue/20">
            <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-black font-display">My Watchlist</h3>
                <button className="w-8 h-8 bg-trail-blue rounded-lg flex items-center justify-center text-white hover:bg-blue-700 transition-colors">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
                    </svg>
                </button>
            </div>
            <div className="space-y-3">
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center justify-between">
                        <div>
                            <div className="font-black font-display">AAPL</div>
                            <div className="text-xs text-gray-500 font-sans">Apple Inc.</div>
                        </div>
                        <div className="text-right">
                            <div className="font-bold font-mono">$195.20</div>
                            <div className="text-xs text-green-600 font-bold font-sans">+4.1%</div>
                        </div>
                    </div>
                </div>
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center justify-between">
                        <div>
                            <div className="font-black font-display">MSFT</div>
                            <div className="text-xs text-gray-500 font-sans">Microsoft</div>
                        </div>
                        <div className="text-right">
                            <div className="font-bold font-mono">$405.15</div>
                            <div className="text-xs text-green-600 font-bold font-sans">+3.4%</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
