import { MarketNews } from '@/components/finance/market-news'

// ... imports remain the same ...
import { getBillionaireBySlug } from '@/app/actions/billionaires/get'
import { FinanceHeader } from '@/components/finance/finance-header'
import { ProfileHeader } from '@/components/finance/profile-header'
import { NetWorthBanner } from '@/components/finance/net-worth-banner'
import { QuickStats } from '@/components/finance/quick-stats'
import { Biography } from '@/components/finance/biography'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/utils/supabase/server'
import type { Metadata } from 'next'

// ... Metadata function remains the same ...

interface PageProps {
    params: Promise<{ slug: string }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
    const resolvedParams = await params
    const billionaire = await getBillionaireBySlug(resolvedParams.slug)

    if (!billionaire) {
        return {
            title: 'Billionaire Not Found - The Trail Finance',
        }
    }

    const netWorthBillions = (billionaire.net_worth_usd / 100000000000).toFixed(1)

    return {
        title: `${billionaire.name}: $${netWorthBillions}B Net Worth - The Trail Finance`,
        description: `Real-time net worth, portfolio holdings, and biography of ${billionaire.name}, ${billionaire.title}.`,
        openGraph: {
            images: billionaire.photo_url ? [billionaire.photo_url] : [],
        },
    }
}

export default async function BillionaireProfilePage({ params }: PageProps) {
    const resolvedParams = await params
    const billionaire = await getBillionaireBySlug(resolvedParams.slug)

    if (!billionaire) {
        notFound()
    }

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                <ProfileHeader billionaire={billionaire} />

                <NetWorthBanner billionaire={billionaire} />

                <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">

                        {/* LEFT: Stats Sidebar */}
                        <div className="lg:col-span-1 space-y-6">
                            <QuickStats billionaire={billionaire} />

                            {/* Latest News - Replaced Placeholder with Market Wire */}
                            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                                <h3 className="font-black text-xs uppercase tracking-wider mb-4 text-gray-500 font-sans">Market Context</h3>
                                <div className="space-y-4">
                                    <MarketNews />
                                    <div className="pt-2">
                                        <Link href="/finance/markets" className="text-xs text-blue-600 hover:underline font-medium">View Global Markets &rarr;</Link>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* RIGHT: Main Content */}
                        <div className="lg:col-span-2 space-y-6">
                            <Biography name={billionaire.name} biography={billionaire.biography} />
                        </div>

                    </div>
                </div>
            </main>
        </div>
    )
}
