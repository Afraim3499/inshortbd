import { createClient } from '@/utils/supabase/server'
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'

export async function MarketNews() {
    const supabase = await createClient()

    // Fetch latest news, strictly filtered for Market context
    const { data: posts } = await supabase
        .from('posts')
        .select('id, title, slug, created_at, category')
        .in('category', ['Business', 'Economy', 'Tech', 'Finance', 'Markets', 'Crypto', 'Forex'])
        .order('created_at', { ascending: false })
        .limit(6)

    return (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between">
                <h3 className="font-bold font-display text-lg">Market Wire</h3>
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" title="Live Updates"></span>
            </div>
            <div className="divide-y divide-gray-50">
                {posts?.map((post: { id: string; title: string; slug: string; created_at: string; category: string | null }) => (
                    <Link
                        key={post.id}
                        href={`/news/${post.slug}`}
                        className="block p-4 hover:bg-gray-50 transition-colors group"
                    >
                        <div className="flex justify-between items-start gap-2 mb-1">
                            <span className="text-[10px] font-bold uppercase text-trail-blue bg-blue-50 px-1.5 py-0.5 rounded">
                                {post.category || 'News'}
                            </span>
                            <span className="text-[10px] text-gray-400 whitespace-nowrap">
                                {formatDistanceToNow(new Date(post.created_at))} ago
                            </span>
                        </div>
                        <h4 className="font-bold text-sm text-gray-900 leading-snug group-hover:text-trail-blue transition-colors line-clamp-2">
                            {post.title}
                        </h4>
                    </Link>
                ))}
                {!posts?.length && (
                    <div className="p-6 text-center text-sm text-gray-400">
                        No recent wire news.
                    </div>
                )}
            </div>
            <div className="p-3 bg-gray-50 text-center">
                <Link href="/news" className="text-xs font-bold text-trail-blue hover:underline">
                    View All Market News
                </Link>
            </div>
        </div>
    )
}
