'use client'

import { Calendar } from 'lucide-react'

export function FilterBar() {
    const currentDate = new Date().toISOString().split('T')[0]

    return (
        <div className="bg-soft-wash border-b border-card-border sticky top-16 z-30 hidden md:block">
            <div className="max-w-[1400px] mx-auto px-6 py-3">
                <div className="flex flex-wrap items-center gap-3">
                    <span className="text-sm font-semibold text-ink-black font-sans">Filter:</span>

                    {/* Date Picker */}
                    <div className="flex items-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:border-trail-blue cursor-pointer transition-colors group">
                        <Calendar className="w-4 h-4 text-gray-500 group-hover:text-trail-blue" />
                        <input
                            type="date"
                            className="text-sm border-none focus:outline-none cursor-pointer text-gray-700 font-mono bg-transparent"
                            defaultValue={currentDate}
                        />
                    </div>

                    {/* Sort Options */}
                    <button className="px-4 py-2 bg-trail-blue text-white text-sm font-medium rounded-lg font-sans shadow-sm hover:bg-blue-700 transition-colors">Latest</button>
                    <button className="px-4 py-2 bg-white border border-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 text-gray-700 font-sans transition-colors">Most Popular</button>
                    <button className="px-4 py-2 bg-white border border-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 text-gray-700 font-sans transition-colors">Trending</button>
                    <button className="px-4 py-2 bg-white border border-gray-300 text-sm font-medium rounded-lg hover:bg-gray-50 text-gray-700 font-sans transition-colors">
                        <span className="inline-flex items-center gap-1">
                            🔥 Hot
                        </span>
                    </button>

                    {/* Category Filter */}
                    <select className="px-4 py-2 bg-white border border-gray-300 text-sm rounded-lg hover:border-trail-blue cursor-pointer text-gray-700 font-sans focus:outline-none">
                        <option>All Categories</option>
                        <option>Politics</option>
                        <option>Tech</option>
                        <option>Culture</option>
                        <option>Business</option>
                        <option>World</option>
                    </select>

                    {/* Time Range */}
                    <select className="px-4 py-2 bg-white border border-gray-300 text-sm rounded-lg hover:border-trail-blue cursor-pointer text-gray-700 font-sans focus:outline-none">
                        <option>Last 24 Hours</option>
                        <option>This Week</option>
                        <option>This Month</option>
                        <option>All Time</option>
                    </select>
                </div>
            </div>
        </div>
    )
}
