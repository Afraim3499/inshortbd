'use client'

import { useState } from 'react'
import type { MarketData } from '@/lib/finnhub'
import { ArrowUp, ArrowDown } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { cn } from '@/lib/utils'

interface MarketTabsProps {
    data: MarketData[]
}

export function MarketTabs({ data }: MarketTabsProps) {
    const [activeTab, setActiveTab] = useState<'all' | 'stock' | 'crypto' | 'forex'>('all')

    const filteredData = activeTab === 'all'
        ? data
        : data.filter(d => d.type === activeTab || (!d.type && activeTab === 'stock')) // Default to stock if undefined

    return (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden h-full flex flex-col">
            {/* Header / Tabs */}
            <div className="flex items-center border-b border-gray-100 bg-gray-50/50 p-2 gap-1">
                {['all', 'stock', 'crypto', 'forex'].map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab as any)}
                        className={cn(
                            "px-4 py-2 rounded-lg text-sm font-bold capitalize transition-all",
                            activeTab === tab
                                ? "bg-white text-trail-blue shadow-sm"
                                : "text-gray-500 hover:text-gray-900 hover:bg-gray-100"
                        )}
                    >
                        {tab}
                    </button>
                ))}
            </div>

            {/* List */}
            <div className="flex-1 overflow-y-auto min-h-[400px]">
                <table className="w-full">
                    <thead className="sticky top-0 bg-white border-b border-gray-100 text-xs uppercase text-gray-400 font-sans z-10">
                        <tr>
                            <th className="px-4 py-3 text-left">Symbol</th>
                            <th className="px-4 py-3 text-right">Price</th>
                            <th className="px-4 py-3 text-right">Chg %</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                        <AnimatePresence mode="popLayout">
                            {filteredData.map((asset) => (
                                <motion.tr
                                    key={asset.symbol}
                                    layout
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className="hover:bg-gray-50/50 transition-colors group cursor-pointer"
                                >
                                    <td className="px-4 py-3">
                                        <div className="font-bold font-mono text-gray-900 group-hover:text-trail-blue transition-colors">
                                            {asset.symbol}
                                        </div>
                                        <div className="text-[10px] text-gray-400 font-sans font-normal truncate max-w-[120px]">
                                            {asset.name}
                                        </div>
                                    </td>
                                    <td className="px-4 py-3 text-right font-mono text-sm text-gray-700">
                                        {asset?.price?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 }) ?? '--'}
                                    </td>
                                    <td className="px-4 py-3 text-right">
                                        <span className={cn(
                                            "inline-flex items-center px-2 py-0.5 rounded text-xs font-bold",
                                            asset.change_percent >= 0 ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                                        )}>
                                            {(asset?.change_percent ?? 0) >= 0 ? '+' : ''}{asset?.change_percent?.toFixed(2) ?? '0.00'}%
                                        </span>
                                    </td>
                                </motion.tr>
                            ))}
                        </AnimatePresence>
                    </tbody>
                </table>
                {filteredData.length === 0 && (
                    <div className="p-8 text-center text-gray-400 text-sm">
                        No assets found for this category.
                    </div>
                )}
            </div>
        </div>
    )
}
