import { createClient } from '@/utils/supabase/server'
import { getSiteUrl } from '@/lib/env'
import { CATEGORIES } from '@/lib/constants'

export default async function sitemap() {
  const baseUrl = getSiteUrl()

  const supabase = await createClient()

  // 1. Fetch Posts
  const { data: posts } = await supabase
    .from('posts')
    .select('slug, updated_at')
    .eq('status', 'published')

  const postUrls = (posts || []).map((post: { slug: string; updated_at: string | null }) => ({
    url: `${baseUrl}/news/${post.slug}`,
    lastModified: post.updated_at ? new Date(post.updated_at) : new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.7,
  }))

  // 2. Fetch Billionaires
  const { data: billionaires } = await supabase
    .from('billionaires')
    .select('slug, updated_at')
    .eq('is_active', true)

  const billionaireUrls = (billionaires || []).map((profile: { slug: string; updated_at: string | null }) => ({
    url: `${baseUrl}/finance/billionaires/${profile.slug}`,
    lastModified: profile.updated_at ? new Date(profile.updated_at) : new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }))

  // 3. Static Routes
  const staticRoutes = [
    '',
    '/search',
    '/finance',
    '/finance/markets',
    '/finance/rising-stars',
    '/finance/women-breaking-billions',
    '/finance/sponsorship',
    '/finance/playbook',
    '/finance/startups',
    '/about',
    '/contact',
    '/editorial-policy',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: route === '' ? 'daily' as const : 'weekly' as const,
    priority: route === '' ? 1 : 0.8,
  }))

  // 4. Categories
  const categoryUrls = CATEGORIES.map((category) => ({
    url: `${baseUrl}/category/${category.toLowerCase()}`,
    lastModified: new Date(),
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }))

  return [
    ...staticRoutes,
    ...categoryUrls,
    ...postUrls,
    ...billionaireUrls,
  ]
}

