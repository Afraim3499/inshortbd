import { createClient } from '@/utils/supabase/server'
import { FinanceHeader } from '@/components/finance/finance-header'
import { PlaybookHero } from '@/components/finance/playbook/hero'
import { ProgressTracker } from '@/components/finance/playbook/progress-tracker'
import { StrategyCard } from '@/components/finance/playbook/strategy-card'
import { MillionaireCalculator } from '@/components/finance/playbook/calculator'
import { NewsletterSignup } from '@/components/newsletter-signup'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'The Millionaire Playbook - 7 Strategies Used by the Wealthy - The Trail Finance',
    description: 'A comprehensive guide to building wealth from scratch, featuring interactive calculators and proven strategies.',
}

// Fallback data in case DB is empty or table doesn't exist yet
const FALLBACK_STRATEGIES = [
    { id: '1', order_index: 1, title: 'Pay Yourself First', is_locked: false, tags: [{ text: '✅ Easy', colorClass: 'bg-green-100 text-green-700' }], content: '<p><strong>The Strategy:</strong> Automatically transfer 20% of every paycheck to investments BEFORE paying any bills.</p>' },
    { id: '2', order_index: 2, title: 'The 3-Income Rule', is_locked: false, tags: [], content: '<p>Build 3 income streams.</p>' },
    { id: '3', order_index: 3, title: 'Real Estate Leverage', is_locked: true, tags: [] },
    { id: '4', order_index: 4, title: 'Tax Efficiency', is_locked: true, tags: [] },
    { id: '5', order_index: 5, title: 'Business Systems', is_locked: true, tags: [] },
    { id: '6', order_index: 6, title: 'Global Diversification', is_locked: true, tags: [] },
    { id: '7', order_index: 7, title: 'Legacy Planning', is_locked: true, tags: [] },
]

export default async function PlaybookPage() {
    const supabase = await createClient()

    // Fetch strategies
    const { data: strategies } = await (supabase
        .from('playbook_strategies') as any)
        .select('*')
        .order('order_index')

    const displayStrategies = (strategies && strategies.length > 0) ? strategies : FALLBACK_STRATEGIES

    return (
        <div className="min-h-screen bg-white">
            <FinanceHeader />

            <main>
                <PlaybookHero />

                <ProgressTracker currentStep={3} totalSteps={7} />

                <article className="max-w-5xl mx-auto px-6 py-16">
                    {displayStrategies.map((strategy: any) => (
                        <StrategyCard
                            key={strategy.id}
                            number={strategy.order_index}
                            title={strategy.title}
                            isLocked={strategy.is_locked}
                            tags={strategy.tags || []}
                            content={
                                strategy.content ? (
                                    <div dangerouslySetInnerHTML={{ __html: strategy.content }} className="prose max-w-none text-gray-700" />
                                ) : undefined
                            }
                        />
                    ))}

                    <MillionaireCalculator />

                </article>

                {/* CTA Section */}
                <section className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-20">
                    <div className="max-w-4xl mx-auto px-6 text-center">
                        <h3 className="text-5xl font-black mb-6 font-display">Ready to Build Your Fortune?</h3>
                        <p className="text-2xl text-gray-300 mb-10 font-serif">
                            Join 50,000+ readers getting weekly wealth strategies
                        </p>
                        <NewsletterSignup
                            variant="inline"
                            source="finance-playbook"
                        />
                    </div>
                </section>
            </main>
        </div>
    )
}
