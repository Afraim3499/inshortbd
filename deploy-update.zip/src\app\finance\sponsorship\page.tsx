import { FinanceHeader } from '@/components/finance/finance-header'
import { NewsletterSignup } from '@/components/newsletter-signup'
import { Check } from 'lucide-react'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Sponsorship & Partnership Opportunities - The Trail Finance',
    description: 'Partner with The Trail Finance to reach an engaged audience of investors, founders, and business leaders.',
}

export default function SponsorshipPage() {
    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                {/* Hero */}
                <div className="bg-gradient-to-r from-gray-900 to-gray-800 text-white py-20 px-6">
                    <div className="max-w-4xl mx-auto text-center">
                        <h1 className="text-5xl md:text-7xl font-black font-display mb-6 tracking-tight">
                            Partner with <span className="text-trail-blue">The Trail</span>
                        </h1>
                        <p className="text-xl md:text-2xl text-gray-300 font-serif">
                            Reach 1M+ monthly readers including founders, investors, and business leaders shaping the future of finance.
                        </p>
                    </div>
                </div>

                {/* Value Props */}
                <div className="max-w-7xl mx-auto px-6 py-16">
                    <div className="grid md:grid-cols-3 gap-8 mb-20">
                        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                            <div className="text-4xl mb-4">📊</div>
                            <h3 className="text-2xl font-black font-display mb-3">Premium Audience</h3>
                            <p className="text-gray-600 font-serif">High net-worth individuals, startup founders, and institutional investors.</p>
                        </div>
                        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                            <div className="text-4xl mb-4">🎯</div>
                            <h3 className="text-2xl font-black font-display mb-3">Targeted Reach</h3>
                            <p className="text-gray-600 font-serif">Feature your brand alongside billionaires, rising stars, and unicorn founders.</p>
                        </div>
                        <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                            <div className="text-4xl mb-4">✨</div>
                            <h3 className="text-2xl font-black font-display mb-3">Premium Placement</h3>
                            <p className="text-gray-600 font-serif">Exclusive sponsorship opportunities across our finance verticals.</p>
                        </div>
                    </div>

                    {/* Pricing Tiers */}
                    <h2 className="text-4xl font-black font-display mb-12 text-center">Partnership Packages</h2>
                    <div className="grid md:grid-cols-3 gap-8 mb-20">
                        {/* Silver */}
                        <div className="bg-white p-8 rounded-2xl shadow-sm border-2 border-gray-200">
                            <div className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-2">Silver</div>
                            <div className="text-4xl font-black mb-6">Contact Us</div>
                            <ul className="space-y-3 mb-8">
                                {[
                                    'Banner placement',
                                    'Newsletter mention',
                                    'Social media shoutout',
                                    '1-month campaign'
                                ].map(feature => (
                                    <li key={feature} className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                                        <span className="text-gray-700">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {/* Gold */}
                        <div className="bg-gradient-to-br from-yellow-50 to-yellow-100 p-8 rounded-2xl shadow-lg border-2 border-yellow-500 relative">
                            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-yellow-500 text-white px-4 py-1 rounded-full text-xs font-bold uppercase">
                                Popular
                            </div>
                            <div className="text-sm font-bold text-yellow-700 uppercase tracking-wider mb-2">Gold</div>
                            <div className="text-4xl font-black mb-6">Contact Us</div>
                            <ul className="space-y-3 mb-8">
                                {[
                                    'All Silver benefits',
                                    'List sponsorship (Rising Stars, WBB)',
                                    'Dedicated article feature',
                                    'Premium placement',
                                    '3-month campaign'
                                ].map(feature => (
                                    <li key={feature} className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                                        <span className="text-gray-900">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {/* Platinum */}
                        <div className="bg-gray-900 text-white p-8 rounded-2xl shadow-lg border-2 border-trail-blue">
                            <div className="text-sm font-bold text-trail-blue uppercase tracking-wider mb-2">Platinum</div>
                            <div className="text-4xl font-black mb-6">Contact Us</div>
                            <ul className="space-y-3 mb-8">
                                {[
                                    'All Gold benefits',
                                    'Exclusive category sponsor',
                                    'Custom content series',
                                    'Event partnerships',
                                    '6-12 month campaign'
                                ].map(feature => (
                                    <li key={feature} className="flex items-start gap-2">
                                        <Check className="w-5 h-5 text-trail-blue flex-shrink-0 mt-0.5" />
                                        <span className="text-gray-200">{feature}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    {/* CTA */}
                    <div className="bg-gradient-to-r from-trail-blue to-blue-600 text-white p-12 rounded-2xl text-center">
                        <h3 className="text-3xl font-black font-display mb-4">Ready to Partner?</h3>
                        <p className="text-xl text-blue-100 mb-8 font-serif">Get in touch to discuss custom packages and pricing.</p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                            <a
                                href="mailto:partnerships@trailheadlines.com?subject=Partnership%20Inquiry"
                                className="px-8 py-4 bg-white text-trail-blue font-bold rounded-xl hover:bg-gray-100 transition-colors shadow-lg font-sans"
                            >
                                Contact Partnerships Team
                            </a>
                            <a
                                href="mailto:sponsorships@trailheadlines.com?subject=Sponsorship%20Info%20Request"
                                className="px-8 py-4 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition-colors font-sans"
                            >
                                Request Media Kit
                            </a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    )
}
