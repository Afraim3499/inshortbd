'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { Plus, Search, Loader2, Edit, Trash2 } from 'lucide-react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'

export default function BillionairesListPage() {
    const supabase = createClient()
    const [search, setSearch] = useState('')

    const { data: billionaires = [], isLoading } = useQuery({
        queryKey: ['billionaires-list', search],
        queryFn: async () => {
            let query = supabase
                .from('billionaires')
                .select('*')
                .order('net_worth_usd', { ascending: false })

            if (search) {
                query = query.ilike('name', `%${search}%`)
            }

            const { data, error } = await query
            if (error) throw error
            return data
        }
    })

    const formatMoney = (amount: number) => {
        return `$${(amount / 1000000000).toFixed(1)}B`
    }

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between gap-4 items-center">
                <h2 className="text-2xl font-bold font-heading">Billionaires Index</h2>
                <Link href="/admin/finance/billionaires/new">
                    <Button className="w-full sm:w-auto">
                        <Plus className="mr-2 h-4 w-4" /> Add Profile
                    </Button>
                </Link>
            </div>

            <div className="flex items-center gap-2 max-w-sm">
                <Search className="h-4 w-4 text-gray-500" />
                <Input
                    placeholder="Search by name..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            <div className="border rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Rank</TableHead>
                            <TableHead>Name</TableHead>
                            <TableHead>Net Worth</TableHead>
                            <TableHead>Industry</TableHead>
                            <TableHead>Tags</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center">
                                    <Loader2 className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                                </TableCell>
                            </TableRow>
                        ) : billionaires.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center text-gray-500">
                                    No profiles found. Create one to get started.
                                </TableCell>
                            </TableRow>
                        ) : (
                            billionaires.map((b: any, index: number) => (
                                <TableRow key={b.id}>
                                    <TableCell className="font-mono text-gray-500">
                                        #{index + 1}
                                    </TableCell>
                                    <TableCell className="font-medium">
                                        <div className="flex items-center gap-3">
                                            {b.photo_url && (
                                                <img src={b.photo_url} alt={b.name} className="w-8 h-8 rounded-full object-cover" />
                                            )}
                                            {b.name}
                                        </div>
                                    </TableCell>
                                    <TableCell className="font-mono text-emerald-600 font-medium">
                                        {formatMoney(b.net_worth_usd)}
                                    </TableCell>
                                    <TableCell>{b.industry}</TableCell>
                                    <TableCell>
                                        <div className="flex gap-1 flex-wrap">
                                            {b.age_group === 'under-40' && <Badge variant="secondary" className="text-xs">Under 40</Badge>}
                                            {b.gender === 'female' && <Badge variant="outline" className="text-xs border-purple-200 text-purple-700 bg-purple-50">Women</Badge>}
                                            {b.is_self_made && <Badge variant="outline" className="text-xs">Self-Made</Badge>}
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Link href={`/admin/finance/billionaires/${b.id}`}>
                                            <Button variant="ghost" size="sm">
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}
