import type { StartupStoryExtended } from '@/types/finance.types'

interface StartupLessonsProps {
    lessons: StartupStoryExtended['lessons']
    variant: 'success' | 'failure'
}

export function StartupLessons({ lessons, variant }: StartupLessonsProps) {
    const isSuccess = variant === 'success'

    const containerClass = isSuccess
        ? 'bg-gradient-to-br from-green-500 to-emerald-600'
        : 'bg-gray-900'

    return (
        <div className={`${containerClass} text-white rounded-2xl p-8 sm:p-12 mb-20`}>
            <h2 className="font-display text-4xl sm:text-5xl font-black mb-8">
                {isSuccess ? 'Lessons from Building' : 'Lessons from the Wreckage'}
            </h2>

            <div className="space-y-8">
                {lessons.map((lesson, idx) => (
                    <div key={idx} className="border-l-4 border-white pl-6">
                        <h3 className="text-2xl font-black mb-3 font-display">{lesson.title}</h3>
                        <p className="text-lg opacity-90 font-sans">{lesson.content}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}
