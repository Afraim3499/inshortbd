import { TiptapRenderer } from '@/components/content/tiptap-renderer'

interface BiographyProps {
    name: string
    biography: any // TipTap JSON content
}

export function Biography({ name, biography }: BiographyProps) {
    // If no biography, show a placeholder
    if (!biography) {
        return (
            <article className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
                <h2 className="font-display text-3xl sm:text-4xl font-black mb-6">The Journey</h2>
                <p className="text-gray-500 italic">Biography content coming soon...</p>
            </article>
        )
    }

    return (
        <article className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
            <h2 className="font-display text-3xl sm:text-4xl font-black mb-6">The Journey</h2>
            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:font-bold prose-p:font-serif prose-p:text-gray-700">
                <TiptapRenderer content={biography} />
            </div>
        </article>
    )
}
