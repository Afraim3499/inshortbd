import type { HoldingWithCompany } from '@/types/finance.types'

interface HoldingsListProps {
    holdings: HoldingWithCompany[]
}

export function HoldingsList({ holdings }: HoldingsListProps) {
    if (!holdings || holdings.length === 0) {
        return (
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
                <h2 className="text-2xl font-black mb-6 font-display">Portfolio & Holdings</h2>
                <p className="text-gray-500 italic">No holdings data available.</p>
            </div>
        )
    }

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
            <h2 className="text-2xl font-black mb-6 font-display">Portfolio & Holdings</h2>

            <div className="space-y-4">
                {holdings.map((holding) => {
                    const company = holding.company
                    // Calculate value in Billions
                    const valueBillions = holding.current_value_usd
                        ? (holding.current_value_usd / 100000000000).toFixed(1)
                        : '0.0'

                    return (
                        <div key={holding.id} className="p-5 bg-gray-50 rounded-xl border border-gray-200">
                            <div className="flex items-start gap-4">
                                <div className="w-14 h-14 bg-gray-900 rounded-xl flex items-center justify-center text-white font-black text-2xl flex-shrink-0 font-display">
                                    {company.name.charAt(0)}
                                </div>
                                <div className="flex-1 min-w-0">
                                    <div className="font-black text-xl mb-1 font-display">{company.name}</div>
                                    <div className="text-sm text-gray-600 mb-3 font-sans">
                                        {company.industry} • Founded {company.founded_year}
                                    </div>
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm font-sans">
                                        <div className="px-3 py-2 bg-white rounded-lg border border-gray-200">
                                            <div className="text-xs text-gray-500 mb-1">Ownership</div>
                                            <div className="font-black">{holding.ownership_percentage}%</div>
                                        </div>
                                        <div className="px-3 py-2 bg-white rounded-lg border border-gray-200">
                                            <div className="text-xs text-gray-500 mb-1">Shares</div>
                                            <div className="font-black">
                                                {holding.shares_count ? holding.shares_count.toLocaleString() : '-'}
                                            </div>
                                        </div>
                                        <div className="px-3 py-2 bg-white rounded-lg border border-gray-200">
                                            <div className="text-xs text-gray-500 mb-1">Value</div>
                                            <div className="font-black">${valueBillions}B</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )
                })}
            </div>
        </div>
    )
}
