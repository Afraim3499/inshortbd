import { cn } from '@/lib/utils'

interface MarketSignalProps {
    symbol: string
    changePercent: number
}

export function MarketSignal({ symbol, changePercent }: MarketSignalProps) {
    // Simple logic: > 0.5% Strong Buy, > 0% Buy, < -0.5% Strong Sell, < 0% Sell
    let signal = 'NEUTRAL'
    let color = 'bg-gray-500'
    let text = 'text-gray-500'
    let score = 50 // 0 to 100

    if (changePercent > 1.0) {
        signal = 'STRONG BUY'
        color = 'bg-green-600'
        text = 'text-green-600'
        score = 90
    } else if (changePercent > 0) {
        signal = 'BUY'
        color = 'bg-green-500'
        text = 'text-green-500'
        score = 65
    } else if (changePercent < -1.0) {
        signal = 'STRONG SELL'
        color = 'bg-red-600'
        text = 'text-red-600'
        score = 10
    } else if (changePercent < 0) {
        signal = 'SELL'
        color = 'bg-red-500'
        text = 'text-red-500'
        score = 35
    }

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-500 text-xs uppercase tracking-wider mb-4">Technical Analysis ({symbol})</h3>

            <div className="flex items-center justify-between mb-4">
                <span className={cn("text-2xl font-black font-display", text)}>
                    {signal}
                </span>
                <span className="font-mono text-sm font-bold text-gray-400">1D Interval</span>
            </div>

            {/* Gauge Bar */}
            <div className="relative h-4 bg-gray-100 rounded-full overflow-hidden w-full mb-2">
                {/* Zones */}
                <div className="absolute left-0 top-0 bottom-0 w-[33%] bg-red-100 border-r-2 border-white"></div>
                <div className="absolute left-[33%] top-0 bottom-0 w-[33%] bg-gray-100 border-r-2 border-white"></div>
                <div className="absolute right-0 top-0 bottom-0 w-[33%] bg-green-100"></div>

                {/* Marker */}
                <div
                    className={cn("absolute top-0 bottom-0 w-2 rounded transition-all duration-1000 ease-out", color)}
                    style={{ left: `${score}%` }}
                />
            </div>

            <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase">
                <span>Sell</span>
                <span>Neutral</span>
                <span>Buy</span>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-50 text-xs text-gray-500">
                <p>Based on moving averages and daily momentum.</p>
            </div>
        </div>
    )
}
