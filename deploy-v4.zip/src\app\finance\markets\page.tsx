import { FinanceHeader } from '@/components/finance/finance-header'
import { getMarketData, getIndicesHistory, getMarketPulse, type MarketData } from '@/lib/finnhub'
import { TickerTape } from '@/components/finance/ticker-tape'
import { MarketChart } from '@/components/finance/market-chart'
import { MarketTabs } from '@/components/finance/market-tabs'
import { MarketSignal } from '@/components/finance/market-signal'
import { MarketNews } from '@/components/finance/market-news'
import { MarketSectorGrid } from '@/components/finance/market-sector-grid'
import { Activity, Zap } from 'lucide-react'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Global Markets Terminal | The Trail Finance',
    description: 'Professional grade market data, crypto, forex, and real-time analysis.',
}

export const revalidate = 300 // 5 minutes

export default async function MarketsPage() {
    // Parallel data fetching
    const [marketData, sp500History, pulse] = await Promise.all([
        getMarketData(),
        getIndicesHistory('SPY'),
        getMarketPulse()
    ])

    const getData = (symbol: string) => marketData.find(d => d.symbol === symbol)
    const sp500 = getData('SPY')

    return (
        <div className="min-h-screen bg-gray-50 flex flex-col">
            <FinanceHeader />

            {/* 1. Ticker Tape */}
            <TickerTape data={marketData} />

            <main className="flex-1 max-w-[1600px] mx-auto w-full px-4 sm:px-6 lg:px-8 py-6">

                {/* Dashboard Header */}
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
                    <div>
                        <h1 className="text-2xl font-black text-gray-900 font-display flex items-center gap-2">
                            <Activity className="w-6 h-6 text-trail-blue" />
                            Global Markets Terminal <span className="text-xs bg-slate-900 text-white px-2 py-0.5 rounded ml-2">PRO</span>
                        </h1>
                        <p className="text-sm text-gray-500 font-sans mt-1">
                            Real-time cross-asset monitoring: Equities, Crypto, Forex.
                        </p>
                    </div>
                    <div className="flex items-center gap-3 text-xs font-bold bg-white text-gray-500 px-3 py-1.5 rounded-full shadow-sm border border-gray-100">
                        <span className="flex items-center gap-1.5">
                            <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                            N.Y. OPEN
                        </span>
                        <span className="w-px h-3 bg-gray-200"></span>
                        <span>LON OPEN</span>
                        <span className="w-px h-3 bg-gray-200"></span>
                        <span className="text-slate-300">TOK CLOSED</span>
                    </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

                    {/* LEFT COLUMN: Main Visuals (8 cols) */}
                    <div className="lg:col-span-8 space-y-6">

                        {/* Main Chart Card */}
                        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 h-[420px] flex flex-col">
                            <div className="flex items-center justify-between mb-4">
                                <div>
                                    <div className="flex items-center gap-2">
                                        <h2 className="text-lg font-bold font-display text-gray-900">S&P 500</h2>
                                        <span className="text-xs font-mono text-gray-400">SPY/USD</span>
                                    </div>
                                    <div className="flex items-baseline gap-3 mt-1">
                                        <span className="text-3xl font-black font-mono text-gray-900">
                                            {sp500?.price.toLocaleString() || "..."}
                                        </span>
                                        <span className={`text-sm font-bold font-mono ${sp500 && sp500.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                            {sp500 && sp500.change >= 0 ? '+' : ''}{sp500?.change} ({sp500?.change_percent.toFixed(2)}%)
                                        </span>
                                    </div>
                                </div>
                                <div className="hidden sm:flex gap-2">
                                    <button className="px-3 py-1 text-xs font-bold bg-gray-100 text-gray-900 rounded-md">1D</button>
                                    <button className="px-3 py-1 text-xs font-bold text-gray-400 hover:text-gray-900">1W</button>
                                    <button className="px-3 py-1 text-xs font-bold text-gray-400 hover:text-gray-900">1M</button>
                                </div>
                            </div>
                            <div className="flex-1 w-full min-h-[300px] overflow-hidden">
                                <MarketChart data={sp500History} color={sp500 && sp500.change >= 0 ? '#059669' : '#DC2626'} />
                            </div>
                        </div>

                        {/* Analysis Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Technical Signal */}
                            <MarketSignal symbol="S&P 500" changePercent={sp500?.change_percent || 0.1} />

                            {/* Quick Stats */}
                            <div className="bg-slate-900 rounded-2xl p-6 text-white relative overflow-hidden">
                                <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-trail-blue/20 to-transparent"></div>
                                <h3 className="flex items-center gap-2 font-bold text-sm text-slate-400 mb-4">
                                    <Zap className="w-4 h-4 text-yellow-400" />
                                    Market Pulse
                                </h3>
                                <div className="space-y-4 relative z-10">
                                    {/* Volatility */}
                                    <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                                        <span className="text-sm font-bold">Volatility (VIXY)</span>
                                        <span className={`font-mono text-lg ${pulse.vix.change_percent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                            {pulse.vix.price.toFixed(2)}
                                            <span className={`text-xs ml-2 ${pulse.vix.change_percent >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                {pulse.vix.change_percent >= 0 ? '+' : ''}{pulse.vix.change_percent.toFixed(2)}%
                                            </span>
                                        </span>
                                    </div>

                                    {/* Treasury (Price) */}
                                    <div className="flex justify-between items-center pb-3 border-b border-slate-800">
                                        <div className="flex flex-col">
                                            <span className="text-sm font-bold">7-10Y Bond (IEF)</span>
                                            <span className="text-[10px] text-slate-500">ETF Price</span>
                                        </div>
                                        <span className={`font-mono text-lg ${pulse.treasury.change_percent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                            ${pulse.treasury.price.toFixed(2)}
                                            <span className={`text-xs ml-2 ${pulse.treasury.change_percent >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                {pulse.treasury.change_percent >= 0 ? '+' : ''}{pulse.treasury.change_percent.toFixed(2)}%
                                            </span>
                                        </span>
                                    </div>

                                    {/* Oil */}
                                    <div className="flex justify-between items-center">
                                        <span className="text-sm font-bold">Crude Oil (USO)</span>
                                        <span className={`font-mono text-lg ${pulse.oil.change_percent >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                                            ${pulse.oil.price.toFixed(2)}
                                            <span className={`text-xs ml-2 ${pulse.oil.change_percent >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                                                {pulse.oil.change_percent >= 0 ? '+' : ''}{pulse.oil.change_percent.toFixed(2)}%
                                            </span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* New Sector Grid (Fill Gap + More Data) */}
                        <MarketSectorGrid data={marketData} />

                    </div>

                    {/* RIGHT COLUMN: Watchlist & News (4 cols) */}
                    <div className="lg:col-span-4 space-y-6 flex flex-col h-full">

                        {/* Tabbed Watchlist - Takes up vertical space */}
                        <div className="flex-1 min-h-[500px]">
                            <MarketTabs data={marketData} />
                        </div>

                        {/* News Feed */}
                        <MarketNews />

                    </div>
                </div>
            </main>
        </div>
    )
}
