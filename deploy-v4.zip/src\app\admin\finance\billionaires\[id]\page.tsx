'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { TiptapEditor } from '@/components/editor/tiptap'
import { Loader2, Save, ArrowLeft, Plus, Trash2 } from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import Link from 'next/link'
import { ImageUpload } from '@/components/editor/image-upload'
import { revalidatePathAction } from '@/app/actions/revalidate'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { parseBillionaireImportText, parseCurrencyString } from "@/lib/finance/import-parser"
import { Sparkles } from "lucide-react"

interface TimelineEvent {
    year: number
    label: string
    description: string
}

export default function BillionaireEditorPage() {
    const params = useParams()
    const id = params.id as string
    const isNew = id === 'new'
    const router = useRouter()
    const supabase = createClient()
    const queryClient = useQueryClient()

    const [name, setName] = useState('')
    const [slug, setSlug] = useState('')
    const [netWorth, setNetWorth] = useState<number>(0)
    const [industry, setIndustry] = useState('')
    const [country, setCountry] = useState('')
    const [age, setAge] = useState<number | ''>('')
    const [sourceOfWealth, setSourceOfWealth] = useState('') // comma separated for now
    const [bio, setBio] = useState<any>(null)
    const [photoUrl, setPhotoUrl] = useState<string | null>(null)
    const [isSelfMade, setIsSelfMade] = useState(false)
    const [gender, setGender] = useState('male')
    const [worldRank, setWorldRank] = useState<number | ''>('')
    const [wealthHistory, setWealthHistory] = useState<TimelineEvent[]>([])

    const [error, setError] = useState('')

    // Fetch existing data
    // Fetch existing data
    const { data: existingData, isLoading } = useQuery({
        queryKey: ['billionaire', id],
        queryFn: async () => {
            if (isNew) return null

            const { data, error } = await supabase
                .from('billionaires')
                .select('*')
                .eq('id', id)
                .single()

            if (error) throw error
            return data
        },
        enabled: true
    })

    // Populate form
    useEffect(() => {
        if (existingData) {
            const b = existingData
            setName(b.name)
            setSlug(b.slug)
            setNetWorth(b.net_worth_usd)
            setIndustry(b.industry)
            setCountry(b.country_code || '')
            setAge(b.age || '')
            setSourceOfWealth(b.source_of_wealth?.join(', ') || '')
            setBio(b.biography)
            setPhotoUrl(b.photo_url)
            setIsSelfMade(b.is_self_made || false)
            setGender(b.gender || 'male')
            setWorldRank(b.world_rank || '')
            setWealthHistory((b.wealth_history as TimelineEvent[]) || [])
        }
    }, [existingData])

    // Auto-slug
    useEffect(() => {
        if (isNew && name && !slug) {
            setSlug(name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''))
        }
    }, [name, isNew, slug])


    // We need to rewrite saveMutation heavily to handle the relations properly.
    // Let's just create a better save function inside the component for clarity.
    const handleSave = async () => {
        try {
            setError('')

            // 1. Save Billionaire Profile
            const payload: any = {
                name,
                slug,
                net_worth_usd: netWorth,
                industry,
                country_code: country || null,
                age: age || null,
                source_of_wealth: sourceOfWealth.split(',').map(s => s.trim()).filter(Boolean),
                biography: bio,
                photo_url: photoUrl,
                is_self_made: isSelfMade,
                gender,
                age_group: (age && age < 40) ? 'under-40' : (age && age < 60) ? '40-60' : '60+',
                world_rank: worldRank || null,
                wealth_history: wealthHistory,
                is_active: true
            }

            if (isNew) {
                const { data, error } = await supabase.from('billionaires').insert(payload).select().single()
                if (error) throw error
            } else {
                const { error } = await supabase.from('billionaires').update(payload).eq('id', id)
                if (error) throw error
            }

            await revalidatePathAction(`/finance/billionaires/${slug}`)
            queryClient.invalidateQueries({ queryKey: ['billionaires-list'] })
            queryClient.invalidateQueries({ queryKey: ['billionaire', id] })
            router.push('/admin/finance/billionaires')
        } catch (e: any) {
            setError(e.message)
        }
    }

    const addTimelineEvent = () => {
        setWealthHistory([...wealthHistory, { year: new Date().getFullYear(), label: '', description: '' }])
    }

    const removeTimelineEvent = (index: number) => {
        const newHistory = [...wealthHistory]
        newHistory.splice(index, 1)
        setWealthHistory(newHistory)
    }

    const updateTimelineEvent = (index: number, field: keyof TimelineEvent, value: any) => {
        const newHistory = [...wealthHistory]
        newHistory[index] = { ...newHistory[index], [field]: value }
        setWealthHistory(newHistory)
    }

    const [isSmartImportOpen, setIsSmartImportOpen] = useState(false)
    const [smartImportText, setSmartImportText] = useState('')

    const handleSmartImport = () => {
        try {
            const profiles = parseBillionaireImportText(smartImportText)
            if (profiles.length > 0) {
                const p = profiles[0] // Take first profile

                if (p.name) setName(p.name)
                if (p.slug) setSlug(p.slug)
                if (p.rank) setWorldRank(p.rank || '')
                if (p.net_worth_raw) {
                    const nw = parseCurrencyString(p.net_worth_raw)
                    setNetWorth(isNaN(nw) ? 0 : nw)
                }
                if (p.age) setAge(p.age || '')
                if (p.country_code) setCountry(p.country_code)
                if (p.industry) setIndustry(p.industry)
                if (p.source_of_wealth) setSourceOfWealth(p.source_of_wealth.join(', '))
                if (p.gender) setGender(p.gender.toLowerCase())

                // Handle Bio - if it's plain text, wrap in simple HTML paragraph for Tiptap
                if (p.biography) {
                    setBio(`<p>${p.biography.replace(/\n/g, '</br>')}</p>`)
                }

                // Handle Timeline
                if (p.wealth_timeline && p.wealth_timeline.length > 0) {
                    setWealthHistory(p.wealth_timeline.map(evt => ({
                        year: evt.year || new Date().getFullYear(),
                        label: evt.label || 'Milestone',
                        description: evt.description || ''
                    })))
                }

                setIsSmartImportOpen(false)
                setSmartImportText('')
            }
        } catch (error) {
            console.error("Smart import failed", error)
            alert("Failed to parse import text. Please check format.")
        }
    }

    if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>

    return (
        <div className="max-w-4xl mx-auto space-y-6 pb-12">
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                    <Link href="/admin/finance/billionaires">
                        <Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button>
                    </Link>
                    <h1 className="text-2xl font-bold font-heading">{isNew ? 'New Profile' : 'Edit Profile'}</h1>
                </div>

                <Dialog open={isSmartImportOpen} onOpenChange={setIsSmartImportOpen}>
                    <DialogTrigger asChild>
                        <Button variant="outline" className="gap-2 border-emerald-500 text-emerald-600 hover:bg-emerald-50">
                            <Sparkles className="w-4 h-4" />
                            Smart Import
                        </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-[600px]">
                        <DialogHeader>
                            <DialogTitle>Smart Import Profile</DialogTitle>
                            <div className="hidden">
                                <DialogDescription>Paste the profile text here to auto-fill the form.</DialogDescription>
                            </div>
                        </DialogHeader>
                        <div className="grid gap-4 py-4">
                            <p className="text-sm text-gray-500">
                                Paste the component text block (starting with [[PROFILE]]) here to auto-fill the form.
                            </p>
                            <Textarea
                                value={smartImportText}
                                onChange={(e) => setSmartImportText(e.target.value)}
                                placeholder="[[PROFILE]]..."
                                className="min-h-[300px] font-mono text-xs"
                            />
                        </div>
                        <DialogFooter>
                            <Button onClick={handleSmartImport}>Import Data</Button>
                        </DialogFooter>
                    </DialogContent>
                </Dialog>
            </div>

            {error && <div className="p-4 bg-red-50 text-red-600 rounded-md">{error}</div>}

            <div className="grid md:grid-cols-3 gap-6">

                {/* Main Form */}
                <div className="md:col-span-2 space-y-6">
                    <div className="space-y-4 p-6 bg-white rounded-lg border">
                        <h3 className="font-semibold text-lg">Identity</h3>
                        <div className="grid gap-4">
                            <div>
                                <Label htmlFor="fullName">Full Name</Label>
                                <Input id="fullName" name="fullName" value={name} onChange={e => setName(e.target.value)} placeholder="Elon Musk" />
                            </div>
                            <div>
                                <Label htmlFor="slug">Slug</Label>
                                <Input id="slug" name="slug" value={slug} onChange={e => setSlug(e.target.value)} placeholder="elon-musk" />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-4 p-6 bg-white rounded-lg border">
                        <h3 className="font-semibold text-lg">Biography</h3>
                        {/* Using a simplified container for Tiptap to match form styling */}
                        <div className="min-h-[300px] border rounded-md">
                            <TiptapEditor
                                content={bio}
                                onChange={setBio}
                                className="min-h-[300px]"
                            />
                        </div>
                    </div>

                    {/* WEALTH TIMELINE EDITOR */}
                    <div className="space-y-4 p-6 bg-white rounded-lg border">
                        <div className="flex items-center justify-between">
                            <h3 className="font-semibold text-lg">Wealth Timeline</h3>
                            <Button variant="outline" size="sm" onClick={addTimelineEvent}>
                                <Plus className="w-4 h-4 mr-2" /> Add Event
                            </Button>
                        </div>

                        {wealthHistory.length === 0 ? (
                            <p className="text-sm text-gray-500 italic">No timeline events added.</p>
                        ) : (
                            <div className="space-y-4">
                                {wealthHistory.map((event, idx) => (
                                    <div key={idx} className="grid gap-3 p-4 bg-gray-50 rounded border relative">
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            className="absolute top-2 right-2 text-red-500 hover:text-red-700 hover:bg-red-50"
                                            onClick={() => removeTimelineEvent(idx)}
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                        <div className="grid grid-cols-4 gap-4">
                                            <div className="col-span-1">
                                                <Label htmlFor={`year-${idx}`} className="text-xs">Year</Label>
                                                <Input
                                                    id={`year-${idx}`}
                                                    name={`year-${idx}`}
                                                    type="number"
                                                    value={event.year}
                                                    onChange={e => updateTimelineEvent(idx, 'year', Number(e.target.value))}
                                                />
                                            </div>
                                            <div className="col-span-3">
                                                <Label htmlFor={`label-${idx}`} className="text-xs">Label / Milestone</Label>
                                                <Input
                                                    id={`label-${idx}`}
                                                    name={`label-${idx}`}
                                                    value={event.label}
                                                    onChange={e => updateTimelineEvent(idx, 'label', e.target.value)}
                                                    placeholder="e.g. IPO Launch"
                                                />
                                            </div>
                                        </div>
                                        <div>
                                            <Label htmlFor={`description-${idx}`} className="text-xs">Description</Label>
                                            <Input
                                                id={`description-${idx}`}
                                                name={`description-${idx}`}
                                                value={event.description || ''}
                                                onChange={e => updateTimelineEvent(idx, 'description', e.target.value)}
                                                placeholder="Short detail..."
                                            />
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                    <div className="p-6 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Financials</h3>
                        <div>
                            <Label htmlFor="netWorth">Net Worth (USD)</Label>
                            <Input
                                id="netWorth"
                                name="netWorth"
                                type="number"
                                value={netWorth}
                                onChange={e => setNetWorth(Number(e.target.value))}
                                placeholder="e.g. 250000000000"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Raw number (e.g. 250000000000)</p>
                        </div>
                        <div>
                            <Label htmlFor="worldRank">World Rank</Label>
                            <Input
                                id="worldRank"
                                name="worldRank"
                                type="number"
                                value={worldRank}
                                onChange={e => setWorldRank(Number(e.target.value))}
                                placeholder="e.g. 1"
                            />
                        </div>
                        <div>
                            <Label htmlFor="sourceOfWealth">Source of Wealth</Label>
                            <Input
                                id="sourceOfWealth"
                                name="sourceOfWealth"
                                value={sourceOfWealth}
                                onChange={e => setSourceOfWealth(e.target.value)}
                                placeholder="Tesla, SpaceX"
                            />
                            <p className="text-xs text-muted-foreground mt-1">Comma separated</p>
                        </div>
                    </div>

                    <div className="p-6 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Demographics</h3>
                        <div>
                            <Label htmlFor="industry">Industry</Label>
                            <Input id="industry" name="industry" value={industry} onChange={e => setIndustry(e.target.value)} placeholder="Automotive" />
                        </div>
                        <div>
                            <Label htmlFor="countryCode">Country Code</Label>
                            <Input id="countryCode" name="countryCode" value={country} onChange={e => setCountry(e.target.value)} placeholder="US" maxLength={2} />
                        </div>
                        <div>
                            <Label htmlFor="age">Age</Label>
                            <Input id="age" name="age" type="number" value={age} onChange={e => setAge(Number(e.target.value))} placeholder="52" />
                        </div>
                        <div>
                            <Label htmlFor="gender">Gender</Label>
                            <select
                                id="gender"
                                name="gender"
                                className="w-full border rounded-md p-2 text-sm bg-background"
                                value={gender}
                                onChange={e => setGender(e.target.value)}
                            >
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                        <div className="flex items-center gap-2 pt-2">
                            <input
                                type="checkbox"
                                id="selfMade"
                                name="selfMade"
                                checked={isSelfMade}
                                onChange={e => setIsSelfMade(e.target.checked)}
                                className="h-4 w-4"
                            />
                            <Label htmlFor="selfMade">Self-Made</Label>
                        </div>
                    </div>

                    <div className="p-6 bg-white rounded-lg border space-y-4">
                        <h3 className="font-semibold">Photo</h3>
                        {photoUrl ? (
                            <div className="relative">
                                <img src={photoUrl} className="w-full h-48 object-cover rounded-md" alt="Preview" />
                                <Button variant="destructive" size="sm" className="absolute top-2 right-2" onClick={() => setPhotoUrl(null)}>Remove</Button>
                            </div>
                        ) : (
                            <ImageUpload onUploadComplete={setPhotoUrl} />
                        )}
                    </div>

                    <Button onClick={handleSave} className="w-full bg-emerald-600 hover:bg-emerald-700">
                        <Save className="mr-2 h-4 w-4" />
                        Save Profile
                    </Button>
                </div>
            </div>
        </div>
    )
}
