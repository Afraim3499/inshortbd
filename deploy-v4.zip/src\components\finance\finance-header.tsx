import Link from 'next/link'
import Image from 'next/image'
import { ArrowLeft, Home, LayoutGrid } from 'lucide-react'

export function FinanceHeader() {
    return (
        <header className="bg-white border-b sticky top-0 z-50 shadow-sm font-sans">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
                {/* Left: Back to Main Site */}
                <Link
                    href="/"
                    className="flex items-center gap-2 text-sm font-medium text-gray-500 hover:text-[#D4AF37] transition-colors group"
                >
                    <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                    <span className="hidden sm:inline">Back to News</span>
                </Link>

                {/* Center: Finance Brand */}
                <Link href="/finance" className="absolute left-1/2 -translate-x-1/2 flex items-center gap-2 group hover:opacity-80 transition-opacity">
                    <Image
                        src="/logo.svg"
                        alt="The Trail"
                        width={140}
                        height={32}
                        className="h-6 w-auto sm:h-8"
                        style={{ width: 'auto' }}
                        priority
                    />
                    <span className="hidden sm:inline-block font-black text-lg tracking-tight text-[#D4AF37]">FINANCE</span>
                </Link>

                {/* Right: Finance Hub / Actions */}
                <div className="flex items-center gap-4">
                    <Link
                        href="/finance"
                        className="text-gray-500 hover:text-[#D4AF37] transition-colors"
                        title="Finance Dashboard"
                    >
                        <LayoutGrid className="w-5 h-5" />
                    </Link>
                </div>
            </div>
        </header>
    )
}
