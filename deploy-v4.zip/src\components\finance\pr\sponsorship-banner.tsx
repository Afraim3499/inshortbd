interface SponsorshipBannerProps {
    text?: string
    ctaText?: string
    ctaLink?: string
}

export function SponsorshipBanner({
    text = "Want to be featured in our next list?",
    ctaText = "Learn More →",
    ctaLink = "#"
}: SponsorshipBannerProps) {
    return (
        <div className="bg-yellow-50 border-y border-yellow-200 py-3">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                        <div className="px-3 py-1 bg-yellow-500 text-white text-xs font-bold rounded-full font-sans uppercase">
                            Sponsored
                        </div>
                        <p className="text-sm font-semibold text-gray-700 font-sans">
                            {text}
                        </p>
                    </div>
                    <a
                        href={ctaLink}
                        className="px-6 py-2 bg-trail-blue text-white font-bold rounded-lg hover:bg-blue-700 text-sm whitespace-nowrap transition-colors font-sans"
                    >
                        {ctaText}
                    </a>
                </div>
            </div>
        </div>
    )
}
