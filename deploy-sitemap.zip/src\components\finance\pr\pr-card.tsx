import Link from 'next/link'
import Image from 'next/image'
import type { BillionaireWithHoldings } from '@/types/finance.types'

interface PRCardProps {
    billionaire: BillionaireWithHoldings
    rank: number
    description?: string
    colorClass?: string // Border/Text color
}

export function PRCard({ billionaire, rank, description, colorClass = 'text-trail-blue' }: PRCardProps) {
    const countryName = billionaire.country_code === 'US' ? 'USA'
        : billionaire.country_code === 'CN' ? 'China'
            : billionaire.country_code === 'IN' ? 'India'
                : billionaire.country_code

    const flagEmoji = billionaire.country_code === 'US' ? '🇺🇸'
        : billionaire.country_code === 'CN' ? '🇨🇳'
            : billionaire.country_code === 'IN' ? '🇮🇳'
                : '🌐'

    const netWorthBillions = (billionaire.net_worth_usd / 100000000000).toFixed(1)
    const changeToday = billionaire.net_worth_change_today
        ? (billionaire.net_worth_change_today / 100000000000).toFixed(0) // No decimal for compact look in this card
        : '0'
    const isPositiveToday = (billionaire.net_worth_change_today || 0) >= 0

    const borderColor = colorClass.includes('purple') ? 'hover:border-purple-600' : 'hover:border-[#D4AF37]'

    return (
        <div className={`bg-white rounded-2xl p-6 shadow-sm border-2 border-transparent transition-all duration-300 ${borderColor} mb-6`}>
            <div className="flex flex-col sm:flex-row gap-6">

                {/* Rank & Photo */}
                <div className="flex items-center gap-4 sm:flex-col sm:items-center sm:w-24 flex-shrink-0">
                    <div className={`text-4xl font-black ${colorClass === 'text-trail-blue' ? 'text-[#D4AF37]' : colorClass} font-display`}>
                        #{rank}
                    </div>
                    <div className="relative w-20 h-20">
                        <Image
                            src={billionaire.photo_url || '/placeholder-billionaire.jpg'}
                            alt={billionaire.name}
                            fill
                            className="rounded-full border-4 border-gray-100 object-cover"
                        />
                    </div>
                </div>

                <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3 mb-4">
                        <div>
                            <Link href={`/finance/billionaires/${billionaire.slug}`} className="group">
                                <h3 className="text-2xl font-black mb-2 font-display group-hover:text-[#D4AF37] transition-colors">
                                    {billionaire.name}
                                </h3>
                            </Link>
                            <div className="flex flex-wrap items-center gap-2 text-sm text-gray-600 mb-2 font-sans">
                                <span className={`font-bold ${colorClass === 'text-trail-blue' ? 'text-[#D4AF37]' : colorClass}`}>{billionaire.age} years old</span>
                                <span>•</span>
                                <span>{flagEmoji} {countryName}</span>
                                <span>•</span>
                                <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full font-semibold">
                                    {billionaire.industry}
                                </span>
                            </div>
                            <p className="text-gray-600 font-serif italic text-sm">
                                {billionaire.title}
                            </p>
                        </div>
                        <div className="text-right">
                            <div className={`text-3xl font-black ${colorClass === 'text-trail-blue' ? 'text-[#D4AF37]' : colorClass} mb-1 font-display`}>
                                ${netWorthBillions}B
                            </div>
                            <div className={`text-sm font-bold ${isPositiveToday ? 'text-green-600' : 'text-red-600'} font-sans`}>
                                {isPositiveToday ? '+' : ''}${Math.abs(Number(changeToday))}M this year
                            </div>
                        </div>
                    </div>

                    {(description || billionaire.biography) && (
                        <div className="bg-gray-50 rounded-xl p-4 mb-4">
                            <p className="text-sm text-gray-700 leading-relaxed font-serif">
                                {description || "A leading figure in global finance and innovation."}
                            </p>
                        </div>
                    )}

                    {/* Holdings Snippet */}
                    {billionaire.holdings && billionaire.holdings.length > 0 && (
                        <div className="border-t pt-3 border-gray-100">
                            <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 font-sans">
                                Primary Asset
                            </div>
                            <div className="flex flex-wrap gap-3">
                                <div className="flex items-center gap-2 px-3 py-2 bg-white rounded-lg border border-gray-200">
                                    <div className="w-8 h-8 bg-gray-900 rounded flex items-center justify-center text-white font-bold text-xs flex-shrink-0 font-display">
                                        {billionaire.holdings[0].company.name.charAt(0)}
                                    </div>
                                    <div>
                                        <div className="font-bold text-sm font-display">{billionaire.holdings[0].company.name}</div>
                                        <div className="text-xs text-gray-600 font-sans">
                                            {billionaire.holdings[0].ownership_percentage}% stake
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    )
}
