import type { BillionaireWithHoldings } from '@/types/finance.types'

interface QuickStatsProps {
    billionaire: BillionaireWithHoldings
}

export function QuickStats({ billionaire }: QuickStatsProps) {
    const countryName = billionaire.country_code === 'US' ? 'USA'
        : billionaire.country_code === 'CN' ? 'China'
            : billionaire.country_code === 'IN' ? 'India'
                : billionaire.country_code

    const flagEmoji = billionaire.country_code === 'US' ? '🇺🇸'
        : billionaire.country_code === 'CN' ? '🇨🇳'
            : billionaire.country_code === 'IN' ? '🇮🇳'
                : '🌐'

    // Mock primary source if array is empty
    const primarySource = billionaire.source_of_wealth && billionaire.source_of_wealth.length > 0
        ? billionaire.source_of_wealth[0]
        : 'Data Unavailable'

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
            <h3 className="font-black text-sm uppercase tracking-wider mb-4 text-gray-500 font-sans">
                Quick Facts
            </h3>
            <div className="space-y-3 text-sm font-sans">
                <div className="flex justify-between">
                    <span className="text-gray-600">World Rank</span>
                    <span className="font-black">#{billionaire.world_rank || '-'}</span>
                </div>
                <div className="h-px bg-gray-200"></div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Age</span>
                    <span className="font-bold">{billionaire.age}</span>
                </div>
                <div className="h-px bg-gray-200"></div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Country</span>
                    <span className="font-bold">{flagEmoji} {countryName}</span>
                </div>
                <div className="h-px bg-gray-200"></div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Industry</span>
                    <span className="font-bold">{billionaire.industry}</span>
                </div>
                <div className="h-px bg-gray-200"></div>
                <div className="flex justify-between">
                    <span className="text-gray-600">Source</span>
                    <span className="font-bold">{primarySource}</span>
                </div>
            </div>
        </div>
    )
}
