import { getBillionaires } from '@/app/actions/billionaires/get'
import { RisingStarsClient } from './client'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Rising Stars Under 40: Young Billionaires - The Trail Finance',
    description: 'The next generation of billionaires, unicorn founders, and wealth builders reshaping global finance.',
}

export const revalidate = 300 // 5 minutes

export default async function RisingStarsPage() {
    // Fetch up to 100 rising stars
    const { billionaires } = await getBillionaires({
        ageGroup: 'under-40',
        sortBy: 'net_worth',
        limit: 100,
    })

    // Calculate Stats
    const count = billionaires.length

    // Total wealth in billions
    const totalWealthVal = billionaires.reduce((acc, curr) => acc + curr.net_worth_usd, 0)
    const totalWealthStr = `$${(totalWealthVal / 100000000000).toFixed(1)}B`

    // Avg Age
    const totalAge = billionaires.reduce((acc, curr) => acc + (curr.age || 0), 0)
    const avgAge = count > 0 ? Math.round(totalAge / count) : 0

    // Self Made %
    const selfMadeCount = billionaires.filter(b => b.is_self_made).length
    const selfMadePct = count > 0 ? Math.round((selfMadeCount / count) * 100) : 0

    return (
        <RisingStarsClient
            billionaires={billionaires}
            stats={{
                count,
                wealth: totalWealthStr,
                avgAge,
                selfMadePct
            }}
        />
    )
}
