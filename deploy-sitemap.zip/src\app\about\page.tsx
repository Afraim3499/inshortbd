import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { Metadata } from 'next'
import { getSiteUrl } from '@/lib/env'

export const metadata: Metadata = {
  title: 'About Us - The Trail',
  description: 'Learn about The Trail - Follow the path to the truth. High performance, clean typology, information-dense news.',
  alternates: {
    canonical: `${getSiteUrl()}/about`,
  },
}

export default function AboutPage() {
  return (
    <>
      <Navigation />
      <main className="min-h-screen bg-background text-foreground">
        <div className="max-w-3xl mx-auto px-4 py-16">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-8">About The Trail</h1>

          <div className="prose prose-invert prose-zinc max-w-none space-y-6">
            <p className="text-xl text-muted-foreground leading-relaxed">
              <strong className="text-foreground">Follow the path to the truth.</strong>
            </p>

            <div className="space-y-4">
              <h2 className="text-2xl font-heading font-bold">Our Mission</h2>
              <p>
                The Trail is a modern news platform designed for digital natives who value speed,
                clarity, and unbiased information. We believe in presenting the facts without
                clutter, allowing readers to form their own conclusions.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-heading font-bold">Our Philosophy</h2>
              <p>
                We operate as a &quot;Terminal for Truth&quot; - a high-performance, information-dense
                platform that prioritizes content over decoration. Our clean, high-contrast interface
                reflects our commitment to clarity and focus, inspired by the legibility of classic print media.
              </p>
            </div>

            <div className="space-y-4">
              <h2 className="text-2xl font-heading font-bold">What We Stand For</h2>
              <ul className="list-disc list-inside space-y-2 ml-4">
                <li>Accuracy and verification in all reporting</li>
                <li>Transparency in editorial processes</li>
                <li>Speed without sacrificing quality</li>
                <li>Reader-focused design and experience</li>
                <li>Independent and unbiased journalism</li>
              </ul>
            </div>

            <div className="space-y-4 pt-8 border-t border-border">
              <h2 className="text-2xl font-heading font-bold">Get In Touch</h2>
              <p>
                Have questions, feedback, or story tips?{' '}
                <a href="/contact" className="text-accent hover:underline">
                  Contact us
                </a>{' '}
                or reach out on social media.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

