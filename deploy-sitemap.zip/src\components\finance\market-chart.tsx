'use client'

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { format } from 'date-fns'
import type { MarketCandle } from '@/lib/finnhub'

interface MarketChartProps {
    data: MarketCandle[]
    color?: string
}

export function MarketChart({ data, color = '#10b981' }: MarketChartProps) {
    if (!data || data.length === 0) return (
        <div className="h-64 flex items-center justify-center text-gray-400 bg-gray-50 rounded-xl italic">
            Chart data unavailable (Check API Plan)
        </div>
    )

    // Calculate dynamic domain to zoom in on price action
    const minPrice = Math.min(...data.map(d => d.close))
    const maxPrice = Math.max(...data.map(d => d.close))
    const padding = (maxPrice - minPrice) * 0.1

    return (
        <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                    <defs>
                        <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={color} stopOpacity={0.1} />
                            <stop offset="95%" stopColor={color} stopOpacity={0} />
                        </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis
                        dataKey="time"
                        tickFormatter={(str) => format(new Date(str), 'HH:mm')}
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: '#9ca3af', fontSize: 12 }}
                        minTickGap={30}
                    />
                    <YAxis
                        domain={[minPrice - padding, maxPrice + padding]}
                        orientation="right"
                        axisLine={false}
                        tickLine={false}
                        tick={{ fill: '#9ca3af', fontSize: 12 }}
                        tickFormatter={(num) => `$${num.toLocaleString()}`}
                        width={60}
                    />
                    <Tooltip
                        contentStyle={{
                            backgroundColor: '#fff',
                            borderRadius: '8px',
                            boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                            border: 'none'
                        }}
                        labelFormatter={(label) => format(new Date(label), 'MMM dd, HH:mm')}
                        formatter={(value: number) => [`$${value.toFixed(2)}`, 'Price']}
                    />
                    <Area
                        type="monotone"
                        dataKey="close"
                        stroke={color}
                        fillOpacity={1}
                        fill="url(#colorPrice)"
                        strokeWidth={2}
                    />
                </AreaChart>
            </ResponsiveContainer>
        </div>
    )
}
