import type { Metadata } from "next";
import { Inter, Merriweather, JetBrains_Mono } from "next/font/google";
import Script from "next/script";
import "./globals.css";
import { cn } from "@/lib/utils";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const merriweather = Merriweather({
  variable: "--font-merriweather",
  subsets: ["latin"],
  weight: ["300", "400", "700", "900"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    template: "%s | The Trail",
    default: "The Trail",
  },
  description: "Follow the path to the truth. High-end printed magazine aesthetic with zero eye strain and maximum legibility.",
  icons: {
    icon: '/favicon.ico?v=2',
    shortcut: '/favicon.ico?v=2',
    apple: '/favicon.ico?v=2',
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://trailheadlines.com',
    siteName: 'The Trail',
    title: 'The Trail',
    description: 'Follow the path to the truth. Independent journalism with high editorial standards.',
    images: [{
      url: 'https://trailheadlines.com/og-default.jpg',
      width: 1200,
      height: 630,
      alt: 'The Trail - Independent Journalism'
    }]
  },
  twitter: {
    card: 'summary_large_image',
    site: '@TheTrailNews',
    creator: '@TheTrailNews'
  },
  metadataBase: new URL('https://trailheadlines.com'),
};

import QueryProvider from "@/providers/QueryProvider";
import { SkipToContent } from "@/components/skip-to-content";
import { MobileBottomNav } from "@/components/mobile-bottom-nav";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={cn(
          "font-sans antialiased text-gray-900 bg-white pb-24 lg:pb-0",
          inter.variable,
          merriweather.variable,
          jetbrainsMono.variable
        )}
        suppressHydrationWarning
      >
        <SkipToContent />
        <QueryProvider>
          {children}
          <MobileBottomNav />
          {/* Google Analytics */}
          <Script
            strategy="afterInteractive"
            src="https://www.googletagmanager.com/gtag/js?id=G-2WW4JDK6Z0"
          />
          <Script
            id="google-analytics"
            strategy="afterInteractive"
            dangerouslySetInnerHTML={{
              __html: `
window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
gtag('js', new Date());
gtag('config', 'G-2WW4JDK6Z0');
`,
            }}
          />
        </QueryProvider>
      </body>
    </html>
  );
}
