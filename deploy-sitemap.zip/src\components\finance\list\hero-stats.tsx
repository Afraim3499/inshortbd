import Image from 'next/image'
import { getBillionaireStats } from '@/app/actions/billionaires/get'

export async function HeroStats() {
    const stats = await getBillionaireStats()

    const formattedWealth = (stats.totalWealth / 1000000000000).toFixed(1) + 'T'
    const formattedAvg = (stats.averageDetails / 1000000000).toFixed(1) + 'B'

    return (
        <div className="relative bg-black text-white py-12 sm:py-16 overflow-hidden">
            <div className="absolute inset-0 z-0">
                <Image
                    src="/billionaire.jpg"
                    alt="Billionaire Cover"
                    fill
                    className="object-cover opacity-40"
                    priority
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />
            </div>
            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6">
                <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-black mb-6 font-serif text-white">
                    Real-Time Billionaires
                </h1>
                <p className="text-lg sm:text-xl opacity-90 mb-8 max-w-2xl font-sans text-gray-200">
                    Track the world&apos;s richest people in real-time. Updated every 5 minutes based on stock market movements.
                </p>

                {/* Global Stats */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6">
                    <div className="bg-zinc-900/40 backdrop-blur-md rounded-2xl p-4 sm:p-6 border border-white/10">
                        <div className="text-3xl sm:text-4xl font-black mb-2 font-display text-[#D4AF37]">{stats.totalCount.toLocaleString()}</div>
                        <div className="text-sm opacity-75 font-sans text-gray-300">Total Billionaires</div>
                    </div>
                    <div className="bg-zinc-900/40 backdrop-blur-md rounded-2xl p-4 sm:p-6 border border-white/10">
                        <div className="text-3xl sm:text-4xl font-black mb-2 font-display text-[#D4AF37]">${formattedWealth}</div>
                        <div className="text-sm opacity-75 font-sans text-gray-300">Combined Wealth</div>
                    </div>
                    <div className="bg-zinc-900/40 backdrop-blur-md rounded-2xl p-4 sm:p-6 border border-white/10">
                        <div className="text-3xl sm:text-4xl font-black mb-2 font-display text-[#D4AF37]">{stats.countryCount}</div>
                        <div className="text-sm opacity-75 font-sans text-gray-300">Countries</div>
                    </div>
                    <div className="bg-zinc-900/40 backdrop-blur-md rounded-2xl p-4 sm:p-6 border border-white/10">
                        <div className="text-3xl sm:text-4xl font-black mb-2 font-display text-[#D4AF37]">${formattedAvg}</div>
                        <div className="text-sm opacity-75 font-sans text-gray-300">Avg Net Worth</div>
                    </div>
                </div>
            </div>
        </div>
    )
}
