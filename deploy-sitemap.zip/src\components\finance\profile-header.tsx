import Link from 'next/link'
import Image from 'next/image'
import type { BillionaireWithHoldings } from '@/types/finance.types'

interface ProfileHeaderProps {
    billionaire: BillionaireWithHoldings
}

export function ProfileHeader({ billionaire }: ProfileHeaderProps) {
    const countryName = billionaire.country_code === 'US' ? 'United States'
        : billionaire.country_code === 'CN' ? 'China'
            : billionaire.country_code === 'IN' ? 'India'
                : billionaire.country_code

    const flagEmoji = billionaire.country_code === 'US' ? '🇺🇸'
        : billionaire.country_code === 'CN' ? '🇨🇳'
            : billionaire.country_code === 'IN' ? '🇮🇳'
                : '🌐'

    return (
        <div className="bg-white border-b">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
                <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
                    <div className="relative w-24 h-24 sm:w-32 sm:h-32 flex-shrink-0">
                        <Image
                            src={billionaire.photo_url || '/placeholder-billionaire.jpg'}
                            alt={billionaire.name}
                            fill
                            sizes="(max-width: 640px) 96px, 128px"
                            className="rounded-full border-4 border-gray-100 shadow-lg object-cover"
                            unoptimized
                        />
                    </div>

                    <div className="flex-1 text-center sm:text-left">
                        <h1 className="font-display text-4xl sm:text-5xl font-black mb-2 font-serif">
                            {billionaire.name}
                        </h1>
                        <p className="text-lg sm:text-xl text-gray-600 mb-4 font-sans">
                            {billionaire.title}
                        </p>
                        <div className="flex flex-wrap justify-center sm:justify-start gap-2 text-sm text-gray-600 font-sans">
                            {billionaire.age && <span>{billionaire.age} years old</span>}
                            {billionaire.age && <span>•</span>}
                            <span>{flagEmoji} {countryName}</span>
                            <span>•</span>
                            <span>{billionaire.industry}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
