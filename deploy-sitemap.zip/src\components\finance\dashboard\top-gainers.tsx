export function TopGainers() {
    return (
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-3xl p-6 border-2 border-green-200">
            <h3 className="text-lg font-black mb-6 flex items-center gap-2 font-display">
                <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5.293 9.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 7.414V15a1 1 0 11-2 0V7.414L6.707 9.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
                    </svg>
                </div>
                Top Gainers
            </h3>
            <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-2">
                        <span className="font-black text-lg font-display">NVDA</span>
                        <span className="text-green-600 font-bold text-lg font-sans">+8.2%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 font-sans">$892.45</span>
                        <span className="text-gray-500 font-sans">+$67.89</span>
                    </div>
                </div>
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-2">
                        <span className="font-black text-lg font-display">AMD</span>
                        <span className="text-green-600 font-bold text-lg font-sans">+6.5%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 font-sans">$156.78</span>
                        <span className="text-gray-500 font-sans">+$9.58</span>
                    </div>
                </div>
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center justify-between mb-2">
                        <span className="font-black text-lg font-display">TSLA</span>
                        <span className="text-green-600 font-bold text-lg font-sans">+5.3%</span>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 font-sans">$245.30</span>
                        <span className="text-gray-500 font-sans">+$12.35</span>
                    </div>
                </div>
            </div>
        </div>
    )
}
