interface StrategyCardProps {
    number: number
    title: string
    tags?: { text: string, colorClass: string }[]
    content?: React.ReactNode
    isLocked?: boolean
    isExpanded?: boolean // Assuming we might want to toggle expansion, for now static as per template logic
}

export function StrategyCard({ number, title, tags, content, isLocked }: StrategyCardProps) {
    if (isLocked) {
        return (
            <div className="bg-gray-50 rounded-2xl p-8 border-2 border-gray-200 opacity-60">
                <div className="flex items-center gap-4 mb-4">
                    <div className="w-16 h-16 rounded-2xl bg-gray-300 text-white flex items-center justify-center font-black text-2xl font-display">
                        {number}
                    </div>
                    <div>
                        <h4 className="font-black text-xl text-gray-700 font-display">Strategy {number}</h4>
                        <p className="text-sm text-gray-500 font-sans">🔒 Complete previous strategies to unlock</p>
                    </div>
                </div>
            </div>
        )
    }

    return (
        <div className="mb-20">
            <div className="flex flex-col sm:flex-row items-start gap-4 sm:gap-6 mb-8">
                <div className="flex-shrink-0">
                    <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-3xl bg-gradient-to-br from-trail-blue to-blue-600 flex items-center justify-center shadow-2xl">
                        <span className="text-4xl sm:text-5xl font-black text-white font-display">{number}</span>
                    </div>
                </div>
                <div className="flex-1">
                    <h2 className="text-4xl sm:text-5xl font-display font-black mb-3 bg-gradient-to-r from-gray-900 to-trail-blue bg-clip-text text-transparent">
                        {title}
                    </h2>
                    {tags && (
                        <div className="flex flex-wrap items-center gap-2 sm:gap-4 text-sm font-sans">
                            {tags.map((tag, i) => (
                                <span key={i} className={`px-4 py-2 rounded-full font-bold ${tag.colorClass}`}>
                                    {tag.text}
                                </span>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-xl border-2 border-blue-100 transition-all hover:-translate-y-1 hover:shadow-2xl">
                {content}
            </div>
        </div>
    )
}
