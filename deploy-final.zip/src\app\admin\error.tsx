'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function AdminError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-4">
      <div className="text-center space-y-6 max-w-md">
        <div className="space-y-2">
          <h1 className="text-3xl font-heading font-bold">Admin Error</h1>
          <p className="text-muted-foreground">
            An error occurred in the admin panel. Please try again or return to The Desk.
          </p>
          {error.digest && process.env.NODE_ENV === 'development' && (
            <p className="text-xs text-muted-foreground font-mono mt-2">
              Error ID: {error.digest}
            </p>
          )}
        </div>
        <div className="flex gap-4 justify-center">
          <Button onClick={reset}>Try Again</Button>
          <Button variant="outline" asChild>
            <Link href="/admin/desk">Back to Desk</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}




