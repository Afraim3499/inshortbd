'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { X, ChevronRight, Twitter, Instagram, Youtube, Mail, Shield, User } from 'lucide-react'

const MENU_ITEMS = [
    { label: 'Politics', href: '/category/Politics' },
    { label: 'Technology', href: '/category/Technology' },
    { label: 'Business', href: '/category/Business' },
    { label: 'Culture', href: '/category/Culture' },
    { label: 'World', href: '/category/World' },
]

const SECONDARY_LINKS = [
    { label: 'About', href: '/about', icon: User },
    { label: 'Editorial Policy', href: '/editorial-policy', icon: Shield },
    { label: 'Contact', href: '/contact', icon: Mail },
]

interface MobileMenuModalProps {
    open: boolean
    onOpenChange: (open: boolean) => void
}

export function MobileMenuModal({ open, onOpenChange }: MobileMenuModalProps) {
    const router = useRouter()

    const handleLinkClick = (href: string) => {
        onOpenChange(false)
        router.push(href)
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-full h-[100dvh] p-0 gap-0 bg-white/98 backdrop-blur-xl data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom duration-300 border-none rounded-none flex flex-col">
                <DialogTitle className="sr-only">Main Menu</DialogTitle>
                <DialogDescription className="sr-only">Navigation menu</DialogDescription>

                {/* Header */}
                <div className="flex items-center justify-between p-5 border-b border-gray-100">
                    <span className="font-serif font-bold text-xl tracking-tight">The Trail</span>
                    <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full">
                        <X className="w-6 h-6" />
                    </Button>
                </div>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto p-6 space-y-8">

                    {/* Main Categories */}
                    <div className="space-y-4">
                        <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Sections</h3>
                        <div className="grid gap-3">
                            {MENU_ITEMS.map((item) => (
                                <button
                                    key={item.href}
                                    onClick={() => handleLinkClick(item.href)}
                                    className="flex items-center justify-between w-full text-left group p-3 rounded-lg hover:bg-gray-50 transition-colors"
                                >
                                    <span className="text-2xl font-serif text-ink-black group-hover:text-trail-blue transition-colors">
                                        {item.label}
                                    </span>
                                    <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-trail-blue" />
                                </button>
                            ))}
                        </div>
                    </div>

                    <div className="w-full h-px bg-gray-100" />

                    {/* Secondary Links */}
                    <div className="space-y-2">
                        {SECONDARY_LINKS.map((link) => (
                            <button
                                key={link.href}
                                onClick={() => handleLinkClick(link.href)}
                                className="flex items-center gap-3 w-full text-left p-2 text-gray-600 hover:text-trail-blue transition-colors"
                            >
                                <link.icon className="w-4 h-4" />
                                <span className="font-sans font-medium text-sm">{link.label}</span>
                            </button>
                        ))}
                    </div>

                </div>

                {/* Footer Actions */}
                <div className="p-6 border-t border-gray-100 bg-gray-50">
                    <div className="flex justify-center gap-6">
                        <a href="https://twitter.com" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-twitter transition-colors">
                            <Twitter className="w-5 h-5" />
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-pink-600 transition-colors">
                            <Instagram className="w-5 h-5" />
                        </a>
                        <a href="https://youtube.com" target="_blank" rel="noreferrer" className="text-gray-400 hover:text-red-600 transition-colors">
                            <Youtube className="w-5 h-5" />
                        </a>
                    </div>
                </div>

            </DialogContent>
        </Dialog>
    )
}
