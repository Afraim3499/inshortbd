import { TiptapRenderer } from '@/components/content/tiptap-renderer'

interface BiographyProps {
    name: string
    biography: any // TipTap JSON content
}

export function Biography({ name, biography }: BiographyProps) {
    // Hide component entirely if no biography
    if (!biography) {
        return null
    }

    return (
        <article className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-200">
            <h2 className="font-display text-3xl sm:text-4xl font-black mb-6">The Journey</h2>
            <div className="prose prose-lg max-w-none prose-headings:font-display prose-headings:font-bold prose-p:font-serif prose-p:text-gray-700">
                <TiptapRenderer content={biography} />
            </div>
        </article>
    )
}
