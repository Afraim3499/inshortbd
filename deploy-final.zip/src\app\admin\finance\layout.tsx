'use client'

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { LayoutDashboard, Users, Rocket, BookOpen, DollarSign } from "lucide-react"

export default function FinanceLayout({
    children,
}: {
    children: React.ReactNode
}) {
    const pathname = usePathname()

    const navItems = [
        {
            name: 'Overview',
            href: '/admin/finance',
            icon: LayoutDashboard,
            exact: true
        },
        {
            name: 'Billionaires',
            href: '/admin/finance/billionaires',
            icon: Users
        },
        {
            name: 'Startups',
            href: '/admin/finance/startups',
            icon: Rocket
        },
        {
            name: 'Wealth Playbook',
            href: '/admin/finance/wealth',
            icon: BookOpen
        },
    ]

    const isActive = (item: any) => {
        if (item.exact) return pathname === item.href
        return pathname.startsWith(item.href)
    }

    return (
        <div className="flex flex-col space-y-8">
            <div>
                <h1 className="text-3xl font-heading font-bold text-gray-900 tracking-tight">Finance Hub</h1>
                <p className="text-muted-foreground mt-2">Manage crucial financial data for the specialized finance sections.</p>
            </div>

            <div className="flex flex-col lg:flex-row gap-8">
                {/* Sub-Sidebar */}
                <aside className="lg:w-64 flex-shrink-0">
                    <nav className="space-y-1">
                        {navItems.map((item) => (
                            <Link
                                key={item.name}
                                href={item.href}
                                className={cn(
                                    "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors",
                                    isActive(item)
                                        ? "bg-trail-blue text-white shadow-md"
                                        : "text-gray-600 hover:bg-gray-100 hover:text-gray-900"
                                )}
                            >
                                <item.icon className={cn("mr-3 h-5 w-5", isActive(item) ? "text-white" : "text-gray-400 group-hover:text-gray-500")} />
                                {item.name}
                            </Link>
                        ))}
                    </nav>
                </aside>

                {/* Content Area */}
                <main className="flex-1 min-w-0">
                    {children}
                </main>
            </div>
        </div>
    )
}
