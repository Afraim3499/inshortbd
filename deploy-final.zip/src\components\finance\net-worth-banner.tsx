import type { BillionaireWithHoldings } from '@/types/finance.types'

interface NetWorthBannerProps {
    billionaire: BillionaireWithHoldings
}

export function NetWorthBanner({ billionaire }: NetWorthBannerProps) {
    // Format net worth (stored in cents) to Billions
    const netWorthBillions = (billionaire.net_worth_usd / 1000000000).toFixed(1)

    return (
        <div className="bg-gray-900 text-white py-6 border-b border-gray-800">
            <div className="max-w-6xl mx-auto px-4 sm:px-6">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                    <div className="text-center sm:text-left">
                        <div className="text-xs uppercase tracking-wider text-gray-400 mb-1 font-sans">
                            Net Worth
                        </div>
                        <div className="text-5xl sm:text-6xl font-black mb-2 font-display">
                            ${netWorthBillions}B
                        </div>
                        <div className="text-sm text-gray-500 font-mono">
                            Updated {new Date(billionaire.updated_at || billionaire.created_at).toLocaleDateString()}
                        </div>
                    </div>

                    <div className="grid grid-cols-2 gap-8 text-center border-l border-gray-800 pl-6 border-opacity-50 sm:border-l-0 sm:pl-0">
                        <div>
                            <div className="text-3xl font-black font-display">
                                #{billionaire.world_rank || '-'}
                            </div>
                            <div className="text-xs text-gray-400 font-sans uppercase tracking-wide">
                                World Rank
                            </div>
                        </div>
                        <div>
                            <div className="text-3xl font-black font-display">
                                {billionaire.is_self_made ? 'Yes' : 'No'}
                            </div>
                            <div className="text-xs text-gray-400 font-sans uppercase tracking-wide">
                                Self Made
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
