import { Navigation } from '@/components/navigation'
import { Footer } from '@/components/footer'
import { Metadata } from 'next'
import { getSiteUrl } from '@/lib/env'
import { Mail, Twitter, Instagram, Youtube } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Contact Us - The Trail',
  description: 'Get in touch with The Trail news team. Questions, feedback, or story tips.',
  alternates: {
    canonical: `${getSiteUrl()}/contact`,
  },
}

export default function ContactPage() {
  return (
    <>
      <Navigation />
      <main className="min-h-screen bg-background text-foreground">
        <div className="max-w-3xl mx-auto px-4 py-16">
          <h1 className="text-4xl md:text-5xl font-heading font-bold mb-8">Contact Us</h1>

          <div className="prose prose-invert prose-zinc max-w-none space-y-8">
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto font-serif">
              Have questions, feedback, or story tips? We&apos;d love to hear from you.
            </p>

            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-heading font-bold mb-4">Follow The Trail</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <a
                    href="https://twitter.com/TheTrailNews"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 border border-border rounded-lg hover:border-accent hover:bg-accent/5 transition-colors"
                  >
                    <Twitter className="w-5 h-5 text-accent" />
                    <div>
                      <div className="font-medium">Twitter/X</div>
                      <div className="text-sm text-muted-foreground">@TheTrailNews</div>
                    </div>
                  </a>

                  <a
                    href="https://instagram.com/TheTrailDaily"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 border border-border rounded-lg hover:border-accent hover:bg-accent/5 transition-colors"
                  >
                    <Instagram className="w-5 h-5 text-accent" />
                    <div>
                      <div className="font-medium">Instagram</div>
                      <div className="text-sm text-muted-foreground">@TheTrailDaily</div>
                    </div>
                  </a>

                  <a
                    href="https://youtube.com/@TheTrailWatch"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-4 border border-border rounded-lg hover:border-accent hover:bg-accent/5 transition-colors"
                  >
                    <Youtube className="w-5 h-5 text-accent" />
                    <div>
                      <div className="font-medium">YouTube</div>
                      <div className="text-sm text-muted-foreground">@TheTrailWatch</div>
                    </div>
                  </a>
                </div>
              </div>

              <div className="pt-8 border-t border-border">
                <h2 className="text-2xl font-heading font-bold mb-4">Editorial Inquiries</h2>
                <p className="text-muted-foreground">
                  For editorial questions, story submissions, or media inquiries, please reach out
                  through our social media channels or refer to our{' '}
                  <a href="/editorial-policy" className="text-accent hover:underline">
                    Editorial Policy
                  </a>
                  .
                </p>
              </div>

              <div className="pt-8 border-t border-border">
                <h2 className="text-2xl font-heading font-bold mb-4">General Information</h2>
                <p className="text-gray-600 mb-6">
                  For general inquiries or feedback about The Trail platform, we&apos;re active on
                  social media and monitor our general inbox daily.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}

