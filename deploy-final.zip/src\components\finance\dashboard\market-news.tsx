export function MarketNews() {
    // Mock News Data
    const news = [
        {
            time: '14:35',
            title: 'Fed Signals Rate Cuts Coming in Q2',
            desc: 'Federal Reserve Chair hints at monetary easing as inflation shows sustained decline',
            impact: 'S&P +48 pts',
            ago: '5 minutes ago',
            color: 'from-trail-blue to-blue-600',
            impactColor: 'bg-green-100 text-green-700'
        },
        {
            time: '13:20',
            title: 'AI Chip Demand Drives Tech Surge',
            desc: 'NVIDIA, AMD lead rally as enterprise AI adoption accelerates globally',
            impact: 'NASDAQ +125',
            ago: '1 hour ago',
            color: 'from-purple-500 to-pink-500',
            impactColor: 'bg-purple-100 text-purple-700'
        }
    ]

    return (
        <div className="bg-white rounded-3xl p-8 shadow-xl">
            <h3 className="text-2xl font-black mb-6 font-display">Market-Moving News</h3>
            <div className="space-y-6">
                {news.map((item, idx) => (
                    <article key={idx} className="flex gap-4 pb-6 border-b border-gray-100 last:border-0 hover:bg-blue-50 p-4 rounded-xl transition-all">
                        <div className={`flex-shrink-0 w-20 h-20 bg-gradient-to-br ${item.color} rounded-2xl flex flex-col items-center justify-center text-white`}>
                            <div className="text-2xl font-black font-display">{item.time.split(':')[0]}</div>
                            <div className="text-xs font-sans">:{item.time.split(':')[1]}</div>
                        </div>
                        <div className="flex-1">
                            <h4 className="font-black text-lg mb-2 hover:text-trail-blue cursor-pointer font-display">
                                {item.title}
                            </h4>
                            <p className="text-gray-600 mb-3 text-sm font-sans line-clamp-2">
                                {item.desc}
                            </p>
                            <div className="flex items-center gap-3 text-xs font-sans">
                                <span className={`px-3 py-1 ${item.impactColor} rounded-full font-bold`}>{item.impact}</span>
                                <span className="text-gray-500">{item.ago}</span>
                            </div>
                        </div>
                    </article>
                ))}
            </div>
        </div>
    )
}
