import { getStartups } from '@/app/actions/finance/get-startup'
import { FinanceHeader } from '@/components/finance/finance-header'
import Link from 'next/link'
import Image from 'next/image'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Startup Stories: Successes & Failures - The Trail Finance',
    description: 'Deep dives into the most important startup success stories and cautionary tales of failure.',
}

export const revalidate = 300 // 5 minutes

export default async function StartupsIndexPage() {
    const { stories: successStories } = await getStartups({ type: 'success', limit: 3 })
    const { stories: failureStories } = await getStartups({ type: 'failure', limit: 3 })

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                {/* Hero Section */}
                <div className="bg-gray-900 text-white py-20 px-6">
                    <div className="max-w-7xl mx-auto text-center">
                        <h1 className="text-5xl md:text-7xl font-black font-display mb-6 tracking-tight">
                            The Startup <span className="text-trail-blue">Game</span>
                        </h1>
                        <p className="text-xl md:text-2xl text-gray-400 font-serif max-w-2xl mx-auto">
                            Dissecting the unicorns that changed the world—and the crashes that taught us everything.
                        </p>
                    </div>
                </div>

                <div className="max-w-7xl mx-auto px-6 py-16 space-y-20">

                    {/* Success Section */}
                    <section>
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-3xl font-black font-display text-gray-900 flex items-center gap-3">
                                <span className="text-green-500">▲</span> The Breakthroughs
                            </h2>
                            <Link href="/finance/startups/success" className="text-trail-blue font-bold hover:underline font-sans">
                                View All Success Stories &rarr;
                            </Link>
                        </div>

                        <div className="grid md:grid-cols-3 gap-8">
                            {successStories.length > 0 ? (
                                successStories.map(story => (
                                    <StartupCard key={story.id} story={story} />
                                ))
                            ) : (
                                <p className="text-gray-500 italic col-span-3 text-center py-10">Coming soon.</p>
                            )}
                        </div>
                    </section>

                    {/* Failure Section */}
                    <section>
                        <div className="flex items-center justify-between mb-8">
                            <h2 className="text-3xl font-black font-display text-gray-900 flex items-center gap-3">
                                <span className="text-red-500">▼</span> The Hard Lessons
                            </h2>
                            <Link href="/finance/startups/failure" className="text-red-600 font-bold hover:underline font-sans">
                                View All Failure Stories &rarr;
                            </Link>
                        </div>

                        <div className="grid md:grid-cols-3 gap-8">
                            {failureStories.length > 0 ? (
                                failureStories.map(story => (
                                    <StartupCard key={story.id} story={story} />
                                ))
                            ) : (
                                <p className="text-gray-500 italic col-span-3 text-center py-10">Coming soon.</p>
                            )}
                        </div>
                    </section>

                </div>
            </main>
        </div>
    )
}

function StartupCard({ story }: { story: any }) {
    return (
        <Link href={`/finance/startups/${story.story_type}/${story.slug}`} className="group block bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100">
            <div className="aspect-[16/9] bg-gray-100 relative overflow-hidden">
                {story.hero_image_url ? (
                    <Image
                        src={story.hero_image_url}
                        alt={story.company_name}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-4xl text-gray-300 font-black font-display uppercase">
                        {story.company_name.substring(0, 2)}
                    </div>
                )}
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider text-gray-900 font-sans shadow-sm">
                    {story.industry}
                </div>
            </div>
            <div className="p-6">
                <div className={`text-sm font-bold mb-2 font-sans flex items-center gap-2 ${story.story_type === 'success' ? 'text-green-600' : 'text-red-600'}`}>
                    {story.story_type === 'success' ? '🦄' : '📉'}
                    {story.stats?.valuation || story.stats?.value_lost || 'Valuation Unknown'}
                </div>
                <h3 className="text-xl font-black mb-2 font-display text-gray-900 group-hover:text-trail-blue transition-colors">
                    {story.company_name}
                </h3>
                <p className="text-gray-500 text-sm line-clamp-2 font-serif leading-relaxed">
                    {story.title}
                </p>
            </div>
        </Link>
    )
}
