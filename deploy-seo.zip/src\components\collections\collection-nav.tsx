import { createClient } from '@/utils/supabase/server'
import Link from 'next/link'
import { ChevronLeft, ChevronRight, BookOpen } from 'lucide-react'

async function getCollectionForPost(postId: string) {
  const supabase = await createClient()

  // Get collection that contains this post
  const { data: collectionPost, error } = await (supabase
    .from('collection_posts') as any)
    .select(
      `
      collection_id,
      order_index,
      collections (
        id,
        title,
        slug
      )
    `
    )
    .eq('post_id', postId)
    .order('order_index', { ascending: true })
    .limit(1)
    .single()

  if (error || !collectionPost || !collectionPost.collections) {
    return null
  }

  const collection = collectionPost.collections as any

  // Get all posts in this collection
  const { data: allPosts, error: postsError } = await (supabase
    .from('collection_posts') as any)
    .select(
      `
      order_index,
      posts (
        id,
        slug,
        title,
        status,
        published_at
      )
    `
    )
    .eq('collection_id', collection.id)
    .order('order_index', { ascending: true })

  if (postsError || !allPosts) {
    return null
  }

  // Filter to published posts and find current position
  const publishedPosts = allPosts
    .filter((item: any) => item.posts && item.posts.status === 'published' && item.posts.published_at)
    .map((item: any) => ({
      id: item.posts.id,
      slug: item.posts.slug,
      title: item.posts.title,
      order_index: item.order_index,
    }))

  const currentIndex = publishedPosts.findIndex((p: any) => p.id === postId)

  if (currentIndex === -1) {
    return null
  }

  const previousPost = currentIndex > 0 ? publishedPosts[currentIndex - 1] : null
  const nextPost = currentIndex < publishedPosts.length - 1 ? publishedPosts[currentIndex + 1] : null

  return {
    collection: {
      id: collection.id,
      title: collection.title,
      slug: collection.slug,
    },
    currentIndex: currentIndex + 1,
    totalPosts: publishedPosts.length,
    previousPost,
    nextPost,
  }
}

interface CollectionNavProps {
  postId: string
}

export async function CollectionNav({ postId }: CollectionNavProps) {
  const collectionData = await getCollectionForPost(postId)

  if (!collectionData) {
    return null
  }

  const { collection, currentIndex, totalPosts, previousPost, nextPost } = collectionData

  return (
    <div className="border-t border-b border-border py-6 my-8">
      <div className="max-w-3xl mx-auto">
        {/* Collection Header */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <BookOpen className="h-4 w-4" />
          <Link
            href={`/collections/${collection.slug}`}
            className="hover:text-foreground transition-colors"
          >
            {collection.title}
          </Link>
          <span>•</span>
          <span>
            Part {currentIndex} of {totalPosts}
          </span>
        </div>

        {/* Navigation */}
        <div className="grid grid-cols-2 gap-4">
          {previousPost ? (
            <Link
              href={`/news/${previousPost.slug}`}
              className="group flex items-start gap-3 p-4 border border-border rounded-lg hover:border-accent transition-colors"
            >
              <ChevronLeft className="h-5 w-5 text-muted-foreground group-hover:text-foreground mt-0.5 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground mb-1">Previous</div>
                <div className="font-medium line-clamp-2 group-hover:text-accent transition-colors">
                  {previousPost.title}
                </div>
              </div>
            </Link>
          ) : (
            <div className="p-4 border border-border rounded-lg opacity-50">
              <div className="text-xs text-muted-foreground mb-1">Previous</div>
              <div className="font-medium text-muted-foreground">No previous article</div>
            </div>
          )}

          {nextPost ? (
            <Link
              href={`/news/${nextPost.slug}`}
              className="group flex items-start gap-3 p-4 border border-border rounded-lg hover:border-accent transition-colors text-right"
            >
              <div className="flex-1 min-w-0">
                <div className="text-xs text-muted-foreground mb-1">Next</div>
                <div className="font-medium line-clamp-2 group-hover:text-accent transition-colors">
                  {nextPost.title}
                </div>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-foreground mt-0.5 flex-shrink-0" />
            </Link>
          ) : (
            <div className="p-4 border border-border rounded-lg opacity-50 text-right">
              <div className="text-xs text-muted-foreground mb-1">Next</div>
              <div className="font-medium text-muted-foreground">No next article</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}





