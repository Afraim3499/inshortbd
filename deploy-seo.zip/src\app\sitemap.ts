import { createClient } from '@/utils/supabase/server'
import { getSiteUrl } from '@/lib/env'

export default async function sitemap() {
  const baseUrl = getSiteUrl()

  const supabase = await createClient()
  const { data: posts } = await (supabase
    .from('posts') as any)
    .select('slug, updated_at')
    .eq('status', 'published')

  const typedPosts = (posts || []) as Array<{
    slug: string
    updated_at: string | null
  }>

  const postUrls = typedPosts.map((post: any) => ({
      url: `${baseUrl}/news/${post.slug}`,
      lastModified: post.updated_at ? new Date(post.updated_at) : new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    })) || []

  return [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily',
      priority: 1,
    },
    {
      url: `${baseUrl}/search`,
      lastModified: new Date(),
      changeFrequency: 'weekly',
      priority: 0.5,
    },
    ...postUrls,
  ]
}

