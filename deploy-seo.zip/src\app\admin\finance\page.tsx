'use client'

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Users, TrendingUp, Trophy, ArrowRight } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function FinanceDashboardPage() {
    return (
        <div className="space-y-6">
            <div className="grid gap-6 md:grid-cols-3">
                {/* Billionaires Card */}
                <Card className="hover:shadow-lg transition-shadow border-emerald-100 bg-emerald-50/30">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-emerald-900">
                            Active Billionaires
                        </CardTitle>
                        <Users className="h-4 w-4 text-emerald-600" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-emerald-700">--</div>
                        <p className="text-xs text-muted-foreground mt-1">
                            +0 this month
                        </p>
                        <Link href="/admin/finance/billionaires" className="mt-4 block">
                            <Button variant="outline" className="w-full border-emerald-200 text-emerald-700 hover:bg-emerald-100 hover:text-emerald-800">Manage Profiles</Button>
                        </Link>
                    </CardContent>
                </Card>

                {/* Startups Card */}
                <Card className="hover:shadow-lg transition-shadow border-orange-100 bg-orange-50/30">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-orange-900">
                            Startup Stories
                        </CardTitle>
                        <TrendingUp className="h-4 w-4 text-orange-600" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-orange-700">--</div>
                        <p className="text-xs text-muted-foreground mt-1">
                            Stories published
                        </p>
                        <Link href="/admin/finance/startups" className="mt-4 block">
                            <Button variant="outline" className="w-full border-orange-200 text-orange-700 hover:bg-orange-100 hover:text-orange-800">Manage Stories</Button>
                        </Link>
                    </CardContent>
                </Card>

                {/* Wealth Card */}
                <Card className="hover:shadow-lg transition-shadow border-purple-100 bg-purple-50/30">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium text-purple-900">
                            Wealth Strategies
                        </CardTitle>
                        <Trophy className="h-4 w-4 text-purple-600" />
                    </CardHeader>
                    <CardContent>
                        <div className="text-2xl font-bold text-purple-700">7/7</div>
                        <p className="text-xs text-muted-foreground mt-1">
                            Active strategies
                        </p>
                        <Link href="/admin/finance/wealth" className="mt-4 block">
                            <Button variant="outline" className="w-full border-purple-200 text-purple-700 hover:bg-purple-100 hover:text-purple-800">Edit Playbook</Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Welcome to the Finance Hub</CardTitle>
                    <CardDescription>
                        This specialized dashboard allows you to manage the structured data that powers the Finance section of the website.
                        Unlike standard articles, these items have specific data points (Net Worth, IPO Status, etc.) that enable the rich, interactive components on the frontend.
                    </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-4 rounded-lg border bg-slate-50">
                            <h3 className="font-semibold mb-2 flex items-center gap-2"><Users className="w-4 h-4" /> Billionaires Index</h3>
                            <p className="text-sm text-gray-600">
                                Tracks real-time net worth. Use this to add profiles for "Under 40" stars, "Women Leaders", and the main Billionaires list.
                            </p>
                        </div>
                        <div className="p-4 rounded-lg border bg-slate-50">
                            <h3 className="font-semibold mb-2 flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Startup Stories</h3>
                            <p className="text-sm text-gray-600">
                                Deep dives into company histories. Features structured sections for "Struggle", "Breakthrough", and "Wisdom".
                            </p>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}
