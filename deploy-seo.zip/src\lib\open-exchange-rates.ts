import { createClient } from '@/utils/supabase/server'
import type { MarketData } from '@/lib/finnhub'

const APP_ID = process.env.OPEN_EXCHANGE_RATES_APP_ID
const BASE_URL = 'https://openexchangerates.org/api'

// Cache duration: 1 Hour (in milliseconds)
const CACHE_DURATION = 60 * 60 * 1000

interface OERResponse {
    timestamp: number
    base: string
    rates: Record<string, number>
}

// target symbols map to OER currency codes
const FOREX_PAIRS: Record<string, { base: string, quote: string, name: string, isInverse: boolean }> = {
    'OANDA:EUR_USD': { base: 'USD', quote: 'EUR', name: 'EUR/USD', isInverse: true },
    'OANDA:GBP_USD': { base: 'USD', quote: 'GBP', name: 'GBP/USD', isInverse: true },
    'OANDA:USD_JPY': { base: 'USD', quote: 'JPY', name: 'USD/JPY', isInverse: false },
    'OANDA:AUD_USD': { base: 'USD', quote: 'AUD', name: 'AUD/USD', isInverse: true },
    'OANDA:USD_CAD': { base: 'USD', quote: 'CAD', name: 'USD/CAD', isInverse: false },
    'OANDA:USD_CHF': { base: 'USD', quote: 'CHF', name: 'USD/CHF', isInverse: false },
    'OANDA:NZD_USD': { base: 'USD', quote: 'NZD', name: 'NZD/USD', isInverse: true },
}

export async function getForexRates(): Promise<MarketData[]> {
    if (!APP_ID) {
        console.warn('Missing OPEN_EXCHANGE_RATES_APP_ID')
        return []
    }

    const supabase = await createClient()

    // 1. Check DB Cache for Forex data
    const { data: cachedData } = await (supabase.from('market_prices') as any)
        .select('*')
        .like('symbol', 'OANDA:%')

    // Find oldest update time
    const now = Date.now()
    const newestUpdate = cachedData?.reduce((newest: number, item: any) => {
        const itemTime = new Date(item.updated_at).getTime()
        return itemTime > newest ? itemTime : newest
    }, 0) || 0

    // If cache is fresh (< 1 hour), return it
    if (cachedData && cachedData.length > 0 && (now - newestUpdate) < CACHE_DURATION) {
        return cachedData
    }

    // 2. Fetch Fresh from OpenExchangeRates
    try {
        const res = await fetch(`${BASE_URL}/latest.json?app_id=${APP_ID}`)
        if (!res.ok) throw new Error(`OER Status ${res.status}`)

        const data: OERResponse = await res.json()
        const rates = data.rates
        const results: MarketData[] = []

        for (const [symbol, info] of Object.entries(FOREX_PAIRS)) {
            const rawRate = rates[info.quote]
            if (!rawRate) continue

            // Calculate price (Inverse for EUR/USD etc as OER is USD base)
            const price = info.isInverse ? (1 / rawRate) : rawRate

            // Calculate change (mock or comparison with previous)
            // For now, we compare with cached value if exists to get change
            const prev = cachedData?.find((d: any) => d.symbol === symbol)
            const prevPrice = prev?.price || price
            const change = price - prevPrice
            const changePercent = prevPrice !== 0 ? (change / prevPrice) * 100 : 0

            results.push({
                symbol: symbol, // Keep partial internal ID or display format? Finnhub uses OANDA:...
                name: info.name,
                price: price,
                change: change,
                change_percent: changePercent,
                market_cap: 0,
                updated_at: new Date().toISOString(),
                type: 'forex'
            })
        }

        // 3. Update DB
        if (results.length > 0) {
            await (supabase.from('market_prices') as any).upsert(results, { onConflict: 'symbol' })
        }

        return results

    } catch (e) {
        console.error('OpenExchangeRates Error:', e)
        return cachedData || [] // Fallback to stale cache if API fails
    }
}
