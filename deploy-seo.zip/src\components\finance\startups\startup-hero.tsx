import Image from 'next/image'
import type { StartupStoryExtended } from '@/types/finance.types'

interface StartupHeroProps {
    story: StartupStoryExtended
    variant: 'success' | 'failure'
}

export function StartupHero({ story, variant }: StartupHeroProps) {
    const isSuccess = variant === 'success'

    // Color configuration
    const badgeBg = isSuccess ? 'bg-green-100' : 'bg-red-100'
    const badgeText = isSuccess ? 'text-green-700' : 'text-red-700'
    const statColor = isSuccess ? 'text-green-600' : 'text-red-600'
    const regionBadge = isSuccess ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-700'

    return (
        <div className="mb-12">
            <div className="flex items-center gap-3 mb-6">
                <span className={`inline-block px-4 py-2 ${badgeBg} ${badgeText} text-sm font-bold uppercase tracking-wider rounded-full font-sans`}>
                    {isSuccess ? 'Success Story' : 'Failure Case Study'}
                </span>
                <span className={`px-4 py-2 ${regionBadge} text-sm font-bold rounded-full font-sans`}>
                    {story.stats.countries ? `🌏 ${story.stats.countries} Countries` : '🇺🇸 USA'} {/* Mock logic for region display */}
                </span>
            </div>

            <h1 className="font-display text-5xl sm:text-6xl md:text-7xl font-black leading-tight mb-8">
                {story.title}
            </h1>

            <p className="text-xl sm:text-3xl text-gray-700 font-serif leading-relaxed mb-12">
                {isSuccess
                    ? `From humble beginnings to a ${story.stats.valuation} empire—the journey of ${story.company_name}.`
                    : `The ${story.stats.valuation} collapse: What really happened to ${story.company_name}.`
                }
            </p>

            <div className={`grid grid-cols-2 sm:grid-cols-4 gap-6 mb-16 ${!isSuccess ? 'grid-cols-3' : ''}`}>
                <div className={`text-center ${!isSuccess ? 'p-6 bg-red-50 rounded-2xl' : ''}`}>
                    <div className={`text-4xl font-black ${statColor} mb-2 font-display`}>
                        {story.stats.valuation}
                    </div>
                    <div className="text-sm text-gray-600 font-sans">
                        {isSuccess ? 'Valuation' : 'Peak Valuation'}
                    </div>
                </div>

                {isSuccess && (
                    <>
                        <div className="text-center">
                            <div className="text-4xl font-black text-green-600 mb-2 font-display">{story.stats.countries}</div>
                            <div className="text-sm text-gray-600 font-sans">Countries</div>
                        </div>
                        <div className="text-center">
                            <div className="text-4xl font-black text-green-600 mb-2 font-display">{story.stats.users}</div>
                            <div className="text-sm text-gray-600 font-sans">Users</div>
                        </div>
                        <div className="text-center">
                            <div className="text-4xl font-black text-green-600 mb-2 font-display">{story.stats.years}</div>
                            <div className="text-sm text-gray-600 font-sans">Years</div>
                        </div>
                    </>
                )}

                {!isSuccess && (
                    <>
                        <div className="text-center p-6 bg-red-50 rounded-2xl">
                            <div className="text-4xl font-black text-red-600 mb-2 font-display">{story.stats.capital_raised}</div>
                            <div className="text-sm text-gray-600 font-sans">Capital Raised</div>
                        </div>
                        <div className="text-center p-6 bg-red-50 rounded-2xl">
                            <div className="text-4xl font-black text-red-600 mb-2 font-display">{story.stats.value_lost}</div>
                            <div className="text-sm text-gray-600 font-sans">Value Lost</div>
                        </div>
                    </>
                )}
            </div>

            <div className="aspect-video rounded-2xl overflow-hidden relative">
                {story.hero_image_url ? (
                    <Image
                        src={story.hero_image_url}
                        alt={story.company_name}
                        fill
                        className="object-cover"
                    />
                ) : (
                    <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400">
                        No Hero Image
                    </div>
                )}
            </div>
            <p className="text-sm text-gray-500 text-center mt-4 font-sans max-w-2xl mx-auto">
                {story.company_name} office/operations.
            </p>
        </div>
    )
}
