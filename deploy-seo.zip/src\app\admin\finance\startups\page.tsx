'use client'

import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table"
import { Plus, Search, Loader2, Edit, Trash2 } from 'lucide-react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'

export default function StartupStoriesListPage() {
    const supabase = createClient()
    const [search, setSearch] = useState('')

    const { data: stories = [], isLoading } = useQuery({
        queryKey: ['startups-list', search],
        queryFn: async () => {
            let query = supabase
                .from('startup_stories')
                .select('*')
                .order('created_at', { ascending: false })

            if (search) {
                query = query.ilike('company_name', `%${search}%`)
            }

            const { data, error } = await query
            if (error) throw error
            return data
        }
    })

    return (
        <div className="space-y-6">
            <div className="flex flex-col sm:flex-row justify-between gap-4 items-center">
                <h2 className="text-2xl font-bold font-heading">Startup Stories</h2>
                <Link href="/admin/finance/startups/new">
                    <Button className="w-full sm:w-auto bg-orange-600 hover:bg-orange-700">
                        <Plus className="mr-2 h-4 w-4" /> Add Story
                    </Button>
                </Link>
            </div>

            <div className="flex items-center gap-2 max-w-sm">
                <Search className="h-4 w-4 text-gray-500" />
                <Input
                    placeholder="Search companies..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
            </div>

            <div className="border rounded-lg bg-white overflow-hidden">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Company</TableHead>
                            <TableHead>Founder</TableHead>
                            <TableHead>Type</TableHead>
                            <TableHead>Region</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {isLoading ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center">
                                    <Loader2 className="h-6 w-6 animate-spin mx-auto text-gray-400" />
                                </TableCell>
                            </TableRow>
                        ) : stories.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={6} className="h-24 text-center text-gray-500">
                                    No stories found.
                                </TableCell>
                            </TableRow>
                        ) : (
                            stories.map((s: any) => (
                                <TableRow key={s.id}>
                                    <TableCell className="font-medium">
                                        <div className="flex items-center gap-3">
                                            {s.hero_image_url && (
                                                <img src={s.hero_image_url} alt={s.company_name} className="w-8 h-8 rounded object-cover" />
                                            )}
                                            {s.company_name}
                                        </div>
                                    </TableCell>
                                    <TableCell>{s.founder_name}</TableCell>
                                    <TableCell>
                                        <Badge variant={s.story_type === 'unicorn' ? 'default' : 'secondary'}>
                                            {s.story_type}
                                        </Badge>
                                    </TableCell>
                                    <TableCell>{s.region}</TableCell>
                                    <TableCell>
                                        <Badge variant="outline" className={s.is_published ? "border-green-200 text-green-700" : "border-yellow-200 text-yellow-700"}>
                                            {s.is_published ? 'Published' : 'Draft'}
                                        </Badge>
                                    </TableCell>
                                    <TableCell className="text-right">
                                        <Link href={`/admin/finance/startups/${s.id}`}>
                                            <Button variant="ghost" size="sm">
                                                <Edit className="h-4 w-4" />
                                            </Button>
                                        </Link>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
        </div>
    )
}
