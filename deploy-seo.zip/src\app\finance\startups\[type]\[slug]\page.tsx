import { getStartupBySlug, getRelatedStartups } from '@/app/actions/finance/get-startup'
import { FinanceHeader } from '@/components/finance/finance-header'
import { StartupHero } from '@/components/finance/startups/startup-hero'
import { StartupTimeline } from '@/components/finance/startups/startup-timeline'
import { StartupLessons } from '@/components/finance/startups/startup-lessons'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Image from 'next/image'
import type { Metadata } from 'next'

interface PageProps {
    params: Promise<{
        type: string
        slug: string
    }>
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
    const resolvedParams = await params
    const type = resolvedParams.type as 'success' | 'failure'

    if (type !== 'success' && type !== 'failure') return {}

    const story = await getStartupBySlug(resolvedParams.slug, type)
    if (!story) return { title: 'Story Not Found' }

    return {
        title: `${story.title} - The Trail Finance`,
        description: `The story of ${story.company_name} and its ${type === 'success' ? 'rise to success' : 'collapse'}.`,
    }
}

export default async function StartupStoryPage({ params }: PageProps) {
    const resolvedParams = await params
    const type = resolvedParams.type as 'success' | 'failure'
    const slug = resolvedParams.slug

    if (type !== 'success' && type !== 'failure') {
        notFound()
    }

    const story = await getStartupBySlug(slug, type)

    if (!story) {
        notFound()
    }

    const relatedStories = await getRelatedStartups(type, story.id)

    return (
        <div className="min-h-screen bg-white">
            {/* Header with Progress Bar indicator potentially - for now standard header */}
            <FinanceHeader />

            <article className="max-w-4xl mx-auto px-6 py-16">
                {/* Hero */}
                <StartupHero story={story} variant={type} />

                {/* Intro Content - stored as rich text or HTML string in 'intro_content' or similar part of 'content' */}
                {/* For MVP, assuming text content is in 'content.intro' or just rendering a part of content */}
                <div className="prose prose-lg max-w-none mb-20 prose-headings:font-display prose-headings:font-black prose-p:font-serif prose-p:text-gray-700">
                    {/* Render HTML content safely later. For now, displaying placeholder or raw text if simple */}
                    {typeof story.content === 'string' ? (
                        <div dangerouslySetInnerHTML={{ __html: story.content }} />
                    ) : (
                        <p className="text-xl font-serif leading-relaxed text-gray-700">
                            {/* Fallback if JSON */}
                            Detailed analysis of {story.company_name}&apos;s journey.
                        </p>
                    )}
                </div>

                {/* Timeline */}
                <StartupTimeline timeline={story.timeline} variant={type} />

                {/* Body Content Continued - simplified for this iteration */}

                {/* Lessons */}
                <StartupLessons lessons={story.lessons} variant={type} />

                {/* Related Stories */}
                {relatedStories.length > 0 && (
                    <div>
                        <h3 className="text-3xl font-black mb-8 font-display">
                            {type === 'success' ? 'More Success Stories' : 'Learn from Other Failures'}
                        </h3>
                        <div className="grid md:grid-cols-3 gap-6">
                            {relatedStories.map(related => (
                                <Link
                                    key={related.id}
                                    href={`/finance/startups/${type}/${related.slug}`}
                                    className="group block bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all"
                                >
                                    <div className={`aspect-video overflow-hidden ${type === 'failure' ? 'bg-red-50 flex items-center justify-center' : ''}`}>
                                        {related.hero_image_url ? (
                                            <Image
                                                src={related.hero_image_url}
                                                alt={related.company_name}
                                                width={600}
                                                height={400}
                                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                            />
                                        ) : (
                                            <div className="text-4xl">{type === 'success' ? '🚀' : '📉'}</div>
                                        )}
                                    </div>
                                    <div className="p-6">
                                        <div className={`text-sm ${type === 'success' ? 'text-trail-blue' : 'text-red-600'} font-bold mb-2 font-sans`}>
                                            {related.stats.valuation || related.stats.value_lost}
                                        </div>
                                        <h4 className="text-xl font-black mb-2 font-display">{related.company_name}</h4>
                                        <p className="text-gray-600 text-sm font-sans line-clamp-2">{related.title}</p>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    </div>
                )}

            </article>
        </div>
    )
}
