import { cn } from '@/lib/utils'
import type { MarketData } from '@/lib/finnhub'
import { ArrowUp, ArrowDown, TrendingUp, DollarSign } from 'lucide-react'

interface MarketSectorGridProps {
    data: MarketData[]
}

export function MarketSectorGrid({ data }: MarketSectorGridProps) {
    const crypto = data.filter(d => d.type === 'crypto')
    const forex = data.filter(d => d.type === 'forex')

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">

            {/* Crypto Heatmap / Grid */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 className="flex items-center gap-2 font-bold text-gray-900 mb-4">
                    <div className="p-1.5 bg-orange-100 rounded-lg text-orange-600">
                        <TrendingUp className="w-4 h-4" />
                    </div>
                    Crypto Movers
                </h3>
                <div className="grid grid-cols-2 gap-3">
                    {crypto.slice(0, 6).map((coin) => (
                        <div key={coin.symbol} className="p-3 bg-gray-50 rounded-xl hover:bg-white hover:shadow-md transition-all cursor-pointer border border-transparent hover:border-gray-100">
                            <div className="flex justify-between items-start mb-1">
                                <span className="font-bold text-xs text-gray-900">{coin.symbol.replace('-USD', '')}</span>
                                <span className={cn("text-[10px] font-bold px-1.5 py-0.5 rounded-full",
                                    coin.change_percent >= 0 ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                                )}>
                                    {coin.change_percent >= 0 ? '+' : ''}{coin.change_percent.toFixed(1)}%
                                </span>
                            </div>
                            <div className="font-mono text-sm font-black text-gray-700">
                                ${coin.price.toLocaleString()}
                            </div>
                        </div>
                    ))}
                    {crypto.length === 0 && <div className="text-gray-400 text-xs italic">Crypto data currently unavailable</div>}
                </div>
            </div>

            {/* Forex Cross Rates */}
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <h3 className="flex items-center gap-2 font-bold text-gray-900 mb-4">
                    <div className="p-1.5 bg-blue-100 rounded-lg text-blue-600">
                        <DollarSign className="w-4 h-4" />
                    </div>
                    Forex Cross Rates
                </h3>
                <div className="space-y-3">
                    {forex.slice(0, 5).map((pair) => (
                        <div key={pair.symbol} className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0 hover:bg-gray-50/50 px-2 -mx-2 rounded transition-colors">
                            <div className="flex flex-col">
                                <span className="font-bold text-sm text-gray-900">{pair.symbol}</span>
                                <span className="text-[10px] text-gray-400">{pair.name}</span>
                            </div>
                            <div className="text-right">
                                <div className="font-mono text-sm font-bold text-gray-700">
                                    {pair.price.toFixed(4)}
                                </div>
                                <div className={cn("text-[10px] font-bold",
                                    pair.change_percent >= 0 ? "text-green-600" : "text-red-600"
                                )}>
                                    {pair.change_percent >= 0 ? '+' : ''}{pair.change_percent.toFixed(2)}%
                                </div>
                            </div>
                        </div>
                    ))}
                    {forex.length === 0 && <div className="text-gray-400 text-xs italic">Forex data currently unavailable</div>}
                </div>
            </div>

        </div>
    )
}
