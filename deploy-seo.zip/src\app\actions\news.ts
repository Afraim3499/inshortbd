'use server'

import { createClient } from '@/utils/supabase/server'

const POSTS_PER_PAGE = 20

export async function loadMorePosts(page: number, excludeIds: string[] = []) {
    const supabase = await createClient()
    const from = (page - 1) * POSTS_PER_PAGE
    const to = from + POSTS_PER_PAGE - 1

    let query = (supabase
        .from('posts') as any)
        .select('*')
        .eq('status', 'published')
        .order('published_at', { ascending: false })

    if (excludeIds.length > 0) {
        query = query.not('id', 'in', `(${excludeIds.join(',')})`)
    }

    const { data, error } = await query.range(from, to)

    if (error) {
        console.error('Error fetching more posts:', error)
        return []
    }

    return (data || []) as any[]
}
