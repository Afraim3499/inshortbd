import { Database } from '@/types/database.types'
import { getSiteUrl } from '@/lib/env'

type Post = Database['public']['Tables']['posts']['Row']

interface StructuredDataProps {
  post: Post
  authorName?: string
  siteUrl?: string
}

export function ArticleStructuredData({
  post,
  authorName,
  siteUrl,
}: StructuredDataProps) {
  const finalSiteUrl = siteUrl || getSiteUrl()
  const fullImageUrl = post.featured_image_url
    ? post.featured_image_url.startsWith('http')
      ? post.featured_image_url
      : `${finalSiteUrl}${post.featured_image_url}`
    : undefined

  const structuredData: any = {
    '@context': 'https://schema.org',
    '@type': 'NewsArticle',
    headline: post.title,
    description: post.excerpt || '',
    datePublished: post.published_at || post.created_at,
    dateModified: post.created_at,
    publisher: {
      '@type': 'Organization',
      name: 'The Trail',
      logo: {
        '@type': 'ImageObject',
        url: `${finalSiteUrl}/logo.png`,
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `${finalSiteUrl}/news/${post.slug}`,
    },
    articleSection: post.category,
  }

  if (fullImageUrl) {
    structuredData.image = [fullImageUrl]
  }

  if (authorName) {
    structuredData.author = {
      '@type': 'Person',
      name: authorName,
    }
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  )
}

interface OrganizationStructuredDataProps {
  siteUrl?: string
}

export function OrganizationStructuredData({
  siteUrl,
}: OrganizationStructuredDataProps) {
  const finalSiteUrl = siteUrl || getSiteUrl()
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'NewsMediaOrganization',
    name: 'The Trail',
    url: finalSiteUrl,
    logo: `${finalSiteUrl}/logo.png`,
    slogan: 'Follow the path to the truth.',
    sameAs: [
      'https://twitter.com/TheTrailNews',
      'https://instagram.com/TheTrailDaily',
      'https://youtube.com/@TheTrailWatch',
    ],
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  )
}

interface BreadcrumbStructuredDataProps {
  items: { name: string; url: string }[]
  siteUrl?: string
}

export function BreadcrumbStructuredData({
  items,
  siteUrl,
}: BreadcrumbStructuredDataProps) {
  const finalSiteUrl = siteUrl || getSiteUrl()
  const structuredData = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: `${finalSiteUrl}${item.url}`,
    })),
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
    />
  )
}

