interface ProgressTrackerProps {
    currentStep: number
    totalSteps: number
}

export function ProgressTracker({ currentStep, totalSteps }: ProgressTrackerProps) {
    const progress = Math.min(100, Math.round((currentStep / totalSteps) * 100))

    return (
        <div className="sticky top-20 bg-gradient-to-r from-blue-50 to-cyan-50 border-b border-blue-200 z-30 shadow-sm">
            <div className="max-w-5xl mx-auto px-6 py-6">
                <div className="flex items-center gap-6">
                    <span className="text-sm font-bold text-gray-700 font-sans hidden sm:inline">Your Progress:</span>
                    <div className="flex-1 h-4 bg-white rounded-full overflow-hidden shadow-inner relative">
                        <div
                            className="h-full bg-gradient-to-r from-trail-blue to-blue-600 relative transition-all duration-1000 ease-out"
                            style={{ width: `${progress}%` }}
                        >
                            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-6 h-6 bg-white rounded-full shadow-lg border-2 border-trail-blue"></div>
                        </div>
                    </div>
                    <span className="text-lg font-black text-trail-blue font-sans whitespace-nowrap">{currentStep} / {totalSteps}</span>
                </div>
                <div className="mt-2 text-xs text-gray-600 text-center font-sans hidden sm:block">
                    🎯 Complete all {totalSteps} strategies to unlock your free millionaire blueprint
                </div>
            </div>
        </div>
    )
}
