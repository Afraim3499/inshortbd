export default function FinanceLayout({
    children,
}: {
    children: React.ReactNode
}) {
    return (
        <div className="finance-section">
            {children}
        </div>
    )
}
