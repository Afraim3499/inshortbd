'use client'

import { useState } from 'react'
import { FinanceHeader } from '@/components/finance/finance-header'
import { PRHero } from '@/components/finance/pr/pr-hero'
import { SponsorshipBanner } from '@/components/finance/pr/sponsorship-banner'
import { PRCard } from '@/components/finance/pr/pr-card'

interface RisingStarsClientProps {
    billionaires: any[]
    stats: {
        count: number
        wealth: string
        avgAge: number
        selfMadePct: number
    }
}

export function RisingStarsClient({ billionaires, stats }: RisingStarsClientProps) {
    const [displayLimit, setDisplayLimit] = useState(20)

    const displayedBillionaires = billionaires.slice(0, displayLimit)
    const hasMore = displayLimit < billionaires.length

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                <PRHero
                    title="Rising Stars Under 40"
                    subtitle="The next generation of billionaires, unicorn founders, and wealth builders reshaping global finance"
                    stats={stats}
                    badgeText="EXCLUSIVE LIST 2025"
                    colorClass="text-trail-blue"
                />

                <SponsorshipBanner
                    text="Want to be featured in our next Rising Stars list?"
                    ctaText="Sponsorship Info →"
                    ctaLink="/finance/sponsorship"
                />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

                    {/* Filters or intro text could go here */}
                    <div className="mb-8 p-4 bg-white rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="text-sm font-medium text-gray-600">
                            Showing {displayedBillionaires.length} of {stats.count} young billionaires
                        </div>
                        <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                            Updated: Real-time
                        </div>
                    </div>

                    <div className="space-y-4">
                        {displayedBillionaires.map((b, index) => (
                            <PRCard
                                key={b.id}
                                billionaire={b}
                                rank={index + 1}
                                colorClass="text-trail-blue"
                            />
                        ))}
                        {billionaires.length === 0 && (
                            <div className="text-center py-12 text-gray-500 italic">
                                No rising stars found in the database.
                            </div>
                        )}
                    </div>

                    {/* Footer CTA */}
                    {hasMore && (
                        <div className="text-center py-12">
                            <button
                                onClick={() => setDisplayLimit(prev => prev + 20)}
                                className="px-8 py-4 bg-trail-blue text-white font-bold rounded-xl hover:bg-blue-700 shadow-lg hover:shadow-xl transition-all font-sans"
                            >
                                Load More Candidates
                            </button>
                        </div>
                    )}

                    {/* Bottom Sponsorship - Dark */}
                    <div className="bg-gray-900 text-white rounded-2xl p-6 sm:p-8 border-2 border-trail-blue mt-8">
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                            <h3 className="text-xl sm:text-2xl font-black font-display">Want to be featured in our Rising Stars list?</h3>
                            <div className="flex gap-3">
                                <a
                                    href="mailto:submissions@trailheadlines.com?subject=Rising%20Stars%20Profile%20Submission"
                                    className="px-6 py-3 bg-trail-blue text-white font-bold rounded-lg hover:bg-blue-700 whitespace-nowrap font-sans"
                                >
                                    Submit Profile
                                </a>
                                <a
                                    href="mailto:sponsorships@trailheadlines.com?subject=Sponsorship%20Inquiry%20-%20Rising%20Stars"
                                    className="px-6 py-3 bg-gray-800 text-white font-bold rounded-lg hover:bg-gray-700 border border-gray-700 whitespace-nowrap font-sans"
                                >
                                    Sponsorship Info
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    )
}
