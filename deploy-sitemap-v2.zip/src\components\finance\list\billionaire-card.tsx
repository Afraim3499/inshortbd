import Link from 'next/link'
import Image from 'next/image'
import type { BillionaireWithHoldings } from '@/types/finance.types'

interface BillionaireCardProps {
    billionaire: BillionaireWithHoldings
}

export function BillionaireCard({ billionaire }: BillionaireCardProps) {
    const countryName = billionaire.country_code === 'US' ? 'United States'
        : billionaire.country_code === 'CN' ? 'China'
            : billionaire.country_code === 'IN' ? 'India'
                : billionaire.country_code

    const flagEmoji = billionaire.country_code === 'US' ? '🇺🇸'
        : billionaire.country_code === 'CN' ? '🇨🇳'
            : billionaire.country_code === 'IN' ? '🇮🇳'
                : '🌐'

    const netWorthBillions = (billionaire.net_worth_usd / 1000000000).toFixed(1)

    return (
        <Link
            href={`/finance/billionaires/${billionaire.slug}`}
            className="block bg-white rounded-2xl p-4 sm:p-6 shadow-sm border-2 border-transparent hover:border-[#D4AF37] transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1"
        >
            <div className="flex flex-col sm:flex-row gap-4 sm:gap-6">

                {/* Rank & Photo */}
                <div className="flex items-center gap-4 sm:flex-col sm:items-center sm:w-24 flex-shrink-0">
                    <div className="text-3xl sm:text-4xl font-black text-[#D4AF37] font-display">
                        #{billionaire.world_rank || '-'}
                    </div>
                    <div className="relative w-16 h-16 sm:w-20 sm:h-20">
                        <Image
                            src={billionaire.photo_url || '/placeholder-billionaire.jpg'}
                            alt={billionaire.name}
                            fill
                            sizes="(max-width: 640px) 64px, 80px"
                            className="rounded-full object-cover"
                            unoptimized
                        />
                    </div>
                </div>

                {/* Main Info */}
                <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-2 mb-3">
                        <div>
                            <h3 className="text-xl sm:text-2xl font-black mb-1 font-display group-hover:text-[#D4AF37] transition-colors">{billionaire.name}</h3>
                            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-gray-600 font-sans">
                                {billionaire.age && <span className="font-semibold">{billionaire.age} years old</span>}
                                {billionaire.age && <span>•</span>}
                                <span>{flagEmoji} {countryName}</span>
                                <span>•</span>
                                <span className="px-2 py-1 bg-[#D4AF37]/10 text-[#B4941F] rounded-full font-semibold">
                                    {billionaire.industry}
                                </span>
                            </div>
                        </div>
                        <div className="text-right">
                            <div className="text-2xl sm:text-3xl font-black text-[#D4AF37] mb-1 font-display">
                                ${netWorthBillions}B
                            </div>
                            <div className="text-xs text-gray-400 font-mono">
                                Net Worth
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </Link>
    )
}
