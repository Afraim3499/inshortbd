import { NextResponse } from 'next/server'
import { createClient } from '@/utils/supabase/server'
import { getSiteUrl } from '@/lib/env'

export async function GET() {
  const supabase = await createClient()
  const siteUrl = getSiteUrl()

  const { data: posts, error } = await (supabase
    .from('posts') as any)
    .select('id, title, slug, excerpt, published_at, category')
    .eq('status', 'published')
    .not('published_at', 'is', null)
    .order('published_at', { ascending: false })
    .limit(50)

  if (error) {
    return new NextResponse('Error generating RSS feed', { status: 500 })
  }

  const typedPosts = (posts || []) as any[]

  const rssItems = typedPosts
    .map((post: any) => {
      const pubDate = post.published_at
        ? new Date(post.published_at).toUTCString()
        : new Date().toUTCString()

      return `
    <item>
      <title><![CDATA[${escapeXml(post.title)}]]></title>
      <link>${siteUrl}/news/${post.slug}</link>
      <guid>${siteUrl}/news/${post.slug}</guid>
      <pubDate>${pubDate}</pubDate>
      <description><![CDATA[${escapeXml(post.excerpt || '')}]]></description>
      <category>${escapeXml(post.category)}</category>
    </item>`
    })
    .join('\n')

  const rss = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/">
  <channel>
    <title>The Trail</title>
    <link>${siteUrl}</link>
    <description>Follow the path to the truth. Unbiased news and analysis.</description>
    <language>en-us</language>
    <lastBuildDate>${new Date().toUTCString()}</lastBuildDate>
    <managingEditor>editor@thetrail.news (The Trail Editorial Team)</managingEditor>
    <webMaster>tech@thetrail.news (The Trail Tech Team)</webMaster>
    ${rssItems}
  </channel>
</rss>`

  return new NextResponse(rss, {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
    },
  })
}

function escapeXml(unsafe: string) {
  return unsafe
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;')
}

