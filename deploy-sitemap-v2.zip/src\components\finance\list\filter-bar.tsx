'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useCallback, useState, useEffect } from 'react'

export function FilterBar() {
    const router = useRouter()
    const searchParams = useSearchParams()

    // Local state for immediate feedback
    const [searchTerm, setSearchTerm] = useState(searchParams?.get('q') || '')

    // Create Query String
    const createQueryString = useCallback(
        (name: string, value: string) => {
            const params = new URLSearchParams(searchParams?.toString() || '')
            if (value) {
                params.set(name, value)
            } else {
                params.delete(name)
            }
            return params.toString()
        },
        [searchParams]
    )

    const handleFilterChange = (name: string, value: string) => {
        // Reset page to 1 when filter changes
        const params = new URLSearchParams(searchParams?.toString() || '')
        if (value && value !== 'all') {
            params.set(name, value)
        } else {
            params.delete(name)
        }
        params.delete('page') // Reset pagination

        router.push(`/finance/billionaires?${params.toString()}`)
    }

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault()
        handleFilterChange('q', searchTerm)
    }

    // Effect to update local state if URL changes externally
    useEffect(() => {
        setTimeout(() => setSearchTerm(searchParams?.get('q') || ''), 0)
    }, [searchParams])

    return (
        <div className="bg-white border-b sticky top-0 z-40 shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">

                {/* Search Bar - Make it a form to handle Enter key */}
                <form onSubmit={handleSearch} className="mb-4">
                    <div className="relative">
                        <input
                            type="text"
                            placeholder="Search billionaires by name or company..."
                            className="w-full px-4 py-3 pl-12 border-2 border-gray-200 rounded-xl focus:border-[#D4AF37] focus:outline-none text-sm sm:text-base"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                        <svg className="w-5 h-5 text-gray-400 absolute left-4 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                </form>

                {/* Filter Pills */}
                <div className="flex flex-wrap gap-2 mb-4">
                    <div className="text-xs sm:text-sm font-bold text-gray-500 flex items-center mr-2 font-sans">FILTERS:</div>

                    {/* Country Filter */}
                    <select
                        onChange={(e) => handleFilterChange('country', e.target.value)}
                        className="filter-pill px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-full text-xs sm:text-sm font-semibold cursor-pointer border-none focus:ring-2 focus:ring-[#D4AF37]"
                        defaultValue={searchParams?.get('country') || 'all'}
                    >
                        <option value="all">All Countries</option>
                        <option value="US">🇺🇸 United States</option>
                        <option value="CN">🇨🇳 China</option>
                        <option value="IN">🇮🇳 India</option>
                        <option value="GB">🇬🇧 United Kingdom</option>
                        <option value="DE">🇩🇪 Germany</option>
                        <option value="FR">🇫🇷 France</option>
                    </select>

                    {/* Industry Filter */}
                    <select
                        onChange={(e) => handleFilterChange('industry', e.target.value)}
                        className="filter-pill px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-full text-xs sm:text-sm font-semibold cursor-pointer border-none focus:ring-2 focus:ring-[#D4AF37]"
                        defaultValue={searchParams?.get('industry') || 'all'}
                    >
                        <option value="all">All Industries</option>
                        <option value="Technology">💻 Technology</option>
                        <option value="Finance & Investments">💰 Finance</option>
                        <option value="Manufacturing">🏭 Manufacturing</option>
                        <option value="Fashion & Retail">🛍️ Fashion & Retail</option>
                        <option value="Energy">⚡ Energy</option>
                    </select>

                    {/* Sort */}
                    <select
                        onChange={(e) => handleFilterChange('sort', e.target.value)}
                        className="filter-pill px-4 py-2 bg-black text-[#D4AF37] border border-[#D4AF37] rounded-full text-xs sm:text-sm font-bold cursor-pointer ml-auto focus:ring-2 focus:ring-[#D4AF37]/50"
                        defaultValue={searchParams?.get('sort') || 'net_worth'}
                    >
                        <option value="net_worth">Sort: Richest First</option>
                        <option value="age">Sort: Youngest First</option>
                        <option value="rank">Sort: Rank</option>
                        <option value="name">Sort: Name A-Z</option>
                    </select>
                </div>

                {/* Clear Filters (Only show if filters active) */}
                {(searchParams?.get('country') || searchParams?.get('industry') || searchParams?.get('q')) && (
                    <div className="flex flex-wrap gap-2 items-center">
                        <button
                            onClick={() => router.push('/finance/billionaires')}
                            className="px-3 py-1 bg-gray-200 rounded-full text-xs flex items-center gap-2 hover:bg-gray-300 font-sans font-medium"
                        >
                            <span>Clear All</span>
                            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                            </svg>
                        </button>
                    </div>
                )}

            </div>
        </div>
    )
}
