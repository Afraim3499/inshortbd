import type { StartupStoryExtended } from '@/types/finance.types'

interface StartupTimelineProps {
    timeline: StartupStoryExtended['timeline']
    variant: 'success' | 'failure'
}

export function StartupTimeline({ timeline, variant }: StartupTimelineProps) {
    const isSuccess = variant === 'success'

    const containerClass = isSuccess
        ? 'bg-gradient-to-r from-green-50 to-emerald-50'
        : 'bg-red-50 border-2 border-red-200'

    const titleClass = isSuccess ? 'text-black' : 'text-red-900'
    const dateColor = isSuccess ? 'text-green-600' : 'text-red-600' // Although failure timeline in template had red bars?
    // Template check: Success -> Green text, Green bar. Failure -> "The Decline", red bars.

    const barColor = isSuccess ? 'border-green-600' : 'border-red-600' // For success vertical line

    if (!timeline || timeline.length === 0) return null

    return (
        <div className={`my-16 rounded-2xl p-6 sm:p-10 ${containerClass}`}>
            <h3 className={`text-2xl font-black mb-8 font-display ${titleClass}`}>
                {isSuccess ? 'Founding Timeline' : 'The Decline'}
            </h3>

            <div className="space-y-6">
                {timeline.map((event, idx) => (
                    <div key={idx} className={isSuccess ? 'flex gap-4' : 'mb-4'}>
                        {/* Success Layout: Horizontal Flex */}
                        {isSuccess && (
                            <>
                                <div className={`w-24 sm:w-32 ${dateColor} font-black flex-shrink-0 font-sans`}>
                                    {event.date}
                                </div>
                                <div className={`border-l-4 ${barColor} pl-6`}>
                                    <p className="font-bold font-sans">{event.title}</p>
                                    <p className="text-sm text-gray-600 font-sans">{event.description}</p>
                                </div>
                            </>
                        )}

                        {/* Failure Layout: Bar Chart style as per template? 
                     Template had specific bar charts for WeWork. 
                     For generic timeline, we can fallback to list or try to parse 'description' as value?
                     Let's use a similar list layout for failure but styled red for consistency unless data implies numbers.
                     "The Decline" in WeWork template WAS a bar chart (visual div width).
                     If our data is text timeline, we render text. 
                  */}
                        {!isSuccess && (
                            <div className="flex gap-4">
                                <div className="hidden sm:block sm:w-32 text-red-900 font-bold flex-shrink-0 font-sans opacity-70">
                                    {event.date}
                                </div>
                                <div className="flex-1">
                                    <div className="font-bold text-red-900 mb-1">{event.title} <span className="sm:hidden text-xs opacity-70">({event.date})</span></div>
                                    <div className="h-2 bg-red-200 rounded-full overflow-hidden w-full mb-2">
                                        <div className="h-full bg-red-500 w-full rounded-full"></div>
                                    </div>
                                    <p className="text-sm text-red-800 opacity-80 font-sans">{event.description}</p>
                                </div>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    )
}
