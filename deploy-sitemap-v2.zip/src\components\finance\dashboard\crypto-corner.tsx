export function CryptoCorner() {
    return (
        <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-6 border-2 border-orange-200">
            <h3 className="text-lg font-black mb-6 flex items-center gap-2 font-display">
                <span>🪙</span> Crypto Corner
            </h3>
            <div className="space-y-4">
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-orange-500 rounded-full flex items-center justify-center text-white font-black font-display">₿</div>
                        <div className="flex-1">
                            <div className="font-black font-display">Bitcoin</div>
                            <div className="text-xs text-gray-500 font-sans">BTC</div>
                        </div>
                    </div>
                    <div className="flex items-center justify-between">
                        <div className="font-bold text-lg font-mono">$96,350</div>
                        <div className="text-green-600 font-bold font-sans">+3.2%</div>
                    </div>
                </div>
                <div className="bg-white rounded-xl p-4 hover:shadow-lg transition-all cursor-pointer">
                    <div className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-black font-display">Ξ</div>
                        <div className="flex-1">
                            <div className="font-black font-display">Ethereum</div>
                            <div className="text-xs text-gray-500 font-sans">ETH</div>
                        </div>
                    </div>
                    <div className="flex items-center justify-between">
                        <div className="font-bold text-lg font-mono">$3,280</div>
                        <div className="text-green-600 font-bold font-sans">+5.1%</div>
                    </div>
                </div>
            </div>
        </div>
    )
}
