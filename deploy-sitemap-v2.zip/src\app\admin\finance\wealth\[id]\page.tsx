'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/utils/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { TiptapEditor } from '@/components/editor/tiptap'
import { Loader2, ArrowLeft, Lock, Unlock } from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import Link from 'next/link'

export default function WealthStrategyEditorPage() {
    const params = useParams()
    const id = params.id as string
    const isNew = id === 'new'
    const router = useRouter()
    const supabase = createClient()
    const queryClient = useQueryClient()

    const [title, setTitle] = useState('')
    const [orderIndex, setOrderIndex] = useState<number>(1)
    const [isLocked, setIsLocked] = useState(true)
    const [content, setContent] = useState<any>(null)
    const [error, setError] = useState('')

    // Fetch existing
    const { data: existingData, isLoading } = useQuery({
        queryKey: ['strategy', id],
        queryFn: async () => {
            if (isNew) return null
            const { data, error } = await supabase.from('playbook_strategies').select('*').eq('id', id).single()
            if (error) throw error
            return data
        },
        enabled: !isNew
    })

    useEffect(() => {
        if (existingData) {
            setTitle(existingData.title)
            setOrderIndex(existingData.order_index)
            setIsLocked(existingData.is_locked)
            setContent(existingData.content) // Note: In DB it might be raw HTML if fallback, or JSON if new. Tiptap handles JSON well.
            // If fallback HTML was somehow saved, we might need parsing, but lets assume we start fresh or consistent.
        }
    }, [existingData])


    const saveMutation = useMutation({
        mutationFn: async () => {
            if (!title) throw new Error("Title is required")

            const payload: any = {
                title,
                order_index: orderIndex,
                is_locked: isLocked,
                content: content,
                // tags field in DB is jsonb, can add simplified tag editor later if needed
            }

            if (isNew) {
                const { error } = await supabase.from('playbook_strategies').insert(payload)
                if (error) throw error
            } else {
                const { error } = await supabase.from('playbook_strategies').update(payload).eq('id', id)
                if (error) throw error
            }
        },
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['playbook-strategies'] })
            router.push('/admin/finance/wealth')
        },
        onError: (err: any) => setError(err.message)
    })

    if (isLoading) return <div className="p-8 flex justify-center"><Loader2 className="animate-spin" /></div>

    return (
        <div className="max-w-3xl mx-auto space-y-8 pb-12">
            <div className="flex items-center gap-4">
                <Link href="/admin/finance/wealth">
                    <Button variant="ghost" size="icon"><ArrowLeft className="w-4 h-4" /></Button>
                </Link>
                <h1 className="text-2xl font-bold font-heading">{isNew ? 'New Strategy' : 'Edit Strategy'}</h1>
            </div>

            {error && <div className="p-4 bg-red-50 text-red-600 rounded-md">{error}</div>}

            <div className="grid gap-6">
                <div className="bg-white p-6 rounded-lg border space-y-4">
                    <div className="flex gap-4">
                        <div className="w-24">
                            <Label>Step #</Label>
                            <Input type="number" value={orderIndex} onChange={e => setOrderIndex(Number(e.target.value))} />
                        </div>
                        <div className="flex-1">
                            <Label>Strategy Title</Label>
                            <Input value={title} onChange={e => setTitle(e.target.value)} />
                        </div>
                    </div>

                    <div className="flex items-center gap-2 pt-2">
                        <Button
                            type="button"
                            variant={isLocked ? "secondary" : "outline"}
                            onClick={() => setIsLocked(!isLocked)}
                            className={isLocked ? "bg-gray-100" : "border-green-200 text-green-700"}
                        >
                            {isLocked ? <Lock className="w-4 h-4 mr-2" /> : <Unlock className="w-4 h-4 mr-2" />}
                            {isLocked ? 'Locked Content' : 'Free / Open Access'}
                        </Button>
                    </div>
                </div>

                <div className="space-y-2">
                    <Label>Strategy Description & Guide</Label>
                    <TiptapEditor
                        content={content}
                        onChange={setContent}
                        className="min-h-[400px] border rounded-lg bg-white"
                    />
                </div>

                <div className="flex justify-end">
                    <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="px-8 bg-purple-600 hover:bg-purple-700">
                        {saveMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                        Save Strategy
                    </Button>
                </div>
            </div>
        </div>
    )
}
