'use client'

import Link from 'next/link'
import { Eye } from 'lucide-react'
import { NewsImage } from '@/components/news-image'

interface Post {
    id: string
    title: string
    slug: string
    views?: number | null
    category?: string
    published_at?: string
    featured_image_url?: string
}

interface LeftSidebarProps {
    trendingPosts: Post[]
    editorsPicks: Post[]
}

export function LeftSidebar({ trendingPosts, editorsPicks }: LeftSidebarProps) {
    return (
        <aside className="col-span-12 lg:col-span-3 space-y-6 order-2 lg:order-1">
            {/* Trending Now */}
            <div className="bg-white border border-card-border rounded-xl p-5 shadow-sm">
                <h3 className="font-bold text-sm uppercase tracking-wider text-ink-black mb-4 flex items-center gap-2 font-sans">
                    <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></span>
                    Trending Now
                </h3>
                <div className="space-y-4">
                    {trendingPosts.map((post, index) => (
                        <Link key={post.id} href={`/news/${post.slug}`} className="group block">
                            <div className="flex gap-3">
                                <span className="text-2xl font-black text-gray-200 group-hover:text-trail-blue font-display transition-colors w-6 text-center">{index + 1}</span>
                                <div className="flex-1">
                                    <h4 className="text-sm font-semibold text-ink-black group-hover:text-trail-blue leading-tight mb-1 font-sans transition-colors line-clamp-2">
                                        {post.title}
                                    </h4>
                                    <div className="flex items-center gap-2 text-xs text-meta-gray font-mono">
                                        {post.views ? (
                                            <span className="flex items-center gap-1">
                                                <Eye className="w-3 h-3" />
                                                {post.views.toLocaleString()} views
                                            </span>
                                        ) : (
                                            <span>Trending</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        </Link>
                    ))}
                    {trendingPosts.length === 0 && <p className="text-sm text-gray-500">No trending posts yet.</p>}
                </div>
            </div>

            {/* Editor's Picks */}
            <div className="bg-trail-blue/5 border border-trail-blue/20 rounded-xl p-5">
                <h3 className="font-bold text-sm uppercase tracking-wider text-trail-blue mb-4 font-sans">
                    Editor&apos;s Picks
                </h3>
                <div className="space-y-4">
                    {editorsPicks.map(post => (
                        <Link key={post.id} href={`/news/${post.slug}`} className="group block">
                            <div className="aspect-video rounded-lg overflow-hidden mb-2 relative">
                                <NewsImage
                                    src={post.featured_image_url}
                                    alt={post.title}
                                    fill
                                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                                />
                            </div>
                            <h4 className="text-sm font-bold text-ink-black group-hover:text-trail-blue leading-tight font-sans transition-colors line-clamp-2">
                                {post.title}
                            </h4>
                            <p className="text-xs text-meta-gray mt-1 font-sans">In-depth analysis</p>
                        </Link>
                    ))}
                    {editorsPicks.length === 0 && <p className="text-sm text-gray-500">No picks selected.</p>}
                </div>
            </div>

            {/* Newsletter */}
            <div className="bg-ink-black text-white rounded-xl p-6 shadow-lg">
                <h3 className="font-bold text-lg mb-2 font-display">Daily Brief</h3>
                <p className="text-sm text-gray-300 mb-4 font-sans leading-relaxed">Get the top stories delivered to your inbox every morning.</p>
                <form className="space-y-3" onSubmit={(e) => e.preventDefault()}>
                    <input
                        type="email"
                        placeholder="Your email"
                        className="w-full px-4 py-2 rounded-lg text-gray-900 text-sm focus:outline-none focus:ring-2 focus:ring-trail-blue"
                    />
                    <button className="w-full bg-trail-blue hover:bg-blue-600 text-white font-medium py-2 rounded-lg text-sm transition-colors font-sans transform hover:scale-[1.02] duration-200">
                        Subscribe
                    </button>
                </form>
            </div>
        </aside>
    )
}
