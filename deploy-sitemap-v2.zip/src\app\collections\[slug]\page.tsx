import { createClient } from '@/utils/supabase/server'
import Link from 'next/link'
import { NewsImage } from '@/components/news-image'
import { Metadata } from 'next'
import { notFound } from 'next/navigation'
import { ArrowLeft, BookOpen } from 'lucide-react'

export async function generateMetadata({
  params,
}: {
  params: { slug: string }
}): Promise<Metadata> {
  const supabase = await createClient()
  const { data: collection } = await (supabase
    .from('collections') as any)
    .select('title, description')
    .eq('slug', params.slug)
    .single()

  if (!collection) {
    return {
      title: 'Collection Not Found - The Trail',
    }
  }

  const typedCollection = collection as any
  return {
    title: `${typedCollection.title} - Collections | The Trail`,
    description: typedCollection.description || `Explore ${typedCollection.title} collection on The Trail`,
    openGraph: {
      title: typedCollection.title,
      description: typedCollection.description || '',
      type: 'website',
    },
  }
}

async function getCollection(slug: string) {
  const supabase = await createClient()

  const { data: collection, error } = await (supabase
    .from('collections') as any)
    .select('*')
    .eq('slug', slug)
    .single()

  if (error || !collection) {
    return null
  }

  return collection as any
}

async function getCollectionPosts(collectionId: string) {
  const supabase = await createClient()

  const { data, error } = await (supabase
    .from('collection_posts') as any)
    .select(
      `
      order_index,
      posts (
        id,
        title,
        slug,
        excerpt,
        featured_image_url,
        published_at,
        views,
        category
      )
    `
    )
    .eq('collection_id', collectionId)
    .order('order_index', { ascending: true })

  if (error) {
    console.error('Error fetching collection posts:', error)
    return []
  }

  // Filter out null posts (deleted posts)
  return (data || []).filter((item: any) => item.posts).map((item: any) => ({
    ...item.posts,
    order_index: item.order_index,
  }))
}

// Enable ISR: revalidate every 60 seconds
export const revalidate = 60

export default async function CollectionPage({
  params,
}: {
  params: { slug: string }
}) {
  const collection = await getCollection(params.slug)

  if (!collection) {
    notFound()
  }

  const posts = await getCollectionPosts(collection.id)

  // Filter to only published posts
  const publishedPosts = posts.filter(
    (post: any) => post && post.published_at
  )

  const isSeries = publishedPosts.length > 1 && publishedPosts.some((post: any, index: number) => {
    const prev = publishedPosts[index - 1]
    return prev && post.order_index !== undefined && prev.order_index !== undefined
  })

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        {collection.featured_image_url && (
          <div className="relative w-full h-64 md:h-96 rounded-lg overflow-hidden border border-border/50 mb-6">
            <NewsImage
              src={collection.featured_image_url}
              alt={collection.title}
              fill
              className="object-cover"
            />
          </div>
        )}

        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
          <BookOpen className="h-4 w-4" />
          <span>Collection</span>
          {isSeries && <span>•</span>}
          {isSeries && <span>Series</span>}
        </div>

        <h1 className="text-4xl md:text-5xl font-heading font-bold mb-4">
          {collection.title}
        </h1>

        {collection.description && (
          <p className="text-xl text-muted-foreground leading-relaxed max-w-3xl">
            {collection.description}
          </p>
        )}

        <div className="mt-4 text-sm text-muted-foreground">
          {publishedPosts.length} {publishedPosts.length === 1 ? 'article' : 'articles'} in this collection
        </div>
      </div>

      {/* Posts List */}
      {publishedPosts.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <p>No published articles in this collection yet.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {isSeries ? (
            // Series: Show with part numbers
            <div className="space-y-4">
              {publishedPosts.map((post: any, index: number) => (
                <Link
                  key={post.id}
                  href={`/news/${post.slug}`}
                  className="group block border border-border rounded-lg overflow-hidden hover:border-accent transition-colors"
                >
                  <div className="grid md:grid-cols-3 gap-6 p-6">
                    {post.featured_image_url && (
                      <div className="relative w-full h-48 md:h-full overflow-hidden rounded-md">
                        <NewsImage
                          src={post.featured_image_url}
                          alt={post.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}
                    <div className={`${post.featured_image_url ? 'md:col-span-2' : 'md:col-span-3'} space-y-2`}>
                      <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground">
                        <span className="text-accent uppercase">
                          Part {post.order_index !== null && post.order_index !== undefined 
                            ? post.order_index + 1 
                            : index + 1} of {publishedPosts.length}
                        </span>
                        <span>•</span>
                        <span className="text-accent uppercase">{post.category}</span>
                        {post.published_at && (
                          <>
                            <span>•</span>
                            <span>
                              {new Date(post.published_at).toLocaleDateString()}
                            </span>
                          </>
                        )}
                      </div>
                      <h2 className="text-2xl font-heading font-bold group-hover:text-accent transition-colors">
                        {post.title}
                      </h2>
                      {post.excerpt && (
                        <p className="text-muted-foreground line-clamp-2">
                          {post.excerpt}
                        </p>
                      )}
                      {post.views !== null && (
                        <div className="text-xs text-muted-foreground">
                          {post.views} views
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            // Regular Collection: Grid layout
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {publishedPosts.map((post: any) => (
                <Link
                  key={post.id}
                  href={`/news/${post.slug}`}
                  className="group block border border-border rounded-lg overflow-hidden hover:border-accent transition-colors"
                >
                    {post.featured_image_url && (
                      <div className="relative w-full h-48 overflow-hidden">
                        <NewsImage
                          src={post.featured_image_url}
                          alt={post.title}
                          fill
                          className="object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}
                  <div className="p-4">
                    <span className="text-xs font-mono text-accent uppercase">
                      {post.category}
                    </span>
                    <h2 className="text-xl font-heading font-bold mt-2 mb-2 group-hover:text-accent transition-colors">
                      {post.title}
                    </h2>
                    {post.excerpt && (
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {post.excerpt}
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                      {post.published_at && (
                        <time dateTime={post.published_at}>
                          {new Date(post.published_at).toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </time>
                      )}
                      {post.views !== null && (
                        <>
                          <span>•</span>
                          <span>{post.views} views</span>
                        </>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}




