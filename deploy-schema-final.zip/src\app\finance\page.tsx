import { FinanceHeader } from '@/components/finance/finance-header'
import Link from 'next/link'
import { TrendingUp, Users, BookOpen, Rocket, Award } from 'lucide-react'
import type { Metadata } from 'next'

export const metadata: Metadata = {
    title: 'Finance Hub - The Trail',
    description: 'Market insights, billionaire profiles, startup stories, and wealth building strategies.',
}

import { BreadcrumbStructuredData } from '@/components/structured-data'
import { getSiteUrl } from '@/lib/env'

export default function FinanceHubPage() {
    // ... existing hubs
    const hubs = [
        {
            title: 'Market Dashboard',
            description: 'Live global market data, crypto prices, and economic calendar.',
            href: '/finance/markets',
            icon: <TrendingUp className="w-8 h-8 text-blue-600" />,
            color: 'bg-blue-50 border-blue-100'
        },
        // ... (rest of hubs array)
        {
            title: 'Women Breaking Billions',
            description: 'Celebrating self-made female billionaires.',
            href: '/finance/women-breaking-billions',
            icon: <Award className="w-8 h-8 text-pink-600" />,
            color: 'bg-pink-50 border-pink-100'
        }
    ]

    return (
        <div className="min-h-screen bg-white">
            <BreadcrumbStructuredData
                items={[
                    { name: 'Home', url: '/' },
                    { name: 'Finance', url: '/finance' }
                ]}
                siteUrl={getSiteUrl()}
            />
            <FinanceHeader />
            <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="text-center mb-16">
                    <h1 className="text-5xl font-black mb-4 font-display text-ink-black">Finance Hub</h1>
                    <p className="text-xl text-gray-600 font-serif max-w-2xl mx-auto">
                        Navigate the world of money, markets, and moguls with our comprehensive financial tools and insights.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {hubs.map((hub) => (
                        <Link
                            key={hub.title}
                            href={hub.href}
                            className={`group block p-8 rounded-2xl border-2 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl ${hub.color}`}
                        >
                            <div className="mb-6 bg-white w-16 h-16 rounded-xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                                {hub.icon}
                            </div>
                            <h3 className="text-2xl font-bold mb-3 font-display text-gray-900 group-hover:text-trail-blue transition-colors">
                                {hub.title}
                            </h3>
                            <p className="text-gray-600 font-sans leading-relaxed">
                                {hub.description}
                            </p>
                        </Link>
                    ))}
                </div>
            </main>
        </div>
    )
}
