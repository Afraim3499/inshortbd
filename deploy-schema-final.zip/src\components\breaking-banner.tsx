'use client'

import { useEffect, useState } from 'react'

interface BreakingBannerProps {
  text: string
  active: boolean
}

export function BreakingBanner({ text, active }: BreakingBannerProps) {
  const [shouldMarquee, setShouldMarquee] = useState(false)

  useEffect(() => {
    // Check if text is long enough to require marquee
    const textElement = document.createElement('span')
    textElement.textContent = text
    textElement.style.visibility = 'hidden'
    textElement.style.position = 'absolute'
    textElement.style.whiteSpace = 'nowrap'
    document.body.appendChild(textElement)
    const textWidth = textElement.offsetWidth
    document.body.removeChild(textElement)

    // If text is wider than viewport, enable marquee
    setTimeout(() => setShouldMarquee(textWidth > window.innerWidth - 200), 0) // 200px for "BREAKING" label
  }, [text])

  if (!active || !text) return null

  return (
    <div className="relative top-0 left-0 right-0 z-50 bg-alert-red text-white py-3 px-4">
      <div className="max-w-screen-xl mx-auto flex items-center gap-4">
        <span className="font-bold uppercase text-xs tracking-widest whitespace-nowrap flex-shrink-0">
          Breaking
        </span>
        <div className="flex-1 overflow-hidden">
          {shouldMarquee ? (
            <div className="animate-marquee whitespace-nowrap">
              <span className="inline-block font-medium">{text}</span>
            </div>
          ) : (
            <span className="font-medium">{text}</span>
          )}
        </div>
      </div>
    </div>
  )
}
