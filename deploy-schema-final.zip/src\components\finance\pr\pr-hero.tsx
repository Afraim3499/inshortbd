interface PRHeroProps {
    title: string
    subtitle: string
    stats: {
        count: number
        wealth: string
        avgAge?: number
        selfMadePct?: number
        newThisYear?: number
        countries?: number
    }
    badgeText: string
    colorClass?: string // e.g. 'text-trail-blue' or 'text-purple-400'
}

export function PRHero({
    title,
    subtitle,
    stats,
    badgeText,
    colorClass = 'text-trail-blue'
}: PRHeroProps) {
    return (
        <div className="bg-gray-900 text-white py-16 sm:py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6">
                <div className="max-w-3xl">
                    <div className={`inline-block px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-sm font-bold mb-4 ${colorClass}`}>
                        ⭐ {badgeText}
                    </div>
                    <h1 className="font-display text-5xl sm:text-6xl lg:text-7xl font-black mb-6 leading-tight">
                        {title}
                    </h1>
                    <p className="text-xl sm:text-2xl opacity-90 mb-8 font-sans text-gray-300">
                        {subtitle}
                    </p>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                            <div className={`text-3xl font-black ${colorClass} font-display`}>
                                {stats.count}
                            </div>
                            <div className="text-sm opacity-75 font-sans">Billionaires</div>
                        </div>
                        <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                            <div className={`text-3xl font-black ${colorClass} font-display`}>
                                {stats.wealth}
                            </div>
                            <div className="text-sm opacity-75 font-sans">Combined Wealth</div>
                        </div>
                        {stats.avgAge && (
                            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                                <div className={`text-3xl font-black ${colorClass} font-display`}>
                                    {stats.avgAge}
                                </div>
                                <div className="text-sm opacity-75 font-sans">Avg Age</div>
                            </div>
                        )}
                        {stats.selfMadePct && (
                            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                                <div className={`text-3xl font-black ${colorClass} font-display`}>
                                    {stats.selfMadePct}%
                                </div>
                                <div className="text-sm opacity-75 font-sans">Self-Made</div>
                            </div>
                        )}
                        {stats.newThisYear && !stats.avgAge && (
                            <div className="bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10">
                                <div className={`text-3xl font-black ${colorClass} font-display`}>
                                    +{stats.newThisYear}
                                </div>
                                <div className="text-sm opacity-75 font-sans">New This Year</div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    )
}
