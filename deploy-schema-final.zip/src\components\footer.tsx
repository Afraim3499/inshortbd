'use client'

import Link from 'next/link'
import Image from 'next/image'
import { Twitter, Instagram, Youtube, ArrowUp } from 'lucide-react'
import { NewsletterSignup } from './newsletter-signup'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import { Button } from '@/components/ui/button'

const CATEGORIES = ['Politics', 'Tech', 'Culture', 'Business', 'World']

export function Footer() {
  const currentYear = new Date().getFullYear()

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="hidden lg:block border-t border-card-border bg-gradient-to-b from-white to-soft-wash/30 mt-24">
      <div className="max-w-screen-xl mx-auto px-4 lg:px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Branding Section */}
          <div className="space-y-4">
            <Link
              href="/"
              className="inline-block hover:opacity-80 transition-opacity"
            >
              <Image
                src="/logo.svg"
                alt="The Trail"
                width={180}
                height={40}
                className="h-10 w-auto"
              />
            </Link>
            <p className="text-sm text-slate-text font-serif leading-relaxed">
              Follow the path to the truth. High-end printed magazine aesthetic with zero eye strain and maximum legibility.
            </p>

            {/* Social Media Icons - Horizontal */}
            <div className="flex items-center gap-3 pt-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <a
                      href="https://twitter.com/TheTrailNews"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-soft-wash hover:bg-trail-blue hover:text-white transition-all hover:scale-110 no-underline"
                      aria-label="Follow us on Twitter/X"
                    >
                      <Twitter className="w-4 h-4" />
                    </a>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Follow us on Twitter/X</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <a
                      href="https://instagram.com/TheTrailDaily"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-soft-wash hover:bg-trail-blue hover:text-white transition-all hover:scale-110 no-underline"
                      aria-label="Follow us on Instagram"
                    >
                      <Instagram className="w-4 h-4" />
                    </a>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Follow us on Instagram</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <a
                      href="https://youtube.com/@TheTrailWatch"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-10 h-10 rounded-full flex items-center justify-center bg-soft-wash hover:bg-trail-blue hover:text-white transition-all hover:scale-110 no-underline"
                      aria-label="Follow us on YouTube"
                    >
                      <Youtube className="w-4 h-4" />
                    </a>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Follow us on YouTube</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
          </div>

          {/* Categories Section - Horizontal Button Row */}
          <div>
            <h3
              className="font-sans font-semibold text-sm mb-4 text-ink-black"
              id="footer-categories"
            >
              Categories
            </h3>
            <div className="flex flex-col gap-2" aria-labelledby="footer-categories">
              {CATEGORIES.map((category) => (
                <Link
                  key={category}
                  href={`/category/${encodeURIComponent(category)}`}
                  className="footer-category-link"
                  aria-label={`Browse ${category} category`}
                >
                  {category}
                </Link>
              ))}
            </div>
          </div>

          {/* Quick Links Section - Simple Links */}
          <div>
            <h3 className="font-sans font-semibold text-sm mb-4 text-ink-black">
              Quick Links
            </h3>
            <div className="flex flex-col gap-2">
              <Link
                href="/about"
                className="footer-link"
              >
                About
              </Link>
              <Link
                href="/contact"
                className="footer-link"
              >
                Contact
              </Link>
              <Link
                href="/editorial-policy"
                className="footer-link"
              >
                Policy
              </Link>
              <Link
                href="/feed.xml"
                className="footer-link"
              >
                RSS
              </Link>
              <Link
                href="/archive"
                className="footer-link"
              >
                Archive
              </Link>
            </div>
          </div>

          {/* Newsletter Section */}
          <div>
            <h3 className="font-sans font-semibold text-sm mb-4 text-ink-black">
              Stay Updated
            </h3>
            <div className="bg-white/80 backdrop-blur-sm border border-card-border rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <p className="text-sm text-slate-text font-serif mb-4 leading-relaxed">
                Get the truth delivered to your inbox. Unbiased news and analysis.
              </p>
              <NewsletterSignup variant="compact" source="footer" />
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-card-border/50">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs text-meta-gray font-mono font-semibold">
              © {currentYear} The Trail. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <div className="flex gap-6 text-xs text-meta-gray font-mono">
                <Link
                  href="/editorial-policy"
                  className="hover:text-trail-blue transition-colors no-underline"
                >
                  Editorial Policy
                </Link>
                <Link
                  href="/contact"
                  className="hover:text-trail-blue transition-colors no-underline"
                >
                  Contact
                </Link>
                <Link
                  href="/admin"
                  className="hover:text-trail-blue transition-colors no-underline"
                >
                  Admin
                </Link>
              </div>
              <button
                onClick={scrollToTop}
                className="w-9 h-9 rounded-full bg-soft-wash hover:bg-trail-blue hover:text-white transition-all flex items-center justify-center"
                aria-label="Back to top"
              >
                <ArrowUp className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
