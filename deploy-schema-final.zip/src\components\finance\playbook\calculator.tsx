'use client'

import { useState } from 'react'

export function MillionaireCalculator() {
    const [age, setAge] = useState(28)
    const [investment, setInvestment] = useState(1000)

    // Basic Logic: Assume 8% return, calculate years to $1M
    // FV = PV * (1+r)^n + PMT * [((1+r)^n - 1) / r]
    // Assume PV = 0. We want FV > 1,000,000. Solve for n.
    // This is iterative or strict formula.
    // PMT usually monthly.
    // FV = P * (((1 + r/12)^(12*t) - 1) / (r/12))

    const calculateYears = (monthly: number) => {
        const r = 0.08 / 12
        const target = 1000000
        let n = 0
        let current = 0

        // Safety break
        if (monthly <= 0) return 99

        while (current < target && n < 1200) { // Max 100 years
            current = (current + monthly) * (1 + r)
            n++
        }
        return Math.ceil(n / 12)
    }

    const yearsToMillion = calculateYears(investment)
    const ageAtMillion = age + yearsToMillion

    return (
        <div className="bg-gradient-to-br from-trail-blue to-purple-600 text-white rounded-3xl p-8 sm:p-12 mb-16">
            <h3 className="text-3xl sm:text-4xl font-black mb-8 text-center font-display">💎 Your Millionaire Timeline</h3>
            <div className="grid md:grid-cols-2 gap-8 mb-8 max-w-2xl mx-auto">
                <div>
                    <label className="block font-bold mb-3 font-sans">Current Age</label>
                    <input
                        type="number"
                        value={age}
                        onChange={(e) => setAge(parseInt(e.target.value) || 0)}
                        className="w-full px-6 py-4 rounded-xl text-gray-900 font-bold text-2xl border-4 border-white focus:outline-none focus:border-yellow-300 font-mono"
                    />
                </div>
                <div>
                    <label className="block font-bold mb-3 font-sans">Monthly Investment ($)</label>
                    <input
                        type="number"
                        value={investment}
                        onChange={(e) => setInvestment(parseInt(e.target.value) || 0)}
                        className="w-full px-6 py-4 rounded-xl text-gray-900 font-bold text-2xl border-4 border-white focus:outline-none focus:border-yellow-300 font-mono"
                    />
                </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-10 text-center border-2 border-white/20">
                <div className="text-5xl sm:text-7xl font-black mb-4 font-display">Age {ageAtMillion < 100 ? ageAtMillion : '100+'}</div>
                <p className="text-xl sm:text-2xl mb-2 font-sans">
                    You&apos;ll become a millionaire in <strong className="text-yellow-300">{yearsToMillion < 100 ? yearsToMillion : '100+'} years</strong>
                </p>
                <p className="text-sm text-blue-200 font-sans">Based on 8% average annual returns (historical S&P 500)</p>
            </div>
        </div>
    )
}
