'use client'

import { cn } from '@/lib/utils'
import { ArrowUp, ArrowDown } from 'lucide-react'
import type { MarketData } from '@/lib/finnhub'

interface TickerTapeProps {
    data: MarketData[]
}

export function TickerTape({ data }: TickerTapeProps) {
    // Duplicate data to create seamless loop
    const seamlessData = [...data, ...data]

    return (
        <div className="w-full bg-slate-950 border-b border-gray-800 py-3 overflow-hidden whitespace-nowrap relative">
            {/* Gradient Masks for smooth fade */}
            <div className="absolute left-0 top-0 bottom-0 w-20 z-10 bg-gradient-to-r from-slate-950 to-transparent" />
            <div className="absolute right-0 top-0 bottom-0 w-20 z-10 bg-gradient-to-l from-slate-950 to-transparent" />

            <div className="inline-flex animate-ticker">
                {seamlessData.map((stock, i) => (
                    <div key={`${stock.symbol}-${i}`} className="flex items-center gap-3 px-8 text-sm border-r border-gray-800">
                        <span className="font-mono font-bold text-white">{stock.symbol}</span>
                        <span className="font-mono text-gray-300">
                            {stock?.price?.toLocaleString(undefined, { minimumFractionDigits: 2 }) ?? '--'}
                        </span>
                        <span className={cn(
                            "flex items-center text-xs font-bold",
                            stock.change >= 0 ? "text-green-400" : "text-red-400"
                        )}>
                            {stock.change >= 0 ? <ArrowUp className="w-3 h-3 mr-1" /> : <ArrowDown className="w-3 h-3 mr-1" />}
                            {Math.abs(stock.change_percent).toFixed(2)}%
                        </span>
                    </div>
                ))}
            </div>
        </div>
    )
}
