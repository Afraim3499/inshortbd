interface TimelineEvent {
    year: number
    label: string
    description: string
}

interface WealthTimelineProps {
    history?: TimelineEvent[] | any[]
}

export function WealthTimeline({ history = [] }: WealthTimelineProps) {
    if (!history || history.length === 0) {
        return null
    }

    // Sort by year ascending
    const sortedHistory = [...history].sort((a, b) => a.year - b.year)

    return (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-200">
            <h2 className="text-2xl font-black mb-6 font-display">Wealth Over Time</h2>
            <div className="space-y-4">
                {sortedHistory.map((event, idx) => (
                    <div key={idx} className="flex items-center gap-4">
                        <div className="w-20 font-black text-lg flex-shrink-0 font-display text-gray-400 group-hover:text-gray-900">
                            {event.year}
                        </div>
                        <div className="flex-1 border-l-4 border-gray-900 pl-4 py-1">
                            <div className="font-bold font-sans">{event.label}</div>
                            {event.description && (
                                <div className="text-sm text-gray-600 font-serif">{event.description}</div>
                            )}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}
