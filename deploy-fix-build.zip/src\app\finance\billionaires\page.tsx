import { getBillionaires } from '@/app/actions/billionaires/get'
import { HeroStats } from '@/components/finance/list/hero-stats'
import { FilterBar } from '@/components/finance/list/filter-bar'
import { BillionaireCard } from '@/components/finance/list/billionaire-card'
import { FinanceHeader } from '@/components/finance/finance-header'
import type { Metadata } from 'next'
import type { BillionaireFilters } from '@/types/finance.types'
import { Pagination } from '@/components/pagination'

export const metadata: Metadata = {
    title: 'Real-Time Billionaires List - The Trail Finance',
    description: 'Track the worlds wealthiest people in real-time. Updated market data for global billionaires.',
}

interface PageProps {
    searchParams: Promise<{
        country?: string
        industry?: string
        sort?: string
        q?: string
        page?: string
    }>
}

export default async function BillionairesListPage({ searchParams }: PageProps) {
    const resolvedParams = await searchParams

    // Construct filters
    const filters: BillionaireFilters = {
        country: resolvedParams.country === 'all' ? undefined : resolvedParams.country,
        industry: resolvedParams.industry === 'all' ? undefined : resolvedParams.industry,
        sortBy: (resolvedParams.sort as any) || 'net_worth',
        limit: 50,
    }

    // Fetch data
    const { billionaires, total } = await getBillionaires(filters)

    return (
        <div className="min-h-screen bg-gray-50">
            <FinanceHeader />

            <main>
                <HeroStats />
                <FilterBar />

                <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

                    {/* Results Count */}
                    <div className="text-sm text-gray-600 mb-6 font-sans">
                        Showing <span className="font-bold text-gray-900">{total} billionaires</span> • Real-time
                    </div>

                    {/* List */}
                    <div className="space-y-4">
                        {billionaires.length > 0 ? (
                            billionaires.map(billionaire => (
                                <BillionaireCard key={billionaire.id} billionaire={billionaire} />
                            ))
                        ) : (
                            <div className="text-center py-20 bg-white rounded-2xl shadow-sm">
                                <h3 className="text-xl font-bold text-gray-900 mb-2 font-display">No billionaires found</h3>
                                <p className="text-gray-500 font-sans">Try adjusting your filters or search query.</p>
                            </div>
                        )}
                    </div>

                    {/* Pagination Import Removed from JSX */}

                    {/* ... */}

                    {/* Pagination */}
                    {total > 50 && (
                        <div className="mt-12 pt-8 border-t border-gray-200">
                            <Pagination
                                currentPage={parseInt(resolvedParams.page || '1', 10)}
                                totalPages={Math.ceil(total / 50)}
                                baseUrl="/finance/billionaires"
                                searchParams={{
                                    country: resolvedParams.country,
                                    industry: resolvedParams.industry,
                                    sort: resolvedParams.sort,
                                    q: resolvedParams.q,
                                }}
                            />
                        </div>
                    )}
                </div>
            </main>
        </div>
    )
}
